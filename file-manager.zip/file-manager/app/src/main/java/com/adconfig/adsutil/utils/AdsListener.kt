package com.adconfig.adsutil.utils


data class AdsError(
    val code: Int,
    val error: String
)

interface AdsListener {
    fun onAdClicked()

    fun onAdDismissed()

    fun onAdLoaded(appOpenAd: Any)

    fun onAdLoaded()

    fun onAdFailedToShow(adsError: AdsError)

    fun onAdImpression()

    fun onAdShowed()

}