package com.adconfig.adsutil.admob

interface ClickCallback {
    fun clickNext()
}