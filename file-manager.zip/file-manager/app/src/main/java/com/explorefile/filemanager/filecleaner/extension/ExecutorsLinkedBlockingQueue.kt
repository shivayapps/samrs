package com.explorefile.filemanager.filecleaner.extension

import java.util.*
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadPoolExecutor

class ExecutorsLinkedBlockingQueue : LinkedBlockingQueue<Runnable?> {
    private lateinit var executor: ThreadPoolExecutor

    constructor() : super()
    constructor(capacity: Int) : super(capacity)
    constructor(c: Collection<Runnable?>?) : super(c)

    fun setExecutor(executor: ThreadPoolExecutor) {
        this.executor = executor
    }

    override fun offer(e: Runnable?): Boolean {
        Objects.requireNonNull(executor, "please call setExecutor")
        return if (executor.poolSize < executor.maximumPoolSize
            && executor.activeCount == executor.poolSize
        ) {
            false
        } else super.offer(e)
    }
}