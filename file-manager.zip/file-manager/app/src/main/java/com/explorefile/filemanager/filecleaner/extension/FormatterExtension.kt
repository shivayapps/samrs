package com.explorefile.filemanager.filecleaner.extension

import java.text.DecimalFormat


const val TB_SIZE = 1024f * 1024 * 1024 * 1024
const val GB_SIZE = 1024f * 1024 * 1024
const val MB_SIZE = 1024f * 1024
const val KB_SIZE = 1024

private val decimalFormatTLS: ThreadLocal<DecimalFormat> by lazy {
    object : ThreadLocal<DecimalFormat>() {
        override fun initialValue(): DecimalFormat {
            return DecimalFormat()
        }
    }
}

val decimalFormat: DecimalFormat get() = decimalFormatTLS.get() as DecimalFormat

fun Long.autoFormatFileSize(): String {
    return if (this > TB_SIZE) {
        (this / (TB_SIZE)).let {
            it.getAdaptiveFormatter().format(it)
        } + " TB"
    } else if (this > GB_SIZE) {
        (this / (GB_SIZE)).let {
            it.getAdaptiveFormatter().format(it)
        } + " GB"
    } else if (this > MB_SIZE) {
        (this / (MB_SIZE)).let {
            it.getAdaptiveFormatter().format(it)
        } + " MB"
    } else if (this > KB_SIZE) {
        (this / (KB_SIZE)).toFloat().let {
            it.getAdaptiveFormatter().format(it)
        } + " KB"
    } else {
        "$this B"
    }
}

private fun Float.getAdaptiveFormatter(): DecimalFormat {
    return if (this >= 100) {
        decimalFormat.apply {
            applyPattern("0")
        }
    } else if (this >= 10) {
        decimalFormat.apply {
            applyPattern("0.#")
        }
    } else {
        decimalFormat.apply {
            applyPattern("0.##")
        }
    }
}
