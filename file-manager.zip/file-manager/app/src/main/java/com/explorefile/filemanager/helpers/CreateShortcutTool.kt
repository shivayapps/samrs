package com.explorefile.filemanager.helpers

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.SystemClock
import android.util.Log
import android.widget.Toast
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.core.graphics.drawable.toBitmap
import com.explorefile.filemanager.R
import java.util.*


object CreateShortcutTool {


    var mLastClickTime: Long = 0
    fun createHomeScreenShortcutNew(context: Context, packageName: String) {
        if (ShortcutManagerCompat.isRequestPinShortcutSupported(context)) {
            val packageManager = context.packageManager
            val iconBitmap = packageManager.getApplicationIcon(packageName).toBitmap()
            val appName = packageManager.getApplicationInfo(packageName, 0).loadLabel(packageManager)

            val intent = Intent(context, ShortcutActivity::class.java)
            intent.action = "android.intent.action.MAIN"
            intent.putExtra("appName", appName)
            intent.putExtra("pkgName", packageName)
            val build: ShortcutInfoCompat =
                ShortcutInfoCompat.Builder(context, generateId(packageName))
                    .setIntent(intent).setShortLabel(
                        appName
                    ).setIcon(IconCompat.createWithBitmap(iconBitmap)).build()

            //val shortcutManager = context.getSystemService(ShortcutManager::class.java)
            //context is required when call from the fragment

            val receiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context, intent: Intent) {
                    if (SystemClock.elapsedRealtime() - mLastClickTime < 1000) return
                    mLastClickTime = SystemClock.elapsedRealtime()
                    Log.e("AppShortcut", "onReceive:123")
                    Log.e("AppShortcut", "intent: ${intent.data}")
                    Toast.makeText(context, context.getString(R.string.the_shortcut_has_been_added), Toast.LENGTH_SHORT).show()
                }
            }

            val filter = IntentFilter("test_action")

            // ✅ Safe for all Android versions
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("UnspecifiedRegisterReceiverFlag")
                context.registerReceiver(receiver, filter)
            }

            val receiverIntent = Intent("test_action")
            val pendingIntent = PendingIntent.getBroadcast(context, 123, receiverIntent, PendingIntent.FLAG_IMMUTABLE)
            ShortcutManagerCompat.requestPinShortcut(
                context,
                build,
                pendingIntent.intentSender
            )
            return
        }
        Toast.makeText(
            context,
            "launcher does not support short cut icon",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun generateId(str: String): String {
        return str + (Random().nextInt(91) + 10)
    }

}