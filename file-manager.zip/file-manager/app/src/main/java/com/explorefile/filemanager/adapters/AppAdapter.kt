package com.explorefile.filemanager.adapters

import android.content.Context
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.BaseActivity
import com.explorefile.filemanager.extensions.getContrastColor
import com.explorefile.filemanager.extensions.getProperBackgroundColor
import com.explorefile.filemanager.extensions.getProperPrimaryColor
import com.explorefile.filemanager.extensions.getProperTextColor
import com.explorefile.filemanager.models.AppInfo
import java.util.*


class AppAdapter(private val activity: BaseActivity, private var appInfoList: MutableList<AppInfo>, val appType :String, val onAppSelect :OnAppSelect
) : RecyclerView.Adapter<AppAdapter.ViewHolder>() {


    protected var textColor = activity.getProperTextColor()
    protected var backgroundColor = activity.getProperBackgroundColor()
    protected var properPrimaryColor = activity.getProperPrimaryColor()
    protected var contrastColor = properPrimaryColor.getContrastColor()

    var isMultiSelect = false
    var appDefaultList: MutableList<AppInfo>? = null

    interface OnAppSelect {
        fun onAppClick(position: Int,appInfo: AppInfo)
        fun onAppSelect(position: Int,isChecked: Boolean,appInfo: AppInfo)
    }
    init {
        appDefaultList= appInfoList
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(activity).inflate(R.layout.raw_list_of_app, parent, false))
    }

    override fun getItemCount(): Int {
        return appInfoList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        if (position != RecyclerView.NO_POSITION) {

            holder.tvTitle?.setTextColor(textColor)
            holder.tvDetail?.setTextColor(textColor)
            val appInfo = appInfoList[position]
            holder.tvTitle.text=appInfo.appName

            val size=String.format(Locale.ENGLISH, "%.2f", appInfo.appSize!!.toFloat())
            holder.tvDetail.text="$size MB, ${appInfo.installedOn}"

            val uri = appInfo.appDrawableURI
            try {
                if (uri != Uri.EMPTY)
                    Glide.with(activity)
                        .load(uri)
                        .into(holder.ivThumb)
                else {
                    val img = ContextCompat.getDrawable(activity, R.drawable.ic_apk)
                    holder.ivThumb.setImageDrawable(img)
                }
            } catch (e: Exception) {
                val img = ContextCompat.getDrawable(activity, R.drawable.ic_apk)
                holder.ivThumb.setImageDrawable(img)
            }
            holder.ivOption.setOnClickListener {
                onAppSelect.onAppClick(position,appInfo)
            }
            holder.llInfo.setOnClickListener {
                onAppSelect.onAppClick(position,appInfo)
            }

//        holder.cbSelect.isChecked = selectedPackage.contains(appInfo.appPackage)
            if(appInfoList[position].isSelected) {
                holder.cbSelect.isChecked=true
                appDefaultList!![position].isSelected = true
            } else {
                holder.cbSelect.isChecked=false
                appDefaultList!![position].isSelected = false
            }

            holder.cbSelect.setOnClickListener {
//                Log.e("AppsFragment", "onBindViewHolder-setOnClick: ${appInfo.appPackage}")
                if(holder.cbSelect.isChecked) {
                    appInfoList[position].isSelected = true
                    appDefaultList!![position].isSelected = true
                    onAppSelect.onAppSelect(position,true,appInfo)
                } else {
                    appInfoList[position].isSelected = false
                    appDefaultList!![position].isSelected = false
                    onAppSelect.onAppSelect(position,false,appInfo)
                }
            }

//            holder.ivOption.visibility=View.VISIBLE
            holder.ivDelete.visibility=View.GONE

            if(isMultiSelect) {
                holder.ivOption.visibility=View.INVISIBLE
            } else {
                holder.ivOption.visibility=View.VISIBLE
            }

            if(appType=="user") {
                holder.cbSelect.visibility=View.VISIBLE
            } else {
                holder.cbSelect.visibility=View.GONE
            }
//
//        if(countSelected()==0) {
//            holder.ivOption.visibility=View.VISIBLE
//        } else {
//            holder.ivOption.visibility=View.INVISIBLE
//        }

        }
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvTitle: TextView = itemView.findViewById(R.id.txt_name)
        val tvDetail: TextView = itemView.findViewById(R.id.tv_detail)
        val ivThumb: ImageView = itemView.findViewById(R.id.application_icon_image)
        val ivOption: ImageView = itemView.findViewById(R.id.img_arrow)
        val ivDelete: ImageView = itemView.findViewById(R.id.img_delete)
        val cbSelect: CheckBox = itemView.findViewById(R.id.cb_select)
        val llInfo: LinearLayout = itemView.findViewById(R.id.ll_info)
    }

    fun countSelected() : Int {
        return appInfoList.filter { it.isSelected }.count()
    }

    fun deSelectAll() {
        for (i in 0 until appInfoList.size) {
            appInfoList[i].isSelected=false
        }
        isMultiSelect=false
        notifyDataSetChanged()
    }

    fun updateList(items: List<AppInfo>?) {
        if (items != null) {
            if (items.isNotEmpty()) {
                appInfoList.clear()
                appInfoList.addAll(items)
                notifyDataSetChanged()
            }
        }
    }
    fun getAppList(): MutableList<AppInfo> {
//        selectedAppList.clear()
//        for(app in appInfoList) {
//            if(app.isSelected) selectedAppList.add(app)
//        }
        return appDefaultList!!
    }
}