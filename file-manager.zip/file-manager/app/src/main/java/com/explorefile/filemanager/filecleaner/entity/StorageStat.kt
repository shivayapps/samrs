package com.explorefile.filemanager.filecleaner.entity

data class StorageStat(
    val usedSize: Long,
    val availableSize: Long,
    val totalSize: Long,
)
