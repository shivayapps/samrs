package com.explorefile.filemanager.activities

import android.app.SearchManager
import android.content.Context
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.widget.SearchView
import androidx.core.view.MenuItemCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.adconfig.adsutil.admob.BannerAdHelper
import com.adconfig.adsutil.admob.NativeAdHelper
import com.adconfig.adsutil.admob.NativeLayoutType
import com.explorefile.filemanager.R
import com.explorefile.filemanager.adapters.ItemsAdapter
import com.explorefile.filemanager.adapters.MimeTypesFolderAdapter
import com.explorefile.filemanager.databinding.ActivityFilestypesBinding
import com.explorefile.filemanager.dialogs.ChangeSortingDialog
import com.explorefile.filemanager.dialogs.ChangeViewTypeDialog
import com.explorefile.filemanager.dialogs.RadioGroupDialog
import com.explorefile.filemanager.extensions.areSystemAnimationsEnabled
import com.explorefile.filemanager.extensions.beGone
import com.explorefile.filemanager.extensions.beGoneIf
import com.explorefile.filemanager.extensions.beVisible
import com.explorefile.filemanager.extensions.beVisibleIf
import com.explorefile.filemanager.extensions.config
import com.explorefile.filemanager.extensions.deleteFiles
import com.explorefile.filemanager.extensions.getLongValue
import com.explorefile.filemanager.extensions.getProperBackgroundColor
import com.explorefile.filemanager.extensions.getProperPrimaryColor
import com.explorefile.filemanager.extensions.getProperTextColor
import com.explorefile.filemanager.extensions.getStringValue
import com.explorefile.filemanager.extensions.queryCursor
import com.explorefile.filemanager.extensions.showErrorToast
import com.explorefile.filemanager.extensions.toast
import com.explorefile.filemanager.extensions.tryOpenPathIntent
import com.explorefile.filemanager.extensions.viewBinding
import com.explorefile.filemanager.helpers.APKS
import com.explorefile.filemanager.helpers.AUDIO
import com.explorefile.filemanager.helpers.AdCache
import com.explorefile.filemanager.helpers.DOCUMENTS
import com.explorefile.filemanager.helpers.DOWNLOADS
import com.explorefile.filemanager.helpers.IMAGES
import com.explorefile.filemanager.helpers.MAX_COLUMN_COUNT
import com.explorefile.filemanager.helpers.NavigationIcon
import com.explorefile.filemanager.helpers.PRIMARY_VOLUME_NAME
import com.explorefile.filemanager.helpers.SHOW_MIMETYPE
import com.explorefile.filemanager.helpers.VIDEOS
import com.explorefile.filemanager.helpers.VIEW_TYPE_GRID
import com.explorefile.filemanager.helpers.VIEW_TYPE_LIST
import com.explorefile.filemanager.helpers.VOLUME_NAME
import com.explorefile.filemanager.helpers.ensureBackgroundThread
import com.explorefile.filemanager.helpers.extraAPKMimeTypes
import com.explorefile.filemanager.helpers.extraAudioMimeTypes
import com.explorefile.filemanager.helpers.extraDocumentMimeTypes
import com.explorefile.filemanager.helpers.getListItemsFromFileDirItems
import com.explorefile.filemanager.helpers.isQPlus
import com.explorefile.filemanager.interfaces.ItemOperationsListener
import com.explorefile.filemanager.models.FileDirItem
import com.explorefile.filemanager.models.ListItem
import com.explorefile.filemanager.models.RadioItem
import com.explorefile.filemanager.views.MyGridLayoutManager
import com.explorefile.filemanager.views.MyRecyclerView
import com.google.android.gms.ads.AdView
import java.util.Locale


class FilesTypesActivity : BaseActivity(), ItemOperationsListener {
    private val binding by viewBinding(ActivityFilestypesBinding::inflate)
    private var isSearchOpen = false
    private var currentMimeType = ""
    private var lastSearchedText = ""
    private var searchMenuItem: MenuItem? = null
    private var zoomListener: MyRecyclerView.MyZoomListener? = null
    private var storedItems = ArrayList<ListItem>()
    private var currentViewType = VIEW_TYPE_LIST
    private var currentVolume = PRIMARY_VOLUME_NAME
    private var folderPath = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        isMaterialActivity = true
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        setupOptionsMenu()
        refreshMenuItems()
        binding.apply {
            updateMaterialActivityViews(
                mimetypesCoordinator,
                mimetypesList,
                useTransparentNavigation = false,
                useTopSearchMenu = false
            )
            mimetypesSwipeRefresh.setOnRefreshListener { refreshFragment() }
        }

        currentMimeType = intent.getStringExtra(SHOW_MIMETYPE) ?: return
        currentVolume = intent.getStringExtra(VOLUME_NAME) ?: currentVolume
        binding.mimetypesToolbar.title = getString(
            when (currentMimeType) {
                IMAGES -> R.string.images
                VIDEOS -> R.string.videos
                AUDIO -> R.string.audio
                DOCUMENTS -> R.string.documents
                DOWNLOADS -> R.string.downloads
                APKS -> R.string.apks
                else -> {
                    toast(R.string.unknown_error_occurred)
                    finish()
                    return
                }
            }
        )

        ensureBackgroundThread {
            reFetchItems()
        }

        binding.apply {
            mimetypesFastscroller.updateColors(getProperPrimaryColor())
            mimetypesPlaceholder.setTextColor(getProperTextColor())
            mimetypesPlaceholder2.setTextColor(getProperTextColor())
        }
    }

    var mAdView: AdView? = null
    var isAdLoaded = false
    private fun initAds() {
        val adId =getString(R.string.b_fileType)
        BannerAdHelper.showBanner(this,
            binding.frameAds,
            binding.frameAds,
            adId,
            AdCache.bannerFileType,
            { isLoaded, adView, message ->
                mAdView = adView
                AdCache.bannerFileType = adView
                isAdLoaded = isLoaded
            })
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }

    override fun onResume() {
        super.onResume()
        mAdView?.resume()
        setupToolbar(
            binding.mimetypesToolbar,
            NavigationIcon.Arrow,
            searchMenuItem = searchMenuItem
        )
        updateTopBarColors(binding.mimetypesToolbar, getProperBackgroundColor())
        binding.mimetypesSwipeRefresh.isEnabled =
            lastSearchedText.isEmpty() && config.enablePullToRefresh != false
    }

    private fun refreshMenuItems() {
        val currentViewType = config.getFolderViewType(currentMimeType)

        binding.mimetypesToolbar.menu.apply {
            findItem(R.id.toggle_filename).isVisible = currentViewType == VIEW_TYPE_GRID

            findItem(R.id.temporarily_show_hidden).isVisible = !config.shouldShowHidden()
            findItem(R.id.stop_showing_hidden).isVisible = config.temporarilyShowHidden

            findItem(R.id.column_count).isVisible = currentViewType == VIEW_TYPE_GRID
        }
    }

    private fun setupOptionsMenu() {
        setupSearch(binding.mimetypesToolbar.menu)
        binding.mimetypesToolbar.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                R.id.sort -> showSortingDialog()
                R.id.toggle_filename -> toggleFilenameVisibility()
                R.id.change_view_type -> changeViewType()
                R.id.temporarily_show_hidden -> tryToggleTemporarilyShowHidden()
                R.id.stop_showing_hidden -> tryToggleTemporarilyShowHidden()
                R.id.column_count -> changeColumnCount()
                else -> return@setOnMenuItemClickListener false
            }
            return@setOnMenuItemClickListener true
        }
    }

    private fun tryToggleTemporarilyShowHidden() {
        if (config.temporarilyShowHidden) {
            toggleTemporarilyShowHidden(false)
        } else {
            toggleTemporarilyShowHidden(true)
        }
    }

    private fun toggleTemporarilyShowHidden(show: Boolean) {
        config.temporarilyShowHidden = show
        ensureBackgroundThread {
            reFetchItems()
        }
    }

    override fun refreshFragment() {
        reFetchItems()
    }

    override fun deleteFiles(files: ArrayList<FileDirItem>) {
        deleteFiles(files, false) {
            if (!it) {
                runOnUiThread {
                    toast(R.string.unknown_error_occurred)
                }
            }
        }
    }

    override fun selectedPaths(paths: ArrayList<String>) {}

    fun searchQueryChanged(text: String) {
        val searchText = text.trim()
        lastSearchedText = searchText
        when {
            searchText.isEmpty() -> {
                binding.apply {
                    mimetypesSwipeRefresh.isEnabled =
                        text.isEmpty() && config.enablePullToRefresh != false
                    mimetypesFastscroller.beVisible()
                    getRecyclerAdapter()?.updateItems(storedItems)
                    mimetypesPlaceholder.beGoneIf(storedItems.isNotEmpty())
                    imageNoData.beGoneIf(storedItems.isNotEmpty())
                    mimetypesPlaceholder2.beGone()
                }
            }

            searchText.length == 1 -> {
                binding.apply {
                    mimetypesFastscroller.beGone()
                    mimetypesPlaceholder.beVisible()
                    imageNoData.beVisible()
                    mimetypesPlaceholder2.beVisible()
                }
            }

            else -> {
                ensureBackgroundThread {
                    if (lastSearchedText != searchText) {
                        return@ensureBackgroundThread
                    }

                    val listItems = storedItems.filter {
                        it.name.contains(
                            searchText,
                            true
                        )
                    } as ArrayList<ListItem>

                    runOnUiThread {
                        getRecyclerAdapter()?.updateItems(listItems, text)
                        binding.apply {
                            mimetypesFastscroller.beVisibleIf(listItems.isNotEmpty())
                            mimetypesPlaceholder.beVisibleIf(listItems.isEmpty())
                            imageNoData.beVisibleIf(listItems.isEmpty())
                            mimetypesPlaceholder2.beGone()
                        }
                    }
                }
            }
        }
    }

    override fun setupDateTimeFormat() {}

    override fun toggleFilenameVisibility() {
        MainActivity.onChangeToggleName = true
        config.displayFilenames = !config.displayFilenames
        getRecyclerAdapter()?.updateDisplayFilenamesInGrid()
    }

    private fun changeColumnCount() {
        val items = ArrayList<RadioItem>()
        for (i in 3..MAX_COLUMN_COUNT) {
            items.add(RadioItem(i, resources.getQuantityString(R.plurals.column_counts, i, i)))
        }

        val currentColumnCount = config.fileColumnCnt
        RadioGroupDialog(this, items, config.fileColumnCnt) {
            val newColumnCount = it as Int
            if (currentColumnCount != newColumnCount) {
                config.fileColumnCnt = newColumnCount
                columnCountChanged()
            }
        }
    }

    fun increaseColumnCount() {
        if (currentViewType == VIEW_TYPE_GRID) {
            config.fileColumnCnt += 1
            columnCountChanged()
        }
    }

    fun reduceColumnCount() {
        if (currentViewType == VIEW_TYPE_GRID) {
            config.fileColumnCnt -= 1
            columnCountChanged()
        }
    }

    override fun columnCountChanged() {
        MainActivity.onChangeColum = true
        (binding.mimetypesList.layoutManager as MyGridLayoutManager).spanCount =
            config.fileColumnCnt
        refreshMenuItems()
        getRecyclerAdapter()?.apply {
            notifyItemRangeChanged(0, listItems.size)
        }
    }

    override fun finishActMode() {}

    private fun setupSearch(menu: Menu) {
        val searchManager = getSystemService(Context.SEARCH_SERVICE) as SearchManager
        searchMenuItem = menu.findItem(R.id.search)
        (searchMenuItem!!.actionView as SearchView).apply {
            setSearchableInfo(searchManager.getSearchableInfo(componentName))
            isSubmitButtonEnabled = false
            queryHint = getString(R.string.search)
            setOnQueryTextListener(object : SearchView.OnQueryTextListener {
                override fun onQueryTextSubmit(query: String) = false

                override fun onQueryTextChange(newText: String): Boolean {
                    if (isSearchOpen) {
                        searchQueryChanged(newText)
                    }
                    return true
                }
            })
        }

        MenuItemCompat.setOnActionExpandListener(
            searchMenuItem,
            object : MenuItemCompat.OnActionExpandListener {
                override fun onMenuItemActionExpand(item: MenuItem?): Boolean {
                    isSearchOpen = true
                    searchOpened()
                    return true
                }

                override fun onMenuItemActionCollapse(item: MenuItem?): Boolean {
                    isSearchOpen = false
                    searchClosed()
                    return true
                }
            })
    }

    fun searchOpened() {
        isSearchOpen = true
        lastSearchedText = ""
    }

    fun searchClosed() {
        isSearchOpen = false
        lastSearchedText = ""
        binding.mimetypesSwipeRefresh.isEnabled = config.enablePullToRefresh != false
        searchQueryChanged("")
    }

    private fun getProperFileDirItems(callback: (ArrayList<FileDirItem>) -> Unit) {
        val fileDirItems = ArrayList<FileDirItem>()
        val showHidden = config.shouldShowHidden()

//        val uri = if (isQPlus()) {
//            MediaStore.Files.getContentUri(currentVolume)
//        } else {
            val uri = MediaStore.Files.getContentUri("external")
//        }
        
        val projection = arrayOf(
            MediaStore.Files.FileColumns.MIME_TYPE,
            MediaStore.Files.FileColumns.DATA,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.DATE_MODIFIED
        )
        try {
            queryCursor(
                uri,
                projection,
                when (currentMimeType) {
                    DOWNLOADS -> MediaStore.Files.FileColumns.DATA + " like ?"
                    else -> null
                },
                when (currentMimeType) {
                    DOWNLOADS -> arrayOf(
                        "${Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).path}%"
                    )

                    else -> null
                }
            ) { cursor ->
                try {
                    val fullMimetype =
                        cursor.getStringValue(MediaStore.Files.FileColumns.MIME_TYPE)
                            ?.lowercase(Locale.getDefault()) ?: return@queryCursor
                    val name = cursor.getStringValue(MediaStore.Files.FileColumns.DISPLAY_NAME)

                    if (name.startsWith(".trashed")) {
                        return@queryCursor
                    }

                    if (!showHidden && name.startsWith(".")) {
                        return@queryCursor
                    }

                    val size = cursor.getLongValue(MediaStore.Files.FileColumns.SIZE)
                    if (size == 0L) {
                        return@queryCursor
                    }

                    val path = cursor.getStringValue(MediaStore.Files.FileColumns.DATA)
                    val lastModified =
                        cursor.getLongValue(MediaStore.Files.FileColumns.DATE_MODIFIED) * 1000

                    val mimetype = fullMimetype.substringBefore("/")
                    when (currentMimeType) {
                        IMAGES -> {
                            if (mimetype == "image") {
                                val folderPath =
                                    path.substring(0, path.lastIndexOf("/"))
                                this.folderPath.add(folderPath)
                                fileDirItems.add(
                                    FileDirItem(
                                        path,
                                        name,
                                        false,
                                        0,
                                        size,
                                        lastModified
                                    )
                                )
                            }
                        }

                        VIDEOS -> {
                            if (mimetype == "video") {
                                val folderPath =
                                    path.substring(0, path.lastIndexOf("/"))
                                this.folderPath.add(folderPath)
                                fileDirItems.add(
                                    FileDirItem(
                                        path,
                                        name,
                                        false,
                                        0,
                                        size,
                                        lastModified
                                    )
                                )
                            }
                        }

                        AUDIO -> {
                            if (mimetype == "audio" || extraAudioMimeTypes.contains(fullMimetype)) {
                                val folderPath =
                                    path.substring(0, path.lastIndexOf("/"))
                                this.folderPath.add(folderPath)
                                fileDirItems.add(
                                    FileDirItem(
                                        path,
                                        name,
                                        false,
                                        0,
                                        size,
                                        lastModified
                                    )
                                )
                            }
                        }

                        DOCUMENTS -> {
                            if (mimetype == "text" || extraDocumentMimeTypes.contains(
                                    fullMimetype
                                )
                            ) {
                                fileDirItems.add(
                                    FileDirItem(
                                        path,
                                        name,
                                        false,
                                        0,
                                        size,
                                        lastModified
                                    )
                                )
                            }
                        }

                        DOWNLOADS -> {
                            fileDirItems.add(
                                FileDirItem(
                                    path,
                                    name,
                                    false,
                                    0,
                                    size,
                                    lastModified
                                )
                            )
                        }

                        APKS -> {
                            if (mimetype == ".apk" || extraAPKMimeTypes.contains(
                                    fullMimetype
                                )
                            ) {
                                fileDirItems.add(
                                    FileDirItem(
                                        path,
                                        name,
                                        false,
                                        0,
                                        size,
                                        lastModified
                                    )
                                )
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e("sujal", "getProperFileDirItems: ${e.message}")
                }
            }
        } catch (e: Exception) {
            showErrorToast(e)
        }
        callback(fileDirItems)
    }

    private fun addItems(items: ArrayList<ListItem>) {
        FileDirItem.sorting = config.getFolderSorting(currentMimeType)
        items.sort()
        binding.mimetypesSwipeRefresh.isRefreshing = false
        if (isDestroyed || isFinishing) {
            return
        }

        storedItems = items
        ItemsAdapter(
            this as BaseActivity,
            storedItems,
            this,
            binding.mimetypesList,
            false,
            binding.mimetypesSwipeRefresh
        ) {
            tryOpenPathIntent((it as ListItem).path, false)
        }.apply {
            setupZoomListener(zoomListener)
            binding.mimetypesList.adapter = this
        }

        if (areSystemAnimationsEnabled) {
            binding.mimetypesList.scheduleLayoutAnimation()
        }

        binding.mimetypesPlaceholder.beVisibleIf(items.isEmpty())
        binding.imageNoData.beVisibleIf(items.isEmpty())
    }

    private fun getRecyclerAdapter() = binding.mimetypesList.adapter as? ItemsAdapter

    private fun showSortingDialog() {
        ChangeSortingDialog(this, currentMimeType) {
            recreateList()
        }
    }

    private fun changeViewType() {
        if (config.viewType == VIEW_TYPE_LIST) {
            config.viewType = VIEW_TYPE_GRID
        } else {
            config.viewType = VIEW_TYPE_LIST
        }
//        ChangeViewTypeDialog(this, currentMimeType) {
            MainActivity.onChangeViewType = true
            recreateList()
            setupLayoutManager()
            refreshMenuItems()
//        }
    }

    private fun reFetchItems() {
        getProperFileDirItems { fileDirItems ->
            val listItems = getListItemsFromFileDirItems(fileDirItems)
            runOnUiThread {

                if (fileDirItems.isNotEmpty()) {
                    initAds()
                    try {
                        val arrayList = folderPath.distinct() as ArrayList<String>
                        binding.dividerGrey.beVisibleIf(arrayList.isNotEmpty())
                        binding.folderList.beVisibleIf(arrayList.isNotEmpty())
                        arrayList.add(0, "All")
                        MimeTypesFolderAdapter(this@FilesTypesActivity, arrayList) { path ->
                            if (getRecyclerAdapter()?.actModeCallback!!.isSelectable) {
                                getRecyclerAdapter()?.finishActMode()
                            }
                            if (path == "All") {
                                addItems(listItems)
                            } else {
                                addItems(listItems.filter { it.mPath.startsWith(path) } as ArrayList<ListItem>)
                            }
                        }.apply {
                            binding.folderList.adapter = this
                            binding.folderList.layoutManager =
                                LinearLayoutManager(
                                    this@FilesTypesActivity,
                                    LinearLayoutManager.HORIZONTAL,
                                    false
                                )
                        }
                    } catch (_: Exception) {

                    }
                }
                refreshMenuItems()
                addItems(listItems)
                if (currentViewType != config.getFolderViewType(currentMimeType)) {
                    setupLayoutManager()
                }
            }
        }
    }

    private fun recreateList() {
        val listItems = getRecyclerAdapter()?.listItems
        if (listItems != null) {
            addItems(listItems as ArrayList<ListItem>)
        }
    }

    private fun setupLayoutManager() {
        if (config.getFolderViewType(currentMimeType) == VIEW_TYPE_GRID) {
            currentViewType = VIEW_TYPE_GRID
            setupGridLayoutManager()
        } else {
            currentViewType = VIEW_TYPE_LIST
            setupListLayoutManager()
        }

        binding.mimetypesList.adapter = null
//        initZoomListener()
        addItems(storedItems)
    }

    private fun setupGridLayoutManager() {
        val layoutManager = binding.mimetypesList.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = config.fileColumnCnt

        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                return if (getRecyclerAdapter()?.isASectionTitle(position) == true) {
                    layoutManager.spanCount
                } else {
                    1
                }
            }
        }
    }

    private fun setupListLayoutManager() {
        val layoutManager = binding.mimetypesList.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = 1
        zoomListener = null
    }

    private fun initZoomListener() {
        if (config.getFolderViewType(currentMimeType) == VIEW_TYPE_GRID) {
            val layoutManager = binding.mimetypesList.layoutManager as MyGridLayoutManager
            zoomListener = object : MyRecyclerView.MyZoomListener {
                override fun zoomIn() {
                    if (layoutManager.spanCount > 3) {
                        reduceColumnCount()
                        getRecyclerAdapter()?.finishActMode()
                    }
                }

                override fun zoomOut() {
                    if (layoutManager.spanCount < MAX_COLUMN_COUNT) {
                        increaseColumnCount()
                        getRecyclerAdapter()?.finishActMode()
                    }
                }
            }
        } else {
            zoomListener = null
        }
    }

}
