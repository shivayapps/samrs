package com.explorefile.filemanager.helpers

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class ShortcutActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        val stringExtra = intent.getStringExtra("pkgName")
        if (stringExtra != null) {
            startActivity(packageManager.getLaunchIntentForPackage(stringExtra))
            finish()
        }
        super.onCreate(savedInstanceState)
    }
}