package com.explorefile.filemanager.dialogs

import android.app.Activity
import com.explorefile.filemanager.R
import com.explorefile.filemanager.databinding.DialogFileConflictBinding
import com.explorefile.filemanager.extensions.baseConfig
import com.explorefile.filemanager.extensions.beVisibleIf
import com.explorefile.filemanager.extensions.getAlertDialogBuilder
import com.explorefile.filemanager.extensions.setupDialogStuff
import com.explorefile.filemanager.helpers.CONFLICT_KEEP_BOTH
import com.explorefile.filemanager.helpers.CONFLICT_MERGE
import com.explorefile.filemanager.helpers.CONFLICT_OVERWRITE
import com.explorefile.filemanager.helpers.CONFLICT_SKIP

class FileConflictDialog(
    val activity: Activity, val fileDirItem: com.explorefile.filemanager.models.FileDirItem, val showApplyToAllCheckbox: Boolean,
    val callback: (resolution: Int, applyForAll: Boolean) -> Unit
) {
    val view = DialogFileConflictBinding.inflate(activity.layoutInflater, null, false)

    init {
        view.apply {
            val stringBase = if (fileDirItem.isDirectory) R.string.folder_already_exists else R.string.file_already_exists
            conflictDialogTitle.text = String.format(activity.getString(stringBase), fileDirItem.name)
            conflictDialogApplyToAll.isChecked = activity.baseConfig.lastConflictApplyToAll
            conflictDialogApplyToAll.beVisibleIf(showApplyToAllCheckbox)
            conflictDialogDivider.root.beVisibleIf(showApplyToAllCheckbox)
            conflictDialogRadioMerge.beVisibleIf(fileDirItem.isDirectory)

            val resolutionButton = when (activity.baseConfig.lastConflictResolution) {
                CONFLICT_OVERWRITE -> conflictDialogRadioOverwrite
                CONFLICT_MERGE -> conflictDialogRadioMerge
                else -> conflictDialogRadioSkip
            }
            resolutionButton.isChecked = true
        }

        activity.getAlertDialogBuilder()
            .apply {
                activity.setupDialogStuff(view.root, this){alertDialog ->
                    view.txtOk.setOnClickListener {
                        dialogConfirmed()
                        alertDialog.dismiss()
                    }
                    view.txtCancel.setOnClickListener {
                        alertDialog.dismiss()
                    }
                }
            }
    }

    private fun dialogConfirmed() {
        val resolution = when (view.conflictDialogRadioGroup.checkedRadioButtonId) {
            view.conflictDialogRadioSkip.id -> CONFLICT_SKIP
            view.conflictDialogRadioMerge.id -> CONFLICT_MERGE
            view.conflictDialogRadioKeepBoth.id -> CONFLICT_KEEP_BOTH
            else -> CONFLICT_OVERWRITE
        }

        val applyToAll = view.conflictDialogApplyToAll.isChecked
        activity.baseConfig.apply {
            lastConflictApplyToAll = applyToAll
            lastConflictResolution = resolution
        }

        callback(resolution, applyToAll)
    }
}
