package com.explorefile.filemanager.activities

import android.app.SearchManager
import android.content.Context
import android.os.Bundle
import android.provider.MediaStore
import android.view.Menu
import android.view.MenuItem
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.widget.SearchView
import androidx.core.view.MenuItemCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import com.explorefile.filemanager.R
import com.explorefile.filemanager.adapters.TrashedAdapter
import com.explorefile.filemanager.databinding.ActivityTrashedBinding
import com.explorefile.filemanager.dialogs.ChangeViewTypeDialog
import com.explorefile.filemanager.extensions.areSystemAnimationsEnabled
import com.explorefile.filemanager.extensions.beGone
import com.explorefile.filemanager.extensions.beGoneIf
import com.explorefile.filemanager.extensions.beVisible
import com.explorefile.filemanager.extensions.beVisibleIf
import com.explorefile.filemanager.extensions.config
import com.explorefile.filemanager.extensions.deleteFiles
import com.explorefile.filemanager.extensions.getLongValue
import com.explorefile.filemanager.extensions.getProperBackgroundColor
import com.explorefile.filemanager.extensions.getProperPrimaryColor
import com.explorefile.filemanager.extensions.getProperTextColor
import com.explorefile.filemanager.extensions.getStringValue
import com.explorefile.filemanager.extensions.queryCursor
import com.explorefile.filemanager.extensions.showErrorToast
import com.explorefile.filemanager.extensions.toast
import com.explorefile.filemanager.extensions.tryOpenPathIntent
import com.explorefile.filemanager.extensions.viewBinding
import com.explorefile.filemanager.helpers.MAX_COLUMN_COUNT
import com.explorefile.filemanager.helpers.NavigationIcon
import com.explorefile.filemanager.helpers.PRIMARY_VOLUME_NAME
import com.explorefile.filemanager.helpers.VIEW_TYPE_GRID
import com.explorefile.filemanager.helpers.VIEW_TYPE_LIST
import com.explorefile.filemanager.helpers.ensureBackgroundThread
import com.explorefile.filemanager.helpers.getListItemsFromFileDirItems
import com.explorefile.filemanager.helpers.isQPlus
import com.explorefile.filemanager.interfaces.ItemOperationsListener
import com.explorefile.filemanager.models.FileDirItem
import com.explorefile.filemanager.models.ListItem
import com.explorefile.filemanager.views.MyGridLayoutManager
import com.explorefile.filemanager.views.MyRecyclerView

class TrashedActivity : BaseActivity(), ItemOperationsListener {
    private val binding by viewBinding(ActivityTrashedBinding::inflate)
    private var isSearchOpen = false
    private var lastSearchedText = ""
    private var searchMenuItem: MenuItem? = null
    private var zoomListener: MyRecyclerView.MyZoomListener? = null
    private var storedItems = ArrayList<ListItem>()
    private var currentViewType = VIEW_TYPE_LIST
    private var currentVolume = PRIMARY_VOLUME_NAME

    override fun onCreate(savedInstanceState: Bundle?) {
        isMaterialActivity = true
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        setupOptionsMenu()
        binding.apply {
            updateMaterialActivityViews(
                trashedCoordinator,
                trashedList,
                useTransparentNavigation = true,
                useTopSearchMenu = false
            )
            mimetypesSwipeRefresh.setOnRefreshListener { refreshFragment() }
        }

        binding.trashedToolbar.title = getString(R.string.trashed)

        ensureBackgroundThread {
            reFetchItems()
        }

        binding.apply {
            trashedFastscroller.updateColors(getProperPrimaryColor())
            trashedPlaceholder.setTextColor(getProperTextColor())
            trashedPlaceholder2.setTextColor(getProperTextColor())
        }
    }

    override fun onResume() {
        super.onResume()
        setupToolbar(
            binding.trashedToolbar,
            NavigationIcon.Arrow,
            searchMenuItem = searchMenuItem
        )
        updateTopBarColors(binding.trashedToolbar, getProperBackgroundColor())
        binding.mimetypesSwipeRefresh.isEnabled = lastSearchedText.isEmpty() && config.enablePullToRefresh != false
    }


    private fun setupOptionsMenu() {
        setupSearch(binding.trashedToolbar.menu)
        binding.trashedToolbar.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                R.id.change_view_type -> changeViewType()
                else -> return@setOnMenuItemClickListener false
            }
            return@setOnMenuItemClickListener true
        }
    }

    override fun refreshFragment() {
        reFetchItems()
    }

    override fun deleteFiles(files: ArrayList<FileDirItem>) {
        deleteFiles(files, false) {
            if (!it) {
                runOnUiThread {
                    toast(R.string.unknown_error_occurred)
                }
            }
        }
    }

    override fun selectedPaths(paths: ArrayList<String>) {}

    fun searchQueryChanged(text: String) {
        val searchText = text.trim()
        lastSearchedText = searchText
        when {
            searchText.isEmpty() -> {
                binding.apply {
                    mimetypesSwipeRefresh.isEnabled =
                        text.isEmpty() && config.enablePullToRefresh != false
                    trashedFastscroller.beVisible()
                    getRecyclerAdapter()?.updateItems(storedItems)
                    trashedPlaceholder.beGoneIf(storedItems.isNotEmpty())
                    imageNoData.beGoneIf(storedItems.isNotEmpty())
                    trashedPlaceholder2.beGone()
                }
            }

            searchText.length == 1 -> {
                binding.apply {
                    trashedFastscroller.beGone()
                    trashedPlaceholder.beVisible()
                    imageNoData.beVisible()
                    trashedPlaceholder2.beVisible()
                }
            }

            else -> {
                ensureBackgroundThread {
                    if (lastSearchedText != searchText) {
                        return@ensureBackgroundThread
                    }

                    val listItems = storedItems.filter {
                        it.name.contains(
                            searchText,
                            true
                        )
                    } as ArrayList<ListItem>

                    runOnUiThread {
                        getRecyclerAdapter()?.updateItems(listItems, text)
                        binding.apply {
                            trashedFastscroller.beVisibleIf(listItems.isNotEmpty())
                            trashedPlaceholder.beVisibleIf(listItems.isEmpty())
                            imageNoData.beVisibleIf(listItems.isEmpty())
                            trashedPlaceholder2.beGone()
                        }
                    }
                }
            }
        }
    }

    override fun setupDateTimeFormat() {}

    override fun toggleFilenameVisibility() {
        config.displayFilenames = !config.displayFilenames
        getRecyclerAdapter()?.updateDisplayFilenamesInGrid()
    }

    fun increaseColumnCount() {
        if (currentViewType == VIEW_TYPE_GRID) {
            config.fileColumnCnt += 1
            columnCountChanged()
        }
    }

    fun reduceColumnCount() {
        if (currentViewType == VIEW_TYPE_GRID) {
            config.fileColumnCnt -= 1
            columnCountChanged()
        }
    }

    override fun columnCountChanged() {
        MainActivity.onChangeColum = true
        (binding.trashedList.layoutManager as MyGridLayoutManager).spanCount =
            config.fileColumnCnt
        getRecyclerAdapter()?.apply {
            notifyItemRangeChanged(0, listItems.size)
        }
    }

    override fun finishActMode() {}

    private fun setupSearch(menu: Menu) {
        val searchManager = getSystemService(Context.SEARCH_SERVICE) as SearchManager
        searchMenuItem = menu.findItem(R.id.search)
        (searchMenuItem!!.actionView as SearchView).apply {
            setSearchableInfo(searchManager.getSearchableInfo(componentName))
            isSubmitButtonEnabled = false
            queryHint = getString(R.string.search)
            setOnQueryTextListener(object : SearchView.OnQueryTextListener {
                override fun onQueryTextSubmit(query: String) = false

                override fun onQueryTextChange(newText: String): Boolean {
                    if (isSearchOpen) {
                        searchQueryChanged(newText)
                    }
                    return true
                }
            })
        }

        MenuItemCompat.setOnActionExpandListener(
            searchMenuItem,
            object : MenuItemCompat.OnActionExpandListener {
                override fun onMenuItemActionExpand(item: MenuItem?): Boolean {
                    isSearchOpen = true
                    searchOpened()
                    return true
                }

                override fun onMenuItemActionCollapse(item: MenuItem?): Boolean {
                    isSearchOpen = false
                    searchClosed()
                    return true
                }
            })
    }


    fun searchOpened() {
        isSearchOpen = true
        lastSearchedText = ""
    }

    fun searchClosed() {
        isSearchOpen = false
        lastSearchedText = ""
        binding.mimetypesSwipeRefresh.isEnabled = config.enablePullToRefresh != false
        searchQueryChanged("")
    }

    private fun getProperFileDirItems(callback: (ArrayList<FileDirItem>) -> Unit) {
        val fileDirItems = ArrayList<FileDirItem>()

        val uri = if (isQPlus()) {
            MediaStore.Files.getContentUri(currentVolume)
        } else {
            MediaStore.Files.getContentUri("external")
        }

        val projection = arrayOf(
            MediaStore.Files.FileColumns.MIME_TYPE,
            MediaStore.Files.FileColumns.DATA,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.DATE_MODIFIED
        )

        try {
            queryCursor(
                uri,
                projection
            ) { cursor ->
                try {
                    val name = cursor.getStringValue(MediaStore.Files.FileColumns.DISPLAY_NAME)

                    if (!name.startsWith(".trashed")) {
                        return@queryCursor
                    }

                    val size = cursor.getLongValue(MediaStore.Files.FileColumns.SIZE)
                    if (size == 0L) {
                        return@queryCursor
                    }

                    val path = cursor.getStringValue(MediaStore.Files.FileColumns.DATA)

                    val lastModified =
                        cursor.getLongValue(MediaStore.Files.FileColumns.DATE_MODIFIED) * 1000

                    fileDirItems.add(
                        FileDirItem(
                            path,
                            name,
                            false,
                            0,
                            size,
                            lastModified
                        )
                    )

                } catch (_: Exception) {
                }
            }
        } catch (e: Exception) {
            showErrorToast(e)
        }
        callback(fileDirItems)
    }

    private fun addItems(items: ArrayList<ListItem>) {
        FileDirItem.sorting = config.getFolderSorting(currentVolume)
        items.sort()
        binding.mimetypesSwipeRefresh.isRefreshing = false
        if (isDestroyed || isFinishing) {
            return
        }

        storedItems = items
        TrashedAdapter(
            this as BaseActivity,
            storedItems,
            this,
            binding.trashedList,
            binding.mimetypesSwipeRefresh
        ) {
            tryOpenPathIntent((it as ListItem).path, false)
        }.apply {
            setupZoomListener(zoomListener)
            binding.trashedList.adapter = this
        }

        if (areSystemAnimationsEnabled) {
            binding.trashedList.scheduleLayoutAnimation()
        }

        binding.trashedPlaceholder.beVisibleIf(items.isEmpty())
        binding.imageNoData.beVisibleIf(items.isEmpty())
    }

    private fun getRecyclerAdapter() = binding.trashedList.adapter as? TrashedAdapter

    private fun changeViewType() {

        if (config.viewType == VIEW_TYPE_LIST) {
            config.viewType = VIEW_TYPE_GRID
        } else {
            config.viewType = VIEW_TYPE_LIST
        }
//        ChangeViewTypeDialog(this, currentVolume) {
            recreateList()
            setupLayoutManager()
//        }
    }

    private fun reFetchItems() {
        getProperFileDirItems { fileDirItems ->
            val listItems = getListItemsFromFileDirItems(fileDirItems)
            runOnUiThread {
                addItems(listItems)
                if (currentViewType != config.getFolderViewType(currentVolume)) {
                    setupLayoutManager()
                }
            }
        }
    }

    private fun recreateList() {
        val listItems = getRecyclerAdapter()?.listItems
        if (listItems != null) {
            addItems(listItems as ArrayList<ListItem>)
        }
    }

    private fun setupLayoutManager() {
        if (config.getFolderViewType(currentVolume) == VIEW_TYPE_GRID) {
            currentViewType = VIEW_TYPE_GRID
            setupGridLayoutManager()
        } else {
            currentViewType = VIEW_TYPE_LIST
            setupListLayoutManager()
        }

        binding.trashedList.adapter = null
//        initZoomListener()
        addItems(storedItems)
    }

    private fun setupGridLayoutManager() {
        val layoutManager = binding.trashedList.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = config.fileColumnCnt

        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                return if (getRecyclerAdapter()?.isASectionTitle(position) == true) {
                    layoutManager.spanCount
                } else {
                    1
                }
            }
        }
    }

    private fun setupListLayoutManager() {
        val layoutManager = binding.trashedList.layoutManager as MyGridLayoutManager
        layoutManager.spanCount = 1
        zoomListener = null
    }

    private fun initZoomListener() {
        if (config.getFolderViewType(currentVolume) == VIEW_TYPE_GRID) {
            val layoutManager = binding.trashedList.layoutManager as MyGridLayoutManager
            zoomListener = object : MyRecyclerView.MyZoomListener {
                override fun zoomIn() {
                    if (layoutManager.spanCount > 3) {
                        reduceColumnCount()
                        getRecyclerAdapter()?.finishActMode()
                    }
                }

                override fun zoomOut() {
                    if (layoutManager.spanCount < MAX_COLUMN_COUNT) {
                        increaseColumnCount()
                        getRecyclerAdapter()?.finishActMode()
                    }
                }
            }
        } else {
            zoomListener = null
        }
    }
}