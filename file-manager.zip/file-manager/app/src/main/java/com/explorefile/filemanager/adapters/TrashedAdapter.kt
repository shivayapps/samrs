package com.explorefile.filemanager.adapters

import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.viewbinding.ViewBinding
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.resource.bitmap.CenterCrop
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.RequestOptions
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.BaseActivity
import com.explorefile.filemanager.activities.MainActivity
import com.explorefile.filemanager.databinding.ItemDirGridBinding
import com.explorefile.filemanager.databinding.ItemEmptyBinding
import com.explorefile.filemanager.databinding.ItemFileDirListBinding
import com.explorefile.filemanager.databinding.ItemFileGridBinding
import com.explorefile.filemanager.databinding.ItemSectionBinding
import com.explorefile.filemanager.dialogs.ConfirmationDialog
import com.explorefile.filemanager.dialogs.PropertiesDialog
import com.explorefile.filemanager.extensions.beVisible
import com.explorefile.filemanager.extensions.beVisibleIf
import com.explorefile.filemanager.extensions.config
import com.explorefile.filemanager.extensions.dp
import com.explorefile.filemanager.extensions.formatDate
import com.explorefile.filemanager.extensions.formatSize
import com.explorefile.filemanager.extensions.getAndroidSAFUri
import com.explorefile.filemanager.extensions.getColoredDrawableWithColor
import com.explorefile.filemanager.extensions.getFilenameFromPath
import com.explorefile.filemanager.extensions.getParentPath
import com.explorefile.filemanager.extensions.getTimeFormat
import com.explorefile.filemanager.extensions.hasOTGConnected
import com.explorefile.filemanager.extensions.highlightTextPart
import com.explorefile.filemanager.extensions.isImageFast
import com.explorefile.filemanager.extensions.isPathOnOTG
import com.explorefile.filemanager.extensions.isPathOnRoot
import com.explorefile.filemanager.extensions.isRestrictedSAFOnlyRoot
import com.explorefile.filemanager.extensions.isVideoFast
import com.explorefile.filemanager.extensions.setupViewBackground
import com.explorefile.filemanager.extensions.toast
import com.explorefile.filemanager.extensions.toggleItemVisibility
import com.explorefile.filemanager.helpers.VIEW_TYPE_LIST
import com.explorefile.filemanager.helpers.ensureBackgroundThread
import com.explorefile.filemanager.helpers.getFilePlaceholderDrawables
import com.explorefile.filemanager.interfaces.ItemOperationsListener
import com.explorefile.filemanager.models.FileDirItem
import com.explorefile.filemanager.models.ListItem
import com.explorefile.filemanager.views.MyRecyclerView
import com.explorefile.views.RecyclerViewFastScroller
import com.stericson.RootTools.RootTools

class TrashedAdapter(
    activity: BaseActivity,
    var listItems: MutableList<ListItem>,
    val listener: ItemOperationsListener?,
    recyclerView: MyRecyclerView,
    val swipeRefreshLayout: SwipeRefreshLayout?,
    canHaveIndividualViewType: Boolean = true,
    itemClick: (Any) -> Unit
) : MyRecyclerViewAdapter(activity, recyclerView, itemClick),
    RecyclerViewFastScroller.OnPopupTextUpdate {

    private lateinit var fileDrawable: Drawable
    private lateinit var folderDrawable: Drawable
    private var fileDrawables = HashMap<String, Drawable>()
    private var currentItemsHash = listItems.hashCode()
    private var textToHighlight = ""
    private val hasOTGConnected = activity.hasOTGConnected()
    private var dateFormat = ""
    private var timeFormat = ""

    val layoutParams = RelativeLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.MATCH_PARENT
    )

    val layoutListParams = RelativeLayout.LayoutParams(
        26.dp,
        26.dp
    )

    val layoutGridParams = RelativeLayout.LayoutParams(
        40.dp,
        40.dp
    )

    private val config = activity.config

    private val viewType = if (canHaveIndividualViewType) {
        config.getFolderViewType(
            listItems.firstOrNull { !it.isSectionTitle }?.mPath?.getParentPath() ?: ""
        )
    } else {
        config.viewType
    }

    private val isListViewType = viewType == VIEW_TYPE_LIST
    private var displayFilenamesInGrid = config.displayFilenames

    companion object {
        private const val TYPE_FILE = 1
        private const val TYPE_DIR = 2
        private const val TYPE_SECTION = 3
        private const val TYPE_GRID_TYPE_DIVIDER = 4
    }

    init {
        setupDragListener(true)
        initDrawables()
        updateFontSizes()
        dateFormat = config.dateFormat
        timeFormat = activity.getTimeFormat()
    }

    override fun getActionMenuId() = R.menu.cab_trashed

    override fun prepareActionMode(menu: Menu) {
        menu.apply {
            findItem(R.id.cab_select_all).isVisible = getSelectableItemCount() != selectedKeys.size
            findItem(R.id.cab_select).isVisible = getSelectableItemCount() == selectedKeys.size
        }
    }

    override fun actionItemPressed(id: Int) {
        if (selectedKeys.isEmpty()) {
            return
        }

        when (id) {
            R.id.cab_properties -> showProperties()
            R.id.cab_select_all -> selectAll()
            R.id.cab_select -> finishActMode()
            R.id.cab_recover -> toggleFileVisibility(false)
            R.id.cab_delete -> if (config.skipDeleteConfirmation) deleteFiles() else askConfirmDelete()
        }
    }

    override fun getSelectableItemCount() =
        listItems.filter { !it.isSectionTitle && !it.isGridTypeDivider }.size

    override fun getIsItemSelectable(position: Int) =
        !listItems[position].isSectionTitle && !listItems[position].isGridTypeDivider

    override fun getItemSelectionKey(position: Int) =
        listItems.getOrNull(position)?.path?.hashCode()

    override fun getItemKeyPosition(key: Int) = listItems.indexOfFirst { it.path.hashCode() == key }

    override fun onActionModeCreated() {
        swipeRefreshLayout?.isRefreshing = false
        swipeRefreshLayout?.isEnabled = false
    }

    override fun onActionModeDestroyed() {
        swipeRefreshLayout?.isEnabled = true
    }

    override fun getItemViewType(position: Int): Int {
        return when {
            listItems[position].isGridTypeDivider -> TYPE_GRID_TYPE_DIVIDER
            listItems[position].isSectionTitle -> TYPE_SECTION
            listItems[position].mIsDirectory -> TYPE_DIR
            else -> TYPE_FILE
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = Binding.getByItemViewType(viewType, isListViewType)
            .inflate(layoutInflater, parent, false)

        return createViewHolder(binding.root)
    }

    override fun onBindViewHolder(holder: MyRecyclerViewAdapter.ViewHolder, position: Int) {
        val fileDirItem = listItems[position]
        holder.bindView(
            fileDirItem,
            true,
            !fileDirItem.isSectionTitle
        ) { itemView, layoutPosition ->
            val viewType = getItemViewType(position)
            setupView(
                Binding.getByItemViewType(viewType, isListViewType).bind(itemView),
                fileDirItem
            )
        }
        bindViewHolder(holder)
    }

    override fun getItemCount() = listItems.size

    private fun showProperties() {
        if (selectedKeys.size <= 1) {
            PropertiesDialog(activity, getFirstSelectedItemPath(), config.shouldShowHidden())
        } else {
            val paths = getSelectedFileDirItems().map { it.path }
            PropertiesDialog(activity, paths, config.shouldShowHidden())
        }
    }

    private fun toggleFileVisibility(hide: Boolean) {
        ensureBackgroundThread {
            getSelectedFileDirItems().forEach {
                activity.toggleItemVisibility(it.path, hide)
            }
            activity.runOnUiThread {
                listener?.refreshFragment()
                MainActivity.itemMoment = true
                finishActMode()
            }
        }
    }


    private fun askConfirmDelete() {
        val itemsCnt = selectedKeys.size
        val items = if (itemsCnt == 1) {
            "\"${getFirstSelectedItemPath().getFilenameFromPath()}\""
        } else {
            resources.getQuantityString(R.plurals.delete_items, itemsCnt, itemsCnt)
        }

        val question = String.format(resources.getString(R.string.deletion_confirmation), items)
        ConfirmationDialog(activity, question) {
            deleteFiles()
        }
    }

    private fun deleteFiles() {
        if (selectedKeys.isEmpty()) {
            return
        }

        val SAFPath = getFirstSelectedItemPath()
        if (activity.isPathOnRoot(SAFPath) && !RootTools.isRootAvailable()) {
            activity.toast(R.string.rooted_device_only)
            return
        }

        activity.handleSAFDialog(SAFPath) {
            if (!it) {
                return@handleSAFDialog
            }

            val files = ArrayList<FileDirItem>(selectedKeys.size)
            val positions = ArrayList<Int>()
            selectedKeys.forEach {
                val key = it
                val position = listItems.indexOfFirst { it.path.hashCode() == key }
                if (position != -1) {
                    positions.add(position)
                    files.add(listItems[position])
                }
            }

            positions.sortDescending()
            removeSelectedItems(positions)
            listener?.deleteFiles(files)
            positions.forEach {
                listItems.removeAt(it)
            }
        }
    }

    private fun getFirstSelectedItemPath() = getSelectedFileDirItems().first().path

    private fun getSelectedFileDirItems() =
        listItems.filter { selectedKeys.contains(it.path.hashCode()) } as ArrayList<FileDirItem>

    fun updateItems(newItems: ArrayList<ListItem>, highlightText: String = "") {
        if (newItems.hashCode() != currentItemsHash) {
            currentItemsHash = newItems.hashCode()
            textToHighlight = highlightText
            listItems = newItems.clone() as ArrayList<ListItem>
            notifyDataSetChanged()
            finishActMode()
        } else if (textToHighlight != highlightText) {
            textToHighlight = highlightText
            notifyDataSetChanged()
        }
    }

    fun updateFontSizes() {
        notifyDataSetChanged()
    }

    fun updateDisplayFilenamesInGrid() {
        displayFilenamesInGrid = config.displayFilenames
        notifyDataSetChanged()
    }

    fun isASectionTitle(position: Int) = listItems.getOrNull(position)?.isSectionTitle ?: false

    override fun onViewRecycled(holder: ViewHolder) {
        super.onViewRecycled(holder)
        if (!activity.isDestroyed && !activity.isFinishing) {
            val icon = Binding.getByItemViewType(holder.itemViewType, isListViewType)
                .bind(holder.itemView).itemIcon
            if (icon != null) {
                Glide.with(activity).clear(icon)
            }
        }
    }

    private fun setupView(binding: ItemViewBinding, listItem: ListItem) {
        val isSelected = selectedKeys.contains(listItem.path.hashCode())
        binding.apply {
            if (listItem.isSectionTitle) {
                itemIcon?.setImageDrawable(folderDrawable)
                itemSection?.text =
                    if (textToHighlight.isEmpty()) listItem.mName else listItem.mName.highlightTextPart(
                        textToHighlight,
                        properPrimaryColor
                    )
                itemSection?.setTextColor(textColor)
            } else if (!listItem.isGridTypeDivider) {
                root.setupViewBackground(activity)
                val fileName = listItem.name
                itemName?.text =
                    if (textToHighlight.isEmpty()) fileName.substring(
                        9,
                        fileName.length
                    ) else fileName.substring(9, fileName.length).highlightTextPart(
                        textToHighlight,
                        properPrimaryColor
                    )
                itemName?.setTextColor(textColor)
                itemDetails?.setTextColor(textColor)
                itemDate?.setTextColor(textColor)
                itemLine?.setTextColor(textColor)

                itemCheck?.beVisibleIf(actModeCallback.isSelectable)
                if (isSelected) {
                    itemCheck?.beVisible()
                    itemCheck?.setImageDrawable(activity.getDrawable(R.drawable.ic_check_select_vector))
                } else {
                    itemCheck?.setImageDrawable(activity.getDrawable(R.drawable.circle_background))
                }

                if (!isListViewType && !listItem.isDirectory) {
                    itemName?.beVisibleIf(displayFilenamesInGrid)
                } else {
                    itemName?.beVisible()
                }

                if (listItem.isDirectory) {
                    itemIcon?.setImageDrawable(folderDrawable)
                    itemDetails?.text = getChildrenCnt(listItem)
                    itemDate?.text = listItem.modified.formatDate(activity, dateFormat, timeFormat)
                } else {
                    itemDetails?.text = listItem.size.formatSize()
                    itemDate?.beVisible()
                    itemDate?.text = listItem.modified.formatDate(activity, dateFormat, timeFormat)

                    val drawable = fileDrawables.getOrElse(
                        fileName.substringAfterLast(".").toLowerCase()
                    ) { fileDrawable }
                    val options = RequestOptions()
                        .signature(listItem.getKey())
                        .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                        .error(drawable)
                        .transform(CenterCrop(), RoundedCorners(10))

                    if (listItem.path.isImageFast()) {
                        itemIcon?.layoutParams = layoutParams
                    } else if (listItem.path.isVideoFast()) {
                        itemIcon?.layoutParams = layoutParams
                    } else {
                        if (isListViewType) {
                            itemIcon?.layoutParams = layoutListParams
                        } else {
                            itemIcon?.layoutParams = layoutGridParams
                        }
                    }
                    val itemToLoad = getImagePathToLoad(listItem.path)
                    if (!activity.isDestroyed && itemIcon != null) {
                        Glide.with(activity)
                            .load(itemToLoad)
                            .transition(DrawableTransitionOptions.withCrossFade())
                            .apply(options)
                            .into(itemIcon!!)
                    }
                }
            }
        }
    }

    private fun getChildrenCnt(item: FileDirItem): String {
        val children = item.children
        return activity.resources.getQuantityString(R.plurals.items, children, children)
    }

    private fun getOTGPublicPath(itemToLoad: String) =
        "${baseConfig.OTGTreeUri}/document/${baseConfig.OTGPartition}%3A${
            itemToLoad.substring(
                baseConfig.OTGPath.length
            ).replace("/", "%2F")
        }"

    private fun getImagePathToLoad(path: String): Any {
        var itemToLoad = if (path.endsWith(".apk", true)) {
            val packageInfo =
                activity.packageManager.getPackageArchiveInfo(path, PackageManager.GET_ACTIVITIES)
            if (packageInfo != null) {
                val appInfo = packageInfo.applicationInfo
                appInfo?.sourceDir = path
                appInfo?.publicSourceDir = path
                appInfo?.loadIcon(activity.packageManager)
            } else {
                path
            }
        } else {
            path
        }

        if (activity.isRestrictedSAFOnlyRoot(path)) {
            itemToLoad = activity.getAndroidSAFUri(path)
        } else if (hasOTGConnected && itemToLoad is String && activity.isPathOnOTG(itemToLoad) && baseConfig.OTGTreeUri.isNotEmpty() && baseConfig.OTGPartition.isNotEmpty()) {
            itemToLoad = getOTGPublicPath(itemToLoad)
        }

        return itemToLoad!!
    }

    fun initDrawables() {
        folderDrawable =
            resources.getColoredDrawableWithColor(R.drawable.ic_folder_vector, textColor)
        fileDrawable = resources.getDrawable(R.drawable.ic_file_generic)
        fileDrawables = getFilePlaceholderDrawables(activity)
    }

    override fun onChange(position: Int) =
        listItems.getOrNull(position)?.getBubbleText(activity, dateFormat, timeFormat) ?: ""

    private sealed interface Binding {
        companion object {
            fun getByItemViewType(viewType: Int, isListViewType: Boolean): Binding {
                return when (viewType) {
                    TYPE_SECTION -> ItemSection
                    TYPE_GRID_TYPE_DIVIDER -> ItemEmpty
                    else -> {
                        if (isListViewType) {
                            ItemFileDirList
                        } else if (viewType == TYPE_DIR) {
                            ItemDirGrid
                        } else {
                            ItemFileGrid
                        }
                    }
                }
            }
        }

        fun inflate(
            layoutInflater: LayoutInflater,
            viewGroup: ViewGroup,
            attachToRoot: Boolean
        ): ItemViewBinding

        fun bind(view: View): ItemViewBinding

        data object ItemSection : Binding {
            override fun inflate(
                layoutInflater: LayoutInflater,
                viewGroup: ViewGroup,
                attachToRoot: Boolean
            ): ItemViewBinding {
                return ItemSectionBindingAdapter(
                    ItemSectionBinding.inflate(
                        layoutInflater,
                        viewGroup,
                        attachToRoot
                    )
                )
            }

            override fun bind(view: View): ItemViewBinding {
                return ItemSectionBindingAdapter(ItemSectionBinding.bind(view))
            }
        }

        data object ItemEmpty : Binding {
            override fun inflate(
                layoutInflater: LayoutInflater,
                viewGroup: ViewGroup,
                attachToRoot: Boolean
            ): ItemViewBinding {
                return ItemEmptyBindingAdapter(
                    ItemEmptyBinding.inflate(
                        layoutInflater,
                        viewGroup,
                        attachToRoot
                    )
                )
            }

            override fun bind(view: View): ItemViewBinding {
                return ItemEmptyBindingAdapter(ItemEmptyBinding.bind(view))
            }
        }

        data object ItemFileDirList : Binding {
            override fun inflate(
                layoutInflater: LayoutInflater,
                viewGroup: ViewGroup,
                attachToRoot: Boolean
            ): ItemViewBinding {
                return ItemFileDirListBindingAdapter(
                    ItemFileDirListBinding.inflate(
                        layoutInflater,
                        viewGroup,
                        attachToRoot
                    )
                )
            }

            override fun bind(view: View): ItemViewBinding {
                return ItemFileDirListBindingAdapter(ItemFileDirListBinding.bind(view))
            }
        }

        data object ItemDirGrid : Binding {
            override fun inflate(
                layoutInflater: LayoutInflater,
                viewGroup: ViewGroup,
                attachToRoot: Boolean
            ): ItemViewBinding {
                return ItemDirGridBindingAdapter(
                    ItemDirGridBinding.inflate(
                        layoutInflater,
                        viewGroup,
                        attachToRoot
                    )
                )
            }

            override fun bind(view: View): ItemViewBinding {
                return ItemDirGridBindingAdapter(ItemDirGridBinding.bind(view))
            }
        }

        data object ItemFileGrid : Binding {
            override fun inflate(
                layoutInflater: LayoutInflater,
                viewGroup: ViewGroup,
                attachToRoot: Boolean
            ): ItemViewBinding {
                return ItemFileGridBindingAdapter(
                    ItemFileGridBinding.inflate(
                        layoutInflater,
                        viewGroup,
                        attachToRoot
                    )
                )
            }

            override fun bind(view: View): ItemViewBinding {
                return ItemFileGridBindingAdapter(ItemFileGridBinding.bind(view))
            }
        }
    }

    private interface ItemViewBinding : ViewBinding {
        val itemFrame: FrameLayout
        val itemName: TextView?
        val itemGg: RelativeLayout?
        val itemIcon: ImageView?
        val itemCheck: ImageView?
        val itemDetails: TextView?
        val itemDate: TextView?
        val itemLine: TextView?
        val itemSection: TextView?
    }

    private class ItemSectionBindingAdapter(val binding: ItemSectionBinding) : ItemViewBinding {
        override val itemFrame: FrameLayout = binding.itemFrame
        override val itemName: TextView? = null
        override val itemGg: RelativeLayout = binding.itemBg
        override val itemIcon: ImageView = binding.itemIcon
        override val itemDetails: TextView? = null
        override val itemDate: TextView? = null
        override val itemLine: TextView? = null
        override val itemCheck: ImageView = binding.itemCheck
        override val itemSection: TextView = binding.itemSection
        override fun getRoot(): View = binding.root
    }

    private class ItemEmptyBindingAdapter(val binding: ItemEmptyBinding) : ItemViewBinding {
        override val itemFrame: FrameLayout = binding.itemFrame
        override val itemName: TextView? = null
        override val itemGg: RelativeLayout? = null
        override val itemIcon: ImageView? = null
        override val itemDetails: TextView? = null
        override val itemDate: TextView? = null
        override val itemLine: TextView? = null
        override val itemCheck: ImageView? = null
        override val itemSection: TextView? = null

        override fun getRoot(): View = binding.root
    }

    private class ItemFileDirListBindingAdapter(val binding: ItemFileDirListBinding) :
        ItemViewBinding {
        override val itemFrame: FrameLayout = binding.itemFrame
        override val itemName: TextView = binding.itemName
        override val itemGg: RelativeLayout = binding.itemBg
        override val itemIcon: ImageView = binding.itemIcon
        override val itemDetails: TextView = binding.itemDetails
        override val itemDate: TextView = binding.itemDate
        override val itemLine: TextView = binding.itemLine
        override val itemCheck: ImageView = binding.itemCheck
        override val itemSection: TextView? = null

        override fun getRoot(): View = binding.root
    }

    private class ItemDirGridBindingAdapter(val binding: ItemDirGridBinding) : ItemViewBinding {
        override val itemFrame: FrameLayout = binding.itemFrame
        override val itemName: TextView = binding.itemName
        override val itemGg: RelativeLayout = binding.itemBg
        override val itemIcon: ImageView = binding.itemIcon
        override val itemDetails: TextView? = null
        override val itemDate: TextView? = null
        override val itemLine: TextView? = null
        override val itemCheck: ImageView = binding.itemCheck
        override val itemSection: TextView? = null

        override fun getRoot(): View = binding.root
    }

    private class ItemFileGridBindingAdapter(val binding: ItemFileGridBinding) : ItemViewBinding {
        override val itemFrame: FrameLayout = binding.itemFrame
        override val itemName: TextView = binding.itemName
        override val itemGg: RelativeLayout = binding.itemBg
        override val itemIcon: ImageView = binding.itemIcon
        override val itemDetails: TextView? = null
        override val itemDate: TextView? = null
        override val itemLine: TextView? = null
        override val itemCheck: ImageView = binding.itemCheck
        override val itemSection: TextView? = null

        override fun getRoot(): View = binding.root
    }
}
