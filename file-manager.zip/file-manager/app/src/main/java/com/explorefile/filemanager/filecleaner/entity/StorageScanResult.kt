package com.explorefile.filemanager.filecleaner.entity

data class StorageScanResult(
    var stat: StorageStat? = null,
    var file: FileScanResultSummary? = null,
    var other: Long? = null
) {

    fun calcOtherSizeIfCan() {
        val storageStat = this.stat
        val fileScanResultSummary = this.file
        if (storageStat != null && fileScanResultSummary != null) {
            other = storageStat.usedSize -
                    fileScanResultSummary.image.queueSize.get() -
                    fileScanResultSummary.video.queueSize.get() -
                    fileScanResultSummary.audio.queueSize.get() -
                    fileScanResultSummary.document.queueSize.get() -
                    fileScanResultSummary.apkFile.queueSize.get() -
                    fileScanResultSummary.compressedFile.queueSize.get() -
                    fileScanResultSummary.emptyDir.queueSize.get() -
                    fileScanResultSummary.noExt.queueSize.get() -
                    fileScanResultSummary.unknownExt.queueSize.get()
        }
    }

}
