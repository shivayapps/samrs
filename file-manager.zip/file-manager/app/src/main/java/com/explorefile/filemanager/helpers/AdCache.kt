package com.explorefile.filemanager.helpers

import com.google.android.gms.ads.AdView

class AdCache {
    companion object {
        var bannerMain:AdView?=null
        var bannerFileType:AdView?=null

    }
}


