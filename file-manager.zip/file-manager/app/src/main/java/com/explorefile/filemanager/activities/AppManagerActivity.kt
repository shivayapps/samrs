package com.explorefile.filemanager.activities

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.viewpager.widget.ViewPager
import com.adconfig.AdsConfig
import com.explorefile.filemanager.R
import com.explorefile.filemanager.databinding.ActivityAppManagerBinding
import com.explorefile.filemanager.dialogs.FilePickerDialog
import com.explorefile.filemanager.extensions.config
import com.explorefile.filemanager.extensions.getDocumentFile
import com.explorefile.filemanager.extensions.getDoesFilePathExist
import com.explorefile.filemanager.extensions.getFileOutputStreamSync
import com.explorefile.filemanager.extensions.getFilenameFromPath
import com.explorefile.filemanager.extensions.getMimeType
import com.explorefile.filemanager.extensions.getProperBackgroundColor
import com.explorefile.filemanager.extensions.getProperTextColor
import com.explorefile.filemanager.extensions.needsStupidWritePermissions
import com.explorefile.filemanager.extensions.rescanPaths
import com.explorefile.filemanager.extensions.showErrorToast
import com.explorefile.filemanager.extensions.toast
import com.explorefile.filemanager.extensions.viewBinding
import com.explorefile.filemanager.fragments.ApplicationFragment
import com.explorefile.filemanager.helpers.LocaleHelper.setLocale
import com.explorefile.filemanager.helpers.NavigationIcon
import com.explorefile.filemanager.helpers.ensureBackgroundThread
import java.io.File
import java.util.ArrayList
import java.util.Locale
import kotlin.toString

class AppManagerActivity : BaseActivity(), View.OnClickListener {

    var mViewPager: ViewPager? = null
    var lViewPagerAdapter: ViewPagerAdapter? = null
    var fragmentUserApps: ApplicationFragment? = null
    var fragmentSystemApps: ApplicationFragment? = null
    var isFrom = ""
    var mIsCheckType: String? = null
    val binding by viewBinding(ActivityAppManagerBinding::inflate)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        initData()
        initActions()

    }

    class ViewPagerAdapter(manager: FragmentManager?) : FragmentPagerAdapter(manager!!) {

        private val mFragmentList: MutableList<Fragment> = ArrayList()
        private val mFragmentTitleList: MutableList<String> = ArrayList()

        override fun getItem(position: Int): Fragment {
            return mFragmentList[position]
        }

        override fun getCount(): Int {
            return mFragmentList.size
        }

        fun addFrag(fragment: Fragment, title: String) {
            mFragmentList.add(fragment)
            mFragmentTitleList.add(title)
        }

        override fun getPageTitle(position: Int): CharSequence {
            return mFragmentTitleList[position]
        }
    }

    fun initData() {
//        if (intent.hasExtra("IsCheckType")) {
//            mIsCheckType = intent.extras!!.getString("IsCheckType")
//        }
//        if (intent.hasExtra("IsCheckOneSignalNotification")) {
//            isFromOneSignal = intent.getBooleanExtra("IsCheckOneSignalNotification", false)
//        }

        mViewPager = findViewById(R.id.viewpager)
        fragmentUserApps = ApplicationFragment.newInstance("user")
        fragmentSystemApps = ApplicationFragment.newInstance("system")

        mViewPager?.offscreenPageLimit = 2
        setupViewPager(mViewPager!!)

//        if (AdsManager(mContext).isNeedToShowAds()) {
//            InterstitialAdHelper.loadInterstitialAd(fContext = mContext)
//        }
    }

    private fun setupViewPager(viewPager: ViewPager) {
        lViewPagerAdapter = ViewPagerAdapter(supportFragmentManager)
        lViewPagerAdapter!!.addFrag(fragmentUserApps!!, "UserApps")
        lViewPagerAdapter!!.addFrag(fragmentSystemApps!!, "SystemApps")
        viewPager.adapter = lViewPagerAdapter
        viewPager.offscreenPageLimit = 2
        initViewActions(0)

        viewPager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {
            }

            override fun onPageSelected(position: Int) {
                Log.e("mTAG", "onPageSelected: $position")
                if (position == 0) {
                    isFrom = "UserApps"
                } else {
                    isFrom = "SystemApps"
                }
                val fragment = lViewPagerAdapter?.getItem(position)
                if (fragment is ApplicationFragment) {
                    fragment.deSelectAll()
                    fragment.filter("")
                }
                initViewActions(position)
            }

            override fun onPageScrollStateChanged(state: Int) {}
        })

        if (mIsCheckType == "UserApps") {
            viewPager.currentItem = 0
        } else if (mIsCheckType == "SystemApps") {
            viewPager.currentItem = 1
        }
    }

    private fun initViewActions(position: Int) {
        binding.etSearch.setText("")
        if (position == 0) {
            binding.viewUserActive.visibility = View.VISIBLE
            binding.viewSystemActive.visibility = View.GONE
        } else if (position == 1) {
            binding.viewUserActive.visibility = View.GONE
            binding.viewSystemActive.visibility = View.VISIBLE
        }

    }

    fun initActions() {

        binding.ivBack.setOnClickListener {
            onBackPressed()
        }

        binding.viewUser.setOnClickListener(this)
        binding.viewSystem.setOnClickListener(this)

        binding.tvLessUsed.setOnClickListener(this)
        binding.tvMostUsed.setOnClickListener(this)
        binding.tvDataStore.setOnClickListener(this)
//        binding.ivBack.setOnClickListener(this)
//        binding.ivHistory.setOnClickListener(this)
        var strBefore = ""
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                Log.e("AppsFragment", "beforeTextChanged: ${s.toString()}")
                strBefore = s.toString().trim()
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (binding.etSearch!!.text.toString().trim().isEmpty()) {
                    binding.etSearch!!.clearFocus()
//                    MyUtils.hideKeyboard(mContext, binding.etSearch)
                } else {
                    binding.etSearch!!.requestFocus()
                }
            }

            override fun afterTextChanged(s: Editable?) {
                Log.e("AppsFragment", "afterTextChanged: ${s.toString()}")
                if (strBefore.isEmpty() && s.toString().trim().isEmpty()) return

                if (mViewPager?.currentItem == 0) {
                    fragmentUserApps?.filter(s.toString().trim().lowercase(Locale.getDefault()))
                } else {
                    fragmentSystemApps?.filter(s.toString().trim().lowercase(Locale.getDefault()))
                }
            }
        })
    }

//    override fun onBackPressed() {
//        super.onBackPressed()
//    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.viewUser -> {
                initViewActions(0)
                mViewPager?.currentItem = 0
                fragmentUserApps?.filter("")
            }

            R.id.viewSystem -> {
                initViewActions(1)
                mViewPager?.currentItem = 1
                fragmentSystemApps?.filter("")
            }

            R.id.tvLessUsed -> {
                applySort(0)
            }

            R.id.tvMostUsed -> {
                applySort(1)
            }

            R.id.tvDataStore -> {
                applySort(2)
            }

            R.id.iv_back -> onBackPressed()
//            R.id.iv_history -> {
//                val intent = Intent(mContext, AppHistoryActivity::class.java)
//                startActivity(intent)
//            }
        }
    }

    fun applySort(type: Int) {
//        if(mViewPager?.currentItem==0){
//
//        }

        binding.tvLessUsed.setTextColor(getColor(R.color.sm_colorWhite))
        binding.tvMostUsed.setTextColor(getColor(R.color.sm_colorWhite))
        binding.tvDataStore.setTextColor(getColor(R.color.sm_colorWhite))
        if(type==0){
            binding.tvLessUsed.setTextColor(getColor(R.color.color_primary))
//            binding.tvMostUsed.setTextColor(getColor(R.color.color_primary))
//            binding.tvDataStore.setTextColor(getColor(R.color.color_primary))
        }else if(type==1){
//            binding.tvLessUsed.setTextColor(getColor(R.color.color_primary))
            binding.tvMostUsed.setTextColor(getColor(R.color.color_primary))
//            binding.tvDataStore.setTextColor(getColor(R.color.color_primary))

        }else if(type==2){
//            binding.tvLessUsed.setTextColor(getColor(R.color.color_primary))
//            binding.tvMostUsed.setTextColor(getColor(R.color.color_primary))
            binding.tvDataStore.setTextColor(getColor(R.color.color_primary))
        }
        fragmentUserApps?.sort(type)
        fragmentSystemApps?.sort(type)
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Log.e("onActivityResult", "activity-requestCode: $requestCode")
        Log.e("onActivityResult", "activity-resultCode: $resultCode")
    }


    override fun onResume() {
        super.onResume()
        updateStatusbarColor(getProperBackgroundColor())
        setLocale(this, config.languageSting)
        binding.ivBack.setColorFilter(getProperTextColor())
        binding.tvToolbarText.setTextColor(getProperTextColor())
    }
}
