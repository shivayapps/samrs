package com.explorefile.filemanager.models

import android.net.Uri


/**
 * Created by Mahendra Gohil on 07-12-2021.
 * App info Class
 */

class AppInfo {
    var appName: String? = null
    var appPackage: String? = null
    var installedOn: String? = null
    var lastUpdated: String? = null
    var appVersion: String? = null
    var appDrawableURI: Uri? = null
    var appSize: Double? = null
    var isSelected: Boolean = false
    var publicSourceDir: String? = null

    constructor() {
        appName = " "
        appPackage = " "
        installedOn = " "
        lastUpdated = " "
        appVersion = " "
        appDrawableURI = Uri.EMPTY
        publicSourceDir = ""
        appSize = 0.0
    }

    constructor(appName: String, appPackage: String, installed_On: String, last_Updated: String, appVersion: String, appDrawableURI: Uri, publicSourceDir: String, appSize: Double) {
        this.appName = appName
        this.appPackage = appPackage
        this.installedOn = installed_On
        this.lastUpdated = last_Updated
        this.appVersion = appVersion
        this.appDrawableURI = appDrawableURI
        this.publicSourceDir = publicSourceDir
        this.appSize = appSize
    }
}
