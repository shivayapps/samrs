package com.explorefile.filemanager.filecleaner.service

import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.util.Log
import com.explorefile.filemanager.filecleaner.entity.FileScanResultSummary
import com.explorefile.filemanager.filecleaner.entity.StorageStat
import com.explorefile.filemanager.filecleaner.extension.ExecutorsLinkedBlockingQueue
import com.explorefile.filemanager.filecleaner.extension.throwIfMainThread
import java.io.File
import java.util.concurrent.CancellationException
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.RejectedExecutionHandler
import java.util.concurrent.ThreadFactory
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

class FileScanService {

    companion object {
        private const val TAG = "FileScanServiceImpl"
    }

    val imageFileExtSet = hashSetOf(
        "bmb",
        "jpg",
        "png",
        "gif",
        "tif",
        "pic",
        "jpeg",
        "bmp",
        "webp",
        "heic",
        "heif",
        "apng",
        "avif"
    )
    val videoFileExtSet = hashSetOf("mp4", "mkv", "webm", "avi", "3gp", "mov", "m4v", "3gpp")
    val audioFileExtSet = hashSetOf("wav", "mp3", "wma", "ogg", "m4a", "opus", "flac", "aac", "m4b","aif")

    val documentFileExtSet =
        hashSetOf("txt", "doc", "docx", "xls", "xlsx", "pdf", "xmind", "ppt", "pptx")
    val apkFileExt = "apk"
    val compressedFileExt = hashSetOf("zip", "7z", "rar")

    private val ioThreadNum = AtomicInteger()

    private lateinit var ioExecutors: ThreadPoolExecutor

    fun calcStorageStatFs(): StorageStat {
        return StatFs(Environment.getExternalStorageDirectory().path).let { statFs ->
            val storageAvailableSize = statFs.availableBytes
            val storageTotalSize = statFs.totalBytes
            StorageStat(
                storageTotalSize - storageAvailableSize,
                storageAvailableSize,
                storageTotalSize
            )
        }
    }

    private fun initIOExecutorsIfNeed() {
        if (!this::ioExecutors.isInitialized || ioExecutors.isShutdown) {
            val corePoolSize = 0
            val maxPoolSize = Runtime.getRuntime().availableProcessors() * 8
            val keepAliveTimeSeconds = 30
            val maxQueueSize = maxPoolSize * 0xFF
            val workQueue = ExecutorsLinkedBlockingQueue(maxQueueSize)
            val threadFactory = ThreadFactory { r: Runnable? ->
                Thread(
                    r,
                    "fss-io-${ioThreadNum.incrementAndGet()}-thread"
                )
            }
            val rejectedExecutionHandler =
                RejectedExecutionHandler { r: Runnable, executor: ThreadPoolExecutor ->
                    if (!executor.isShutdown && workQueue.size < maxQueueSize) {
                        executor.execute(r)
                    } else {
                        throw RejectedExecutionException("Task $r rejected from $executor")
                    }
                }
            ioExecutors = ThreadPoolExecutor(
                corePoolSize, maxPoolSize, keepAliveTimeSeconds.toLong(), TimeUnit.SECONDS,
                workQueue, threadFactory, rejectedExecutionHandler
            )
            workQueue.setExecutor(ioExecutors)
        }
    }

    @Throws(CancellationException::class)
    fun start(): FileScanResultSummary {
        throwIfMainThread()
        Log.i(TAG, "startScan: prepare")
        val l = SystemClock.elapsedRealtime()
        initIOExecutorsIfNeed()
        val fileScanResultSummary = FileScanResultSummary()
        ioExecutors.execute {
            processDir(Environment.getExternalStorageDirectory(), fileScanResultSummary)
        }
        fileScanResultSummary.countDownLatch.await()
        if (ioExecutors.isShutdown) {
            throw CancellationException("File scan task has been stopped")
        }
        val scanCost = SystemClock.elapsedRealtime() - l
        fileScanResultSummary.scanCost = scanCost.toInt()
        return fileScanResultSummary
    }

    fun stopIfNeed() {
        if (this::ioExecutors.isInitialized && ioExecutors.activeCount > 0) {
            Log.i(TAG, "stopIfNeed: stop now")
            ioExecutors.shutdownNow()
        }
    }

    private fun processDir(dir: File, fileScanResultSummary: FileScanResultSummary) {
        fileScanResultSummary.scanTaskNum.incrementAndGet()
        try {
            val listFiles = dir.listFiles()
            if (listFiles.isNullOrEmpty()) {
                fileScanResultSummary.emptyDir.fileQueue.offer(dir)
            } else {
                val listPair = listFiles.partition { it.isDirectory }
                for (lDir in listPair.first) {
                    try {
                        ioExecutors.execute { processDir(lDir, fileScanResultSummary) }
                    } catch (e: Exception) {
                        // the executors has been terminated
                        // means our task should be interrupt
                        return
                    }
                }
                for (lFile in listPair.second) {
                    val fileExt = lFile.extension
                    if (fileExt.isEmpty()) {
                        fileScanResultSummary.noExt.offerFileAndAddFileSize(lFile)
                    } else if (imageFileExtSet.contains(lFile.extension)) {
                        fileScanResultSummary.image.offerFileAndAddFileSize(lFile)
                    } else if (videoFileExtSet.contains(lFile.extension)) {
                        fileScanResultSummary.video.offerFileAndAddFileSize(lFile)
                    } else if (audioFileExtSet.contains(lFile.extension)) {
                        fileScanResultSummary.audio.offerFileAndAddFileSize(lFile)
                    } else if (documentFileExtSet.contains(lFile.extension)) {
                        fileScanResultSummary.document.offerFileAndAddFileSize(lFile)
                    } else if (apkFileExt == lFile.extension) {
                        fileScanResultSummary.apkFile.offerFileAndAddFileSize(lFile)
                    } else if (compressedFileExt.contains(lFile.extension)) {
                        fileScanResultSummary.compressedFile.offerFileAndAddFileSize(lFile)
                    } else {
                        fileScanResultSummary.unknownExt.offerFileAndAddFileSize(lFile)
                    }
                }
            }
        } finally {
            if (fileScanResultSummary.scanTaskNum.decrementAndGet() <= 0) {
                fileScanResultSummary.countDownLatch.countDown()
            }
        }
    }

}