package com.explorefile.filemanager.activities

import android.content.Intent
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.adconfig.adsutil.AdsParameters
import com.adconfig.adsutil.openad.OpenAdHelper
import com.adconfig.adsutil.openad.OpenAdHelper.isShowOpenAd
import com.explorefile.filemanager.App.Companion.isAppIsRunning
import com.explorefile.filemanager.BuildConfig
import com.explorefile.filemanager.R
import com.explorefile.filemanager.databinding.ActivitySplashBinding
import com.explorefile.filemanager.extensions.addBit
import com.explorefile.filemanager.extensions.baseConfig
import com.explorefile.filemanager.extensions.config
import com.explorefile.filemanager.extensions.getContrastColor
import com.explorefile.filemanager.extensions.getProperBackgroundColor
import com.explorefile.filemanager.extensions.getProperTextColor
import com.explorefile.filemanager.extensions.isUsingSystemDarkTheme
import com.explorefile.filemanager.extensions.removeBit
import com.explorefile.filemanager.extensions.viewBinding
import com.explorefile.filemanager.helpers.DARK_GREY

class SplashActivity : AppCompatActivity() {
    val binding by viewBinding(ActivitySplashBinding::inflate)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        isAppIsRunning = false

        binding.layoutMain.setBackgroundColor(getProperBackgroundColor())
        updateStatusbarColor(getProperBackgroundColor())
        initAdSize()

//        splashAPICalling(
//            getIntentForOpenActivityAfterSplash(), "com.explorefile.filemanager.json",
//            BuildConfig.VERSION_NAME
//        )
//        OpenAdHelper.loadOpenAd(this) {
        Log.i("ADCONFIG_OpenAdHelper", "SplashActivity:loadOpenAd")

        isShowOpenAd() {
            startNextActivity()
        }

        binding.textView.setTextColor(getProperTextColor())
    }

    private fun startNextActivity() {
        startActivity(getIntentForOpenActivityAfterSplash())
        finish()
    }

    private fun initAdSize() {
        val display = windowManager.defaultDisplay
        val outMetrics = DisplayMetrics()
        display.getMetrics(outMetrics)
        val widthPixels = outMetrics.widthPixels.toFloat()

        val density = outMetrics.density
        val adWidth = (widthPixels / density).toInt()

        AdsParameters(this@SplashActivity).adWidth = adWidth
    }

    private fun getIntentForOpenActivityAfterSplash(): Intent {
        return if (!config.isGetStarted) {
            Intent(this, StartActivity::class.java)
        } else {
            if (config.appRunCount == 0) {
                Intent(this, PermissionActivity::class.java)
            } else {
                if (intent.action == Intent.ACTION_VIEW && intent.data != null) {
                    Intent(this, MainActivity::class.java).apply {
                        action = Intent.ACTION_VIEW
                        data = intent.data
                    }
                } else {
                    Intent(this, MainActivity::class.java)
                }
            }
        }
    }

    private fun updateStatusbarColor(color: Int) {
        window.statusBarColor = color

        if (color.getContrastColor() == DARK_GREY) {
            window.decorView.systemUiVisibility =
                window.decorView.systemUiVisibility.addBit(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)
        } else {
            window.decorView.systemUiVisibility =
                window.decorView.systemUiVisibility.removeBit(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)
        }
    }

}
