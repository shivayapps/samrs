package com.explorefile.filemanager.extensions

import android.content.Context
import com.explorefile.filemanager.models.FileDirItem

fun FileDirItem.isRecycleBinPath(context: Context): Boolean {
    return path.startsWith(context.recycleBinPath)
}
