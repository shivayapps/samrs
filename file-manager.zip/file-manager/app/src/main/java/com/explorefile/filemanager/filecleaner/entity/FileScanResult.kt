package com.explorefile.filemanager.filecleaner.entity

import android.os.Build
import java.io.File
import java.nio.file.Files
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicLong


data class FileScanResult(
    val fileQueue: ConcurrentLinkedQueue<File> = ConcurrentLinkedQueue(),
    val queueSize: AtomicLong = AtomicLong(0)
) {
//    fun offerFileAndAddFileSize(file: File) {
//        fileQueue.offer(file)
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            queueSize.getAndAdd(Files.size(file.toPath()))
//        }else {
//            file.length()
//        }
//    }
    fun offerFileAndAddFileSize(file: File) {
        fileQueue.offer(file)
        val size = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Files.size(file.toPath())
        } else {
            file.length()
        }
        queueSize.getAndAdd(size)
    }

}
