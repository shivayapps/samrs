# file-manager
file-manager

https://docs.google.com/document/d/1yPjtfiwPaZDOHqjOtTKv77Mjw0yNHc-mA1YFly-p-ls/edit?tab=t.0