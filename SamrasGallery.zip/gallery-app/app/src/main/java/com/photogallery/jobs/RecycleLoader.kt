package com.photogallery.jobs

import android.content.Context
import android.os.Build
import android.util.Log
import com.photogallery.GalleryApp
import com.photogallery.R
import com.photogallery.database.AppDatabase
import com.photogallery.extension.isApng
import com.photogallery.extension.isGif
import com.photogallery.extension.isImageFast
import com.photogallery.extension.isPng
import com.photogallery.extension.isPortrait
import com.photogallery.extension.isSvg
import com.photogallery.extension.isVideoFast
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class RecycleLoader(
    private val mContext: Context,
    private var sortType: Int = Constant.SORT_DATE,
    private var sortOrder: Int = Constant.ORDER_DESCENDING,
    private var groupBy: Int = Constant.GROUP_BY_DATE_DAILY,
    private var groupOrder: Int = Constant.GROUP_BY_NONE,
    prefKey: String = "",
) {

    private var TAG = ""
    private var mJob: Job = Job()
    private var preferences: Preferences? = null
    private var dataBase: AppDatabase? = null

    var allList = ArrayList<MediaData>()
    var pictures = ArrayList<Any>()

    fun refreshLoader(prefKey: String) {
        sortType = preferences?.getSortType(prefKey) ?: Constant.SORT_DATE
        sortOrder = preferences?.getSortOrder(prefKey) ?: Constant.ORDER_DESCENDING
        groupBy = preferences?.getGroupBy(prefKey) ?: Constant.GROUP_BY_DATE_DAILY
        groupOrder = preferences?.getGroupOrderBy(prefKey) ?: Constant.GROUP_BY_NONE
    }

    init {
        TAG = prefKey.ifEmpty { "MediaLoaderX" }
        preferences = GalleryApp.preferences

        dataBase = AppDatabase.getInstance(mContext)
        refreshLoader(prefKey)

    }

//    fun getAllData(
//        onSuccess: ((groupedMediaList: ArrayList<Any>, mediaList: ArrayList<MediaData>) -> Unit)? = null,
//        onFailed: ((error: String) -> Unit)? = null,
//    ) {
//
//        mJob = CoroutineScope(Dispatchers.IO).launch {
//            try {
//                val albums: ArrayList<AlbumData> = ArrayList()
//                val sortedMedia: ArrayList<MediaData> = ArrayList()
//                val groupMedia: ArrayList<Any> = ArrayList()
//
//                allList.clear()
//                val hiddenList = dataBase?.dataDao()?.getRecentDeleteList()
//
//                if (!hiddenList.isNullOrEmpty()) {
//                    for (hiddenData in hiddenList) {
//                        val file = File(hiddenData.path)
//                        val mediaData =
//                            MediaData(
//                                hiddenData.path,
//                                file.name,
//                                file.parentFile.name,
//                                file.lastModified(),
//                                file.lastModified(),
//                                file.length(),
//                                Utils.isVideoFile(hiddenData.path)
//                            )
//                        mediaData.isPrivate = true
//                        mediaData.isFavorite = false
//                        mediaData.idDataBase = hiddenData.id
//                        mediaData.restorePath = hiddenData.restorePath
//                        if (mediaData.fileSize > 0) {
//                            allList.add(mediaData)
//                        } else {
//                            dataBase?.dataDao()?.removeRecentDelete(
//                                RecentDeleteData(
//                                    mediaData.idDataBase,
//                                    mediaData.filePath,
//                                    mediaData.restorePath
//                                )
//                            )
//                        }
//                    }
//                }
//
//
//                applyMediaSorting(allList, sortType, sortOrder) { media ->
//                    sortedMedia.addAll(media)
//
//                    val groupedMedia = sortedMedia.groupBy { it.bucketPath }
//                    Log.e(TAG, "groupedMedia size:${groupedMedia.size}")
//                    groupedMedia.forEach { (bucketPath, media) ->
//
//                        val folderName = media.first().folderName
//                        val folderSize = media.sumOf { it.fileSize }
//                        val albumData = AlbumData(
//                            title = folderName,
//                            mediaData = ArrayList(media),
//                            folderPath = bucketPath,
//                            date = media.maxOfOrNull { it.date } ?: 0L,
//                            fileSize = folderSize
//                        )
//                        albums.add(albumData)
//                    }
//                }
//
//                applyMediaGrouping(sortedMedia, groupBy, groupOrder) { groupedMediaList ->
//                    Log.e(TAG, "groupedMediaList==>> ${groupedMediaList.size}")
//                    groupMedia.addAll(groupedMediaList)
//                }
//
//                withContext(Dispatchers.Main) {
////                    onMediaListSuccess?.invoke(sortedMedia)
////                    onMediaFolderListSuccess?.invoke(customAlbumList)
//                    Log.e(TAG, "onSuccess?.invoke")
//                    onSuccess?.invoke(groupMedia, sortedMedia)
//                }
//
//            } catch (e: Exception) {
//                withContext(Dispatchers.Main) {
//                    onFailed?.invoke(e.message ?: "Error occurred while loading media.")
//                }
//            }
//        }
//    }


    private fun searchAlbum(key: String, albumList: ArrayList<AlbumData>): ArrayList<AlbumData> {
        val albumListCopy = ArrayList(albumList)
        val returnList = albumListCopy.filter { it.title.lowercase().contains(key, true) } as ArrayList<AlbumData>
        return returnList
    }

    fun applyMediaSorting(
        mediaList: MutableList<MediaData>,
        sortType: Int,
        sortOrder: Int,
        onSortingComplete: (List<MediaData>) -> Unit
    ) {
        Log.e(TAG, "applyMediaSorting >>>>")
        try {
            val comparator = when (sortType) {
                Constant.SORT_NAME -> compareBy<MediaData> { it.fileName.lowercase() }
//                Constant.SORT_PATH -> compareBy { it.filePath.lowercase() }
                Constant.SORT_SIZE -> compareBy { it.fileSize }
                Constant.SORT_DATE -> compareBy { it.date }
//                Constant.SORT_DATE_TAKEN -> compareBy { it.dateTaken }
                else -> compareBy { it.date }
            }

            val sortedList = if (sortOrder == Constant.ORDER_ASCENDING) {
                mediaList.sortedWith(comparator)
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    mediaList.sortedWith(comparator.reversed())
                } else {
                    mediaList.sortedWith(comparator)
                }
            }

            onSortingComplete(sortedList)
        } catch (e: Exception) {
            Log.e(TAG, "applyMediaSorting Exception:$e")
            onSortingComplete(mediaList)
        }
        Log.e(TAG, "applyMediaSorting <<<<")
    }


    fun applyMediaGrouping(
        mediaList: ArrayList<MediaData>,
        currentGrouping: Int,
        groupOrder: Int,
        onGroupComplete: ((groupedMediaList: ArrayList<Any>) -> Unit)? = null
    ) {
        Log.e(TAG, "applyMediaGrouping >>>>")
        val allList = ArrayList<Any>()
        val format = when (currentGrouping) {
            Constant.GROUP_BY_DATE_DAILY -> SimpleDateFormat(preferences?.dateFormat, Locale.ENGLISH)
//            Constant.GROUP_BY_DATE_TAKEN_DAILY -> SimpleDateFormat(preferences.dateFormat, Locale.ENGLISH)
            Constant.GROUP_BY_DATE_MONTHLY -> SimpleDateFormat("MMMM yyyy", Locale.ENGLISH)
//            Constant.GROUP_BY_DATE_TAKEN_MONTHLY -> SimpleDateFormat("MMMM yyyy", Locale.ENGLISH)
            else -> SimpleDateFormat(preferences?.dateFormat, Locale.ENGLISH)
        }
        try {
            // Group media data based on the selected grouping
            val dateWisePictures = linkedMapOf<String, ArrayList<MediaData>>()

            if (mediaList.isNotEmpty()) {
                mediaList.forEach { pictureData ->
                    // Determine the group key based on the current grouping type
                    val strKey = getGroupKey(pictureData, currentGrouping, format)

                    // Add the media item to the corresponding group
                    dateWisePictures.getOrPut(strKey) { ArrayList() }.add(pictureData)
                }

                // Get the keys and order them based on groupOrder
                val listKeys = ArrayList(dateWisePictures.keys).apply {
                    if (groupOrder == Constant.ORDER_DESCENDING) reverse()
                }

                // If no groups are formed, just add all media items to the list
                if (listKeys.isEmpty()) {
                    allList.addAll(mediaList)
                }

                // Add grouped media data to the final list
                listKeys.forEach { key ->
                    dateWisePictures[key]?.let { imagesData ->
                        if (imagesData.isNotEmpty()) {
                            allList.add(AlbumData(key, imagesData))
                            allList.addAll(imagesData)
                        }
                    }
                }
            }

            // Invoke the callback with the grouped media data
            onGroupComplete?.invoke(allList)

        } catch (e: Exception) {
            allList.addAll(mediaList)
            onGroupComplete?.invoke(allList)
            Log.e(TAG, "applyMediaGrouping Exception: $e")
        }

        Log.e(TAG, "applyMediaGrouping <<<<")
    }

    // Helper function to determine the group key based on the current grouping type
    private fun getGroupKey(pictureData: MediaData, currentGrouping: Int, format: SimpleDateFormat): String {
        return when (currentGrouping) {
            Constant.GROUP_BY_NONE -> ""
            Constant.GROUP_BY_DATE_DAILY -> format.format(getDayStartTS(pictureData.date, false))
//            Constant.GROUP_BY_DATE_TAKEN_DAILY -> format.format(getDayStartTS(pictureData.dateTaken, false))
            Constant.GROUP_BY_DATE_MONTHLY -> format.format(getDayStartTS(pictureData.date, true))
//            Constant.GROUP_BY_DATE_TAKEN_MONTHLY -> format.format(getDayStartTS(pictureData.dateTaken, true))
//            Constant.GROUP_BY_EXTENSION -> pictureData.fileName.getFilenameExtension().lowercase(Locale.getDefault())
//            Constant.GROUP_BY_FOLDER -> pictureData.filePath.getParentFolder().lowercase(Locale.getDefault())
//            Constant.GROUP_BY_FILE_TYPE -> getFileTypeString(pictureData.fileName)
            else -> format.format(getDayStartTS(pictureData.date, false))
        }
    }

    private fun getFileTypeString(fileName: String): String {
        Log.e("getFileTypeString", "getFileTypeString.001:$fileName")
        var stringId = R.string.images
        if (fileName.isImageFast() || fileName.isApng() || fileName.isPng()) stringId =
            R.string.images
        else if (fileName.isVideoFast()) stringId = R.string.videos
        else if (fileName.isPortrait()) stringId = R.string.portraits
        else if (fileName.isSvg()) stringId = R.string.svgs
        else if (fileName.isGif()) stringId = R.string.gifs

        return mContext.getString(stringId)
    }

    private fun getDayStartTS(ts: Long, resetDays: Boolean): Long {
        val calendar = Calendar.getInstance(Locale.ENGLISH).apply {
            timeInMillis = ts
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)

            if (resetDays) {
                set(Calendar.DAY_OF_MONTH, 1)
            }
        }

        return calendar.timeInMillis
    }

    fun destroyLoader() {
        mJob.cancel()
    }

}
