package com.photogallery.event

data class RenameEvent(
    var oldPath: String,
    var renamePath: String,
    var isCompressImage: Boolean = false
)
