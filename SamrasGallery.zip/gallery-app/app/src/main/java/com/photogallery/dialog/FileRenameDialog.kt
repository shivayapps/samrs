package com.photogallery.dialog

import android.app.Activity
import android.app.Dialog
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Point
import android.graphics.drawable.ColorDrawable
import android.media.MediaScannerConnection
import android.media.MediaScannerConnection.OnScanCompletedListener
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import androidx.core.widget.addTextChangedListener
import com.photogallery.R
import com.photogallery.databinding.DialogRenameBinding
import com.photogallery.extension.toast
import com.photogallery.model.MediaData
import com.photogallery.utils.DIALOG_DIM_AMOUNT
import com.photogallery.utils.Preferences
import java.io.File

class FileRenameDialog(
    var mContext: Activity,
    var mediaData: MediaData,
    val positiveBtnClickListener: (renamePath: String, oldPath: String) -> Unit
) : Dialog(mContext) {

    lateinit var bindingDialog: DialogRenameBinding
    var preferences: Preferences = Preferences(mContext)
    var oldName = ""
    var type = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        window?.setDimAmount(DIALOG_DIM_AMOUNT)
        window?.attributes?.windowAnimations = android.R.style.Animation_Dialog
//        window?.decorView!!.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        bindingDialog = DialogRenameBinding.inflate(layoutInflater)
//        bindingDialog.root.setPadding(0, 0, 0, mContext.navigationBarHeight)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
        intListener()
    }


    private fun intView() {

        val separated: List<String> = mediaData.fileName.split(".")

        oldName = separated[0]
        type = separated[1]
        Log.e("", "oldName $oldName")
        bindingDialog.edtName.setText(oldName)
        bindingDialog.edtName.requestFocus()

    }

    private fun intListener() {
        bindingDialog.edtName.addTextChangedListener {
            bindingDialog.icClear.visibility = if (bindingDialog.edtName.text?.trim().toString()
                    .isNotEmpty()
            ) View.VISIBLE else View.GONE
        }
        bindingDialog.icClear.setOnClickListener {
            bindingDialog.edtName.setText("")
        }
        bindingDialog.btnCancel.setOnClickListener { dismiss() }

        bindingDialog.btnRename.setOnClickListener {

            val strNewFileName = bindingDialog.edtName.text.toString().trim()
            if (strNewFileName.isNotEmpty()) {
                val renameFile = File(mediaData.filePath.replace(oldName, strNewFileName))
                if (!renameFile.exists() || oldName == strNewFileName) {
                    if (oldName != strNewFileName) {
                        val renamePath = renameFile(strNewFileName, type)
                        if (renamePath.isNotEmpty()) {
                            setRename(mediaData.filePath, renamePath)
                            dismiss()
                            mContext.toast(mContext.getString(R.string.rename_successfully))
                            positiveBtnClickListener.invoke(renamePath, mediaData.filePath)
                        } else {
                            dismiss()

                            mContext.toast(mContext.getString(R.string.failed))
                        }
                    } else {
                        dismiss()
                    }
                } else {

                    mContext.toast(mContext.getString(R.string.rename_validation2))
                }
            } else
                mContext.toast(mContext.getString(R.string.rename_validation))
        }
    }

    private fun getViewValue(view: EditText): Int {
        val textValue = view.text.toString().trim()
        return if (textValue.isEmpty()) 0 else textValue.toInt()
    }

    private fun setRename(oldPath: String, renamePath: String) {
//        EventBus.getDefault().post(RenameEvent(oldPath, renamePath))
        val list = preferences.getFavoriteList()
        if (list.contains(oldPath)) {
            list.remove(oldPath)
            list.add(0, renamePath)
            preferences.setFavoriteList(list)
        }
    }

    private fun renameFile(strNewFileName: String, type: String): String {

        var renamed = false
        val renameFilePath: String =
            File(mediaData.filePath).parent.toString() + File.separator + strNewFileName + "." + type
        val oldFile: File = File(mediaData.filePath)
        val renameFile = File(renameFilePath)
        renamed = oldFile.renameTo(renameFile)

        MediaScannerConnection.scanFile(context, arrayOf<String>(renameFile.path), null,
            OnScanCompletedListener { path: String?, uri: Uri? -> })

        MediaScannerConnection.scanFile(context, arrayOf<String>(oldFile.path), null,
            OnScanCompletedListener { path: String?, uri: Uri? -> })

        if (renamed)
            return renameFilePath

        return ""
    }

    fun String.getImageResolution(): Point {
        val options = BitmapFactory.Options()
        options.inJustDecodeBounds = true
        BitmapFactory.decodeFile(this, options)

        val width = options.outWidth
        val height = options.outHeight
        return if (width > 0 && height > 0) {
            Point(options.outWidth, options.outHeight)
        } else {
            Point(0, 0)
        }
    }


    fun String.getFilenameExtension() = substring(lastIndexOf(".") + 1)
    fun String.getCompressionFormat() = when (getFilenameExtension().lowercase()) {
        "png" -> Bitmap.CompressFormat.PNG
        "webp" -> Bitmap.CompressFormat.WEBP
        else -> Bitmap.CompressFormat.JPEG
    }

//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)
}

