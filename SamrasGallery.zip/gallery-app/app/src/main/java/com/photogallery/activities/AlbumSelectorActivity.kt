package com.photogallery.activities

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.photogallery.R
import com.photogallery.adapter.AlbumCreationAdapter
import com.photogallery.base.BaseActivity
import com.photogallery.databinding.DialogAddAlbumFullBinding
import com.photogallery.extension.toast
import com.photogallery.model.AlbumData
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences


class AlbumSelectorActivity : BaseActivity() {

    private lateinit var binding: DialogAddAlbumFullBinding
    private lateinit var albumAdapter: AlbumCreationAdapter
    private var albumList: ArrayList<AlbumData> = ArrayList()
    private var selectPos = -1
    private lateinit var preferences: Preferences

    private lateinit var albumDataList: ArrayList<AlbumData>
    private lateinit var selectedAlbum: ArrayList<String>

    private var isCopy: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DialogAddAlbumFullBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        selectedAlbum =
            intent.getSerializableExtra("selectedAlbum") as? ArrayList<String> ?: arrayListOf()
//        selectedAlbum = intent.getStringExtra("selectedAlbum")?:""
        isCopy = intent.getBooleanExtra("isCopy", false)
        albumDataList = Constant.deviceAlbumList
        preferences = Preferences(this)


        initView()
        initAdapter()
        initListener()
    }

    private fun initView() {
        binding.txtTitle.text =
            if (isCopy) getString(R.string.copy_to_album) else getString(R.string.move_to_album)

    }

    private fun initAdapter() {
//        albumDataList.removeAll(selectedAlbum)
        albumDataList.removeIf { it.folderPath in selectedAlbum }
        albumList.addAll(albumList.size, albumDataList)
        //albumList.add(0, AlbumData(getString(R.string.add), isCustomAlbum = true))
        albumAdapter = AlbumCreationAdapter(this, albumList, clickListener = {
            selectPos = it
        })
        val gridLayoutManager = GridLayoutManager(this, 1, RecyclerView.VERTICAL, false)
        binding.albumRecycler.layoutManager = gridLayoutManager
        binding.albumRecycler.adapter = albumAdapter
    }

    private fun initListener() {
        binding.btnClose.setOnClickListener {
            finish()
        }

        binding.btnDone.setOnClickListener {
            if (selectPos >= 0) {
                val albumData = albumList[selectPos]
                if (albumData.isCustomAlbum) {
                    if (albumData.title == getString(R.string.add)) {
                        setResult(RESULT_OK, Intent().putExtra("action", "create"))
                        finish()
                    } else if (albumData.folderPath.isNotEmpty()) {
                        setResult(
                            RESULT_OK,
                            Intent().putExtra("selectedPath", albumData.folderPath)
                        )
                        finish()
                    }
                } else {
                    setResult(RESULT_OK, Intent().putExtra("selectedPath", albumData.folderPath))
                    finish()
                }
            } else {
                toast(getString(R.string.PleaseSelectAlbum))
            }
        }
    }
}
