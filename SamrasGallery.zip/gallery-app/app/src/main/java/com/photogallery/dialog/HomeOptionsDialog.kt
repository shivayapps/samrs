package com.photogallery.dialog

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import com.photogallery.databinding.DialogHomeMenuBinding
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.utils.DIALOG_DIM_AMOUNT
import com.photogallery.utils.Preferences

class HomeOptionsDialog(var mContext: Activity, var currentFragment: Int, val clickListener: (type: Int) -> Unit) :
    Dialog(mContext) {

    lateinit var binding: DialogHomeMenuBinding
    lateinit var preferences: Preferences
    var isShowGrid = false
    var gridCount = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)

        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        window?.setDimAmount(DIALOG_DIM_AMOUNT)
        window?.attributes?.windowAnimations = android.R.style.Animation_Dialog

        binding = DialogHomeMenuBinding.inflate(layoutInflater)
        //binding.root.setPadding(0, 0, 0, mContext.navigationBarHeight)

        setContentView(binding.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
    }
    private fun intView() {
        preferences = Preferences(mContext)
        isShowGrid = preferences.getShowGrid()
        gridCount = preferences.getGridCount()
        selectedGrid = gridCount

        if (currentFragment == 0) {
            binding.btnCreateAlbum.beVisible()
            binding.btnGroup.beGone()

            binding.llMainOperation.beVisible()
        } else if (currentFragment == 1) {
            binding.btnCreateAlbum.beGone()
            binding.llMainOperation.beVisible()
        } else if (currentFragment == 2) {
            binding.btnSelect.beGone()
            binding.llMainOperation.beGone()
        } else if (currentFragment == 3) {
            binding.llMainOperation.beGone()
        }
//        binding.icCall.beVisibleIf(!adsPref.isShowCallInfo)
//        binding.btnCreateAlbum.visibility = if (isShowAlbumTab) View.VISIBLE else View.GONE
//        binding.btnGroup.visibility = if (isShowAlbumTab) View.GONE else View.VISIBLE
//        binding.btnChangeViewType.visibility =  if (isShowAlbumTab) View.VISIBLE else View.GONE

        intListener()
        setView()
        setColumnView()

    }

    var selectedGrid = -1
    private fun intListener() {
        binding.btnSelect.setOnClickListener {
            dismiss()
            clickListener(11)
        }
        binding.btnSortBy.setOnClickListener {
            dismiss()
            clickListener(1)
        }
        binding.btnGroup.setOnClickListener {
            dismiss()
            clickListener(9)
        }
//        binding.btnFilterMedia.setOnClickListener {
//            dismiss()
//            clickListener(2)
//        }
//        binding.btnChangeViewType.setOnClickListener {
//            dismiss()
//            clickListener(2)
//        }
        binding.btnList.setOnClickListener {
            if (isShowGrid) {
                isShowGrid = false
                setView()
                preferences.putShowGrid(isShowGrid)
//                updateListener()
                clickListener(21)
                dismiss()
            } else dismiss()
        }
        binding.btnGrid.setOnClickListener {
            if (!isShowGrid) {
                isShowGrid = true
                setView()
                preferences.putShowGrid(isShowGrid)
//                updateListener()
                clickListener(22)
                dismiss()
            } else dismiss()
        }

        binding.btnCreateAlbum.setOnClickListener {
            dismiss()
            clickListener(3)
        }
        binding.btnDisplayedColumns.setOnClickListener {
            dismiss()
            clickListener(4)
        }

        binding.btnRecycleBin.setOnClickListener {
            dismiss()
            clickListener(5)
        }
        binding.btnCollage.setOnClickListener {
            dismiss()
            clickListener(6)
        }
//        binding.btnPrivateMedia.setOnClickListener {
//            dismiss()
//            clickListener(10)
//        }
//        binding.btnFamilyApps.setOnClickListener {
//            dismiss()
//            clickListener(6)
//        }
//        binding.btnFeedback.setOnClickListener {
////            val intent = Intent(activity, FeedbackActivity::class.java)
////            startActivity(intent)
//            dismiss()
//            clickListener(7)
//        }
        binding.btnSetting.setOnClickListener {
            dismiss()
            clickListener(8)
        }
    }

    private fun setView() {
        if (currentFragment == 0) {
            if (isShowGrid) {
                binding.btnGrid.visibility = View.GONE
                binding.btnList.visibility = View.VISIBLE
                binding.btnDisplayedColumns.visibility = View.VISIBLE
            } else {
                binding.btnGrid.visibility = View.VISIBLE
                binding.btnList.visibility = View.GONE
                binding.btnDisplayedColumns.visibility = View.GONE
            }
        } else {
            binding.btnGrid.visibility = View.GONE
            binding.btnList.visibility = View.GONE
        }
    }

    private fun setColumnView() {
        when (selectedGrid) {
        }
    }


//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)
}