package com.photogallery.jobs

import android.content.Context
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import com.photogallery.GalleryApp
import com.photogallery.R
import com.photogallery.extension.isApng
import com.photogallery.extension.isGif
import com.photogallery.extension.isImageFast
import com.photogallery.extension.isPng
import com.photogallery.extension.isPortrait
import com.photogallery.extension.isSvg
import com.photogallery.extension.isVideoFast
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences
import com.photogallery.utils.TYPE_GIFS
import com.photogallery.utils.TYPE_IMAGES
import com.photogallery.utils.TYPE_VIDEOS
import com.photogallery.utils.photoExtensions
import com.photogallery.utils.rawExtensions
import com.photogallery.utils.videoExtensions
import kotlinx.coroutines.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class FilesLoader(
    private val mContext: Context,
    private var filterMedia: Int = TYPE_IMAGES or TYPE_VIDEOS or TYPE_GIFS,
    private var sortType: Int = Constant.SORT_DATE,
    private var sortOrder: Int = Constant.ORDER_DESCENDING,
    private var groupBy: Int = Constant.GROUP_BY_DATE_DAILY,
    private var groupOrder: Int = Constant.GROUP_BY_NONE,
    private val loadImage: Boolean = true,
    private val loadVideo: Boolean = true,
    private val addCustomAlbum: Boolean = true,
    prefKey: String = "",
) {

    private var TAG = ""
    private var ROOT_PATH = ""
    private var mJob: Job = Job()
    private var preferences: Preferences? = null
    var recentEndDate = Calendar.getInstance()
    var recentStartDate = Calendar.getInstance()

    private val albumList: ArrayList<AlbumData> = ArrayList()

    var recentList: ArrayList<MediaData> = ArrayList()
    var favouriteList: ArrayList<MediaData> = ArrayList()
    var videoList: ArrayList<MediaData> = ArrayList()
    var customAlbumList: ArrayList<AlbumData> = ArrayList()

    val projectionImage = arrayOf(
        MediaStore.Images.Media.DATA,
        MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
        MediaStore.MediaColumns.DATE_MODIFIED,
        MediaStore.MediaColumns.DATE_TAKEN,
        MediaStore.MediaColumns.DISPLAY_NAME,
        MediaStore.MediaColumns.SIZE,
    )
    val projectionVideo = arrayOf(
        MediaStore.Video.VideoColumns.DATA,
        MediaStore.Video.Media.DISPLAY_NAME,
        MediaStore.Video.VideoColumns.SIZE,
        MediaStore.Video.VideoColumns.DURATION,
        MediaStore.Video.VideoColumns.DATE_MODIFIED,
        MediaStore.Video.VideoColumns.DATE_TAKEN,
        MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
    )

    var favList = ArrayList<String>()
    var pinList = ArrayList<String>()

    fun refreshLoader(prefKey: String) {

        sortType = preferences?.getSortType(prefKey) ?: Constant.SORT_DATE
        sortOrder = preferences?.getSortOrder(prefKey) ?: Constant.ORDER_DESCENDING
        groupBy = preferences?.getGroupBy(prefKey) ?: Constant.GROUP_BY_DATE_DAILY
        groupOrder = preferences?.getGroupOrderBy(prefKey) ?: Constant.GROUP_BY_NONE
        filterMedia = preferences?.getFilterMedia() ?: (TYPE_IMAGES or TYPE_VIDEOS or TYPE_GIFS)

        favList.clear()
        favList.addAll(preferences?.getFavoriteList() ?: ArrayList())

        pinList.clear()
        pinList.addAll(preferences?.getPinAlbumList() ?: ArrayList())
    }

    init {
        TAG = prefKey.ifEmpty { "MediaLoaderX" }
        refreshLoader(prefKey)
//        preferences = Preferences(mActivity!!)
        preferences = GalleryApp.preferences

        recentEndDate = Calendar.getInstance()
        recentStartDate = Calendar.getInstance()
        recentStartDate.add(Calendar.DATE, -15)
    }

//    fun getAllData(
//        onSuccess: ((groupedMediaList: ArrayList<Any>, mediaList: ArrayList<MediaData>, mediaFolderList: ArrayList<AlbumData>) -> Unit)? = null,
//        onFailed: ((error: String) -> Unit)? = null,
//    ) {
//
//        mJob = CoroutineScope(Dispatchers.IO).launch {
//            try {
//                val albums: ArrayList<AlbumData> = ArrayList()
//                val sortedMedia: ArrayList<MediaData> = ArrayList()
//                val groupMedia: ArrayList<Any> = ArrayList()
//                val allMedia: ArrayList<MediaData> = ArrayList()
//                allMedia.clear()
//                albumList.clear()
//
//                recentList.clear()
//                favouriteList.clear()
//                videoList.clear()
//
//                ROOT_PATH = Constant.ROOT_PATH
//                Log.e(TAG, "ROOT_PATH:${ROOT_PATH}")
//                //get Images
//                if (loadImage) allMedia.addAll(getImages())
//                //get Videos
//                if (loadVideo) allMedia.addAll(getVideos())
//
//                recentList = ArrayList(allMedia.filter {
//                    it.date >= recentStartDate.timeInMillis + 1 && it.date <= recentEndDate.timeInMillis
//                })
//                applyMediaSorting(allMedia, sortType, sortOrder) { media ->
//                    sortedMedia.addAll(media)
//
//                    val groupedMedia = sortedMedia.groupBy { it.bucketPath }
//                    Log.e(TAG, "groupedMedia size:${groupedMedia.size}")
//                    groupedMedia.forEach { (bucketPath, media) ->
//
//                        val folderName = media.first().folderName
//                        val folderSize = media.sumOf { it.fileSize }
//                        val albumData = AlbumData(
//                            title = folderName,
//                            mediaData = ArrayList(media),
//                            folderPath = bucketPath,
//                            date = media.maxOfOrNull { it.date } ?: 0L,
//                            fileSize = folderSize
//                        )
//                        albums.add(albumData)
//                    }
//                }
//
//                applyMediaGrouping(sortedMedia, groupBy, groupOrder) { groupedMediaList ->
//                    Log.e(TAG, "groupedMediaList==>> ${groupedMediaList.size}")
//                    groupMedia.addAll(groupedMediaList)
//                }
//                applyAlbumSorting(albums, sortType, sortOrder) { sortedAlbums ->
//                    Log.e(TAG, "sortedAlbums==>> ${sortedAlbums.size}")
//                    albumList.addAll(sortedAlbums)
//                }
//
//                setCustomAlbum()
//
//                withContext(Dispatchers.Main) {
////                    onMediaListSuccess?.invoke(sortedMedia)
////                    onMediaFolderListSuccess?.invoke(customAlbumList)
//                    Log.e(TAG, "onSuccess?.invoke")
//                    onSuccess?.invoke(groupMedia, sortedMedia, customAlbumList)
//                }
//
//            } catch (e: Exception) {
//                withContext(Dispatchers.Main) {
//                    onFailed?.invoke(e.message ?: "Error occurred while loading media.")
//                }
//            }
//        }
//    }

//    fun getAllMedia(
//        folderPath: String = "",
//        onSuccess: ((groupedMediaList: ArrayList<Any>, mediaList: ArrayList<MediaData>) -> Unit)? = null,
//        onFailed: ((error: String) -> Unit)? = null,
//    ) {
//        mJob = CoroutineScope(Dispatchers.IO).launch {
//            try {
//                val sortedMedia: ArrayList<MediaData> = ArrayList()
//                val groupMedia: ArrayList<Any> = ArrayList()
//                val allMedia: ArrayList<MediaData> = ArrayList()
//
//                allMedia.clear()
//                albumList.clear()
//
//                recentList.clear()
//                favouriteList.clear()
//                videoList.clear()
//
//                if (folderPath.isNotEmpty()) {
//                    val folder = File(folderPath)
//                    if (folder.exists() && folder.isDirectory) {
//                        folder.listFiles()?.filter { it.isFile }?.forEach { file ->
//                            val mediaData = createMediaData(file)
//                            allMedia.add(mediaData)
//                        }
//                    }
//                }
//
//                recentList = ArrayList(allMedia.filter {
//                    it.date >= recentStartDate.timeInMillis + 1 && it.date <= recentEndDate.timeInMillis
//                })
//
//                applyMediaSorting(allMedia, sortType, sortOrder) { media ->
//                    sortedMedia.addAll(media)
//                }
//
//                applyMediaGrouping(sortedMedia, groupBy, groupOrder) { groupedMediaList ->
//                    Log.e(TAG, "groupedMediaList==>> ${groupedMediaList.size}")
//                    groupMedia.addAll(groupedMediaList)
//                }
//
//                withContext(Dispatchers.Main) {
//                    onSuccess?.invoke(groupMedia, sortedMedia)
//                }
//
//            } catch (e: Exception) {
//                withContext(Dispatchers.Main) {
//                    onFailed?.invoke(e.message ?: "Error occurred while loading media.")
//                }
//            }
//        }
//    }

    private fun createMediaData(file: File): MediaData {
        val path = file.absolutePath
        val title = file.name
        val bucketPath = file.parent ?: ""
        val bucketName = bucketPath.substringAfterLast("/")

        val fileSize = file.length()
        val date = file.lastModified()

        return MediaData(
            filePath = path,
            fileUri = path,
            fileName = title,
            folderName = bucketName,
            date = date,
            bucketPath = bucketPath,
            dateTaken = date,
            fileSize = fileSize
        ).apply {
            isFavorite = favList.contains(path)
        }
    }


//    fun getAllMedia(
//        folderPath: String = "",
//        onSuccess: ((groupedMediaList: ArrayList<Any>, mediaList: ArrayList<MediaData>) -> Unit)? = null,
//        onFailed: ((error: String) -> Unit)? = null,
//    ) {
//        mJob = CoroutineScope(Dispatchers.IO).launch {
//            try {
//                val sortedMedia: ArrayList<MediaData> = ArrayList()
//                val groupMedia: ArrayList<Any> = ArrayList()
//                val allMedia: ArrayList<MediaData> = ArrayList()
//                allMedia.clear()
//                albumList.clear()
//
//                recentList.clear()
//                favouriteList.clear()
//                videoList.clear()
//
//                //get Images
//                if (loadImage) allMedia.addAll(getImages(folderPath))
//                //get Videos
//                if (loadVideo) allMedia.addAll(getVideos(folderPath))
//
//                recentList = ArrayList(allMedia.filter {
//                    it.date >= recentStartDate.timeInMillis + 1 && it.date <= recentEndDate.timeInMillis
//                })
//                applyMediaSorting(allMedia, sortType, sortOrder) { media ->
//                    sortedMedia.addAll(media)
//                }
//
//                applyMediaGrouping(sortedMedia, groupBy, groupOrder) { groupedMediaList ->
//                    Log.e(TAG, "groupedMediaList==>> ${groupedMediaList.size}")
//                    groupMedia.addAll(groupedMediaList)
//                }
//
//                withContext(Dispatchers.Main) {
////                    onMediaListSuccess?.invoke(sortedMedia)
////                    onMediaFolderListSuccess?.invoke(customAlbumList)
//                    Log.e(TAG, "onSuccess?.invoke")
//                    onSuccess?.invoke(groupMedia, sortedMedia)
//                }
//
//            } catch (e: Exception) {
//                withContext(Dispatchers.Main) {
//                    onFailed?.invoke(e.message ?: "Error occurred while loading media.")
//                }
//            }
//        }
//    }

//    fun getAllAlbum(
//        onSuccess: ((customAlbumList: ArrayList<AlbumData>, albumList: ArrayList<AlbumData>, mediaList: ArrayList<MediaData>) -> Unit)? = null,
//        onFailed: ((error: String) -> Unit)? = null,
//    ) {
//
//        mJob = CoroutineScope(Dispatchers.IO).launch {
//            try {
//                val albums: ArrayList<AlbumData> = ArrayList()
//                val sortedMedia: ArrayList<MediaData> = ArrayList()
//                val allMedia: ArrayList<MediaData> = ArrayList()
//                allMedia.clear()
//                albumList.clear()
//
//                recentList.clear()
//                favouriteList.clear()
//                videoList.clear()
//
//                //get Images
//                if (loadImage) allMedia.addAll(getImages())
//                //get Videos
//                if (loadVideo) allMedia.addAll(getVideos())
//
//                recentList = ArrayList(allMedia.filter {
//                    it.date >= recentStartDate.timeInMillis + 1 && it.date <= recentEndDate.timeInMillis
//                })
//                applyMediaSorting(allMedia, sortType, sortOrder) { media ->
//                    sortedMedia.addAll(media)
//
//                    val groupedMedia = sortedMedia.groupBy { it.bucketPath }
//                    Log.e(TAG, "groupedMedia size:${groupedMedia.size}")
//                    groupedMedia.forEach { (bucketPath, media) ->
//
//                        val folderName = media.first().folderName
//                        val folderSize = media.sumOf { it.fileSize }
//                        val albumData = AlbumData(
//                            title = folderName,
//                            mediaData = ArrayList(media),
//                            folderPath = bucketPath,
//                            date = media.maxOfOrNull { it.date } ?: 0L,
//                            fileSize = folderSize
//                        )
//                        albums.add(albumData)
//                    }
//                }
//
//                applyAlbumSorting(albums, sortType, sortOrder) { sortedAlbums ->
//                    albumList.addAll(sortedAlbums)
//                }
//
//                setCustomAlbum()
//
//                withContext(Dispatchers.Main) {
////                    onMediaListSuccess?.invoke(sortedMedia)
////                    onMediaFolderListSuccess?.invoke(customAlbumList)
//                    Log.e(TAG, "onSuccess?.invoke")
//                    onSuccess?.invoke(customAlbumList, albums, sortedMedia)
//                }
//
//            } catch (e: Exception) {
//                withContext(Dispatchers.Main) {
//                    onFailed?.invoke(e.message ?: "Error occurred while loading media.")
//                }
//            }
//        }
//    }

    private fun searchAlbum(key: String, albumList: ArrayList<AlbumData>): ArrayList<AlbumData> {
        val albumListCopy = ArrayList(albumList)
        val returnList = albumListCopy.filter { it.title.lowercase().contains(key, true) } as ArrayList<AlbumData>
        return returnList
    }

//    private fun getImages(folderPath: String = ""): ArrayList<MediaData> {
//        Log.e(TAG, "getImages >>>>")
//        val mediaList = ArrayList<MediaData>()
//        try {
//            val uri: Uri = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
//            val cursor = mContext.contentResolver.query(
//                uri, projectionImage, getSelectionQuery(filterMedia),
//                getSelectionArgsQuery(filterMedia).toTypedArray(),
//                MediaStore.Images.Media.DATE_MODIFIED + " DESC"
//            )
//
//            cursor?.use {
//                while (it.moveToNext()) {
//
//                    val path = it.getString(it.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))
//                    val title = it.getString(it.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME))
//                    val bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
//
//                    var bucketName = it.getString(it.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME)) ?: path.getParentFolder()
//                    if (bucketPath == ROOT_PATH) bucketName = "Root"
//
//                    val fileSize = it.getLong(it.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)).takeIf { size -> size > 0 } ?: File(path).length()
//                    val date = it.getLong(it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)) * 1000
//                    val dateTaken = it.getLong(it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)) * 1000
//
//                    if (folderPath.isNotEmpty()) {
//                        if (bucketName == folderPath.getFilenameFromPath() && File(path).exists()) {
//                            if (fileSize > 0) {
//                                val mediaData = MediaData(
//                                    filePath = path, fileName = title, folderName = bucketName, date = date,
//                                    bucketPath = bucketPath, dateTaken = dateTaken.takeIf { it > 0 } ?: date, fileSize = fileSize
//                                ).apply {
//                                    isFavorite = favList.contains(path)
//                                }
//
//                                if (mediaData.isFavorite) favouriteList.add(mediaData)
//                                mediaList.add(mediaData)
//                            }
//                        }
//                    } else {
//                        if (fileSize > 0) {
//                            val mediaData = MediaData(
//                                filePath = path, fileName = title, folderName = bucketName, date = date,
//                                bucketPath = bucketPath, dateTaken = dateTaken.takeIf { it > 0 } ?: date, fileSize = fileSize
//                            ).apply {
//                                isFavorite = favList.contains(path)
//                            }
//
//                            if (mediaData.isFavorite) favouriteList.add(mediaData)
//                            mediaList.add(mediaData)
//                        }
//                    }
//                }
//            }
//        } catch (e: Exception) {
//            Log.e(TAG, "getImages Exception:$e")
//        }
//        Log.e(TAG, "getImages <<<<")
//        return mediaList
//    }

//    private fun getVideos(folderPath: String = ""): ArrayList<MediaData> {
//        Log.e(TAG, "getVideos >>>>")
//        val mediaList = ArrayList<MediaData>()
//        try {
//            val uri: Uri = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
//
//            val cursor = mContext.contentResolver.query(
//                uri, projectionVideo, getSelectionQuery(filterMedia),
//                getSelectionArgsQuery(filterMedia).toTypedArray(),
//                MediaStore.Video.Media.DATE_MODIFIED + " DESC"
//            )
//
//            cursor?.use {
//                while (it.moveToNext()) {
//                    val path = it.getString(it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA))
//                    val title = it.getString(it.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME))
//                    val bucketPath = path.substring(0, path.lastIndexOf(title) - 1)
//
//                    var bucketName = it.getString(it.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME)) ?: path.getParentFolder()
//                    if (bucketPath == ROOT_PATH) bucketName = "Root"
//
//                    val fileSize = it.getLong(it.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)).takeIf { size -> size > 0 } ?: File(path).length()
//                    val date = it.getLong(it.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DATE_MODIFIED)) * 1000
//                    val dateTaken = it.getLong(it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)) * 1000
//                    val duration = it.getLong(it.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DURATION))
//
//                    if (folderPath.isNotEmpty()) {
//                        if (bucketName == folderPath.getFilenameFromPath() && File(path).exists()) {
//                            if (fileSize > 0) {
//                                val mediaData = MediaData(
//                                    filePath = path, fileName = title, folderName = bucketName, date = date,
//                                    dateTaken = dateTaken.takeIf { it > 0 } ?: date, fileSize = fileSize,
//                                    bucketPath = bucketPath, isVideo = true, videoDuration = duration
//                                ).apply {
//                                    isFavorite = favList.contains(path)
//                                }
//
//                                if (mediaData.isFavorite) favouriteList.add(mediaData)
//                                videoList.add(mediaData)
//                                mediaList.add(mediaData)
//                            }
//                        }
//                    } else {
//                        if (fileSize > 0) {
//                            val mediaData = MediaData(
//                                filePath = path, fileName = title, folderName = bucketName, date = date,
//                                dateTaken = dateTaken.takeIf { it > 0 } ?: date, fileSize = fileSize,
//                                bucketPath = bucketPath, isVideo = true, videoDuration = duration
//                            ).apply {
//                                isFavorite = favList.contains(path)
//                            }
//
//                            if (mediaData.isFavorite) favouriteList.add(mediaData)
//                            videoList.add(mediaData)
//                            mediaList.add(mediaData)
//                        }
//                    }
//                }
//            }
//        } catch (e: Exception) {
//            Log.e(TAG, "getVideos Exception:$e")
//        }
//        Log.e(TAG, "getVideos <<<<")
//        return mediaList
//    }

    fun applyMediaSorting(
        mediaList: MutableList<MediaData>,
        sortType: Int,
        sortOrder: Int,
        onSortingComplete: (List<MediaData>) -> Unit
    ) {
        Log.e(TAG, "applyMediaSorting >>>>")
        try {
            val comparator = when (sortType) {
                Constant.SORT_NAME -> compareBy<MediaData> { it.fileName.lowercase() }
//                Constant.SORT_PATH -> compareBy { it.filePath.lowercase() }
                Constant.SORT_SIZE -> compareBy { it.fileSize }
                Constant.SORT_DATE -> compareBy { it.date }
//                Constant.SORT_DATE_TAKEN -> compareBy { it.dateTaken }
                else -> compareBy { it.date }
            }

            val sortedList = if (sortOrder == Constant.ORDER_ASCENDING) {
                mediaList.sortedWith(comparator)
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    mediaList.sortedWith(comparator.reversed())
                } else {
                    mediaList.sortedWith(comparator)
                }
            }

            onSortingComplete(sortedList)
        } catch (e: Exception) {
            Log.e(TAG, "applyMediaSorting Exception:$e")
            onSortingComplete(mediaList)
        }
        Log.e(TAG, "applyMediaSorting <<<<")
    }

    fun applyMediaGrouping(
        mediaList: ArrayList<MediaData>,
        currentGrouping: Int,
        groupOrder: Int,
        onGroupComplete: ((groupedMediaList: ArrayList<Any>) -> Unit)? = null
    ) {
        Log.e(TAG, "applyMediaGrouping >>>>")
        val allList = ArrayList<Any>()
        val format = when (currentGrouping) {
            Constant.GROUP_BY_DATE_DAILY -> SimpleDateFormat(Constant.dateFormat, Locale.ENGLISH)

            Constant.GROUP_BY_DATE_MONTHLY -> SimpleDateFormat("MMMM yyyy", Locale.ENGLISH)

            else -> SimpleDateFormat(Constant.dateFormat, Locale.ENGLISH)
        }
        try {
            // Group media data based on the selected grouping
            val dateWisePictures = linkedMapOf<String, ArrayList<MediaData>>()

            if (mediaList.isNotEmpty()) {
                mediaList.forEach { pictureData ->
                    // Determine the group key based on the current grouping type
                    val strKey = getGroupKey(pictureData, currentGrouping, format)

                    // Add the media item to the corresponding group
                    dateWisePictures.getOrPut(strKey) { ArrayList() }.add(pictureData)
                }

                // Get the keys and order them based on groupOrder
                val listKeys = ArrayList(dateWisePictures.keys).apply {
                    if (groupOrder == Constant.ORDER_DESCENDING) reverse()
                }

                // If no groups are formed, just add all media items to the list
                if (listKeys.isEmpty()) {
                    allList.addAll(mediaList)
                }

                // Add grouped media data to the final list
                listKeys.forEach { key ->
                    dateWisePictures[key]?.let { imagesData ->
                        if (imagesData.isNotEmpty()) {
                            allList.add(AlbumData(key, imagesData))
                            allList.addAll(imagesData)
                        }
                    }
                }
            }

            // Invoke the callback with the grouped media data
            onGroupComplete?.invoke(allList)

        } catch (e: Exception) {
            allList.addAll(mediaList)
            onGroupComplete?.invoke(allList)
            Log.e(TAG, "applyMediaGrouping Exception: $e")
        }

        Log.e(TAG, "applyMediaGrouping <<<<")
    }

    // Helper function to determine the group key based on the current grouping type
    private fun getGroupKey(pictureData: MediaData, currentGrouping: Int, format: SimpleDateFormat): String {
        return when (currentGrouping) {
            Constant.GROUP_BY_NONE -> ""
            Constant.GROUP_BY_DATE_DAILY -> format.format(getDayStartTS(pictureData.date, false))
//            Constant.GROUP_BY_DATE_TAKEN_DAILY -> format.format(getDayStartTS(pictureData.dateTaken, false))
            Constant.GROUP_BY_DATE_MONTHLY -> format.format(getDayStartTS(pictureData.date, true))
//            Constant.GROUP_BY_DATE_TAKEN_MONTHLY -> format.format(getDayStartTS(pictureData.dateTaken, true))
//            Constant.GROUP_BY_EXTENSION -> pictureData.fileName.getFilenameExtension().lowercase(Locale.getDefault())
//            Constant.GROUP_BY_FOLDER -> pictureData.filePath.getParentFolder().lowercase(Locale.getDefault())
//            Constant.GROUP_BY_FILE_TYPE -> getFileTypeString(pictureData.fileName)
            else -> format.format(getDayStartTS(pictureData.date, false))
        }
    }

    private fun getFileTypeString(fileName: String): String {
        Log.e("getFileTypeString", "getFileTypeString.001:$fileName")
        var stringId = R.string.images
        if (fileName.isImageFast() || fileName.isApng() || fileName.isPng()) stringId =
            R.string.images
        else if (fileName.isVideoFast()) stringId = R.string.videos
        else if (fileName.isPortrait()) stringId = R.string.portraits
        else if (fileName.isSvg()) stringId = R.string.svgs
        else if (fileName.isGif()) stringId = R.string.gifs

        return mContext.getString(stringId)
    }

    private fun getDayStartTS(ts: Long, resetDays: Boolean): Long {
        val calendar = Calendar.getInstance(Locale.ENGLISH).apply {
            timeInMillis = ts
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)

            if (resetDays) {
                set(Calendar.DAY_OF_MONTH, 1)
            }
        }

        return calendar.timeInMillis
    }

    fun applyAlbumSorting(
        albumList: ArrayList<AlbumData>,
        sortType: Int,
        sortOrder: Int,
        onSortingComplete: ((sortedList: ArrayList<AlbumData>) -> Unit)? = null
    ) {
        Log.e(TAG, "applyAlbumSorting size==>> ${albumList.size}")
        try {
            albumList.sortWith { p1, p2 ->
                when (sortType) {
                    Constant.SORT_NAME -> if (sortOrder == Constant.ORDER_ASCENDING)
                        p1.title.compareTo(p2.title, true) else p2.title.compareTo(p1.title, true)

//                    Constant.SORT_PATH -> if (sortOrder == Constant.ORDER_ASCENDING)
//                        p1.folderPath.compareTo(p2.folderPath, true) else p2.folderPath.compareTo(p1.folderPath, true)

                    Constant.SORT_SIZE -> if (sortOrder == Constant.ORDER_ASCENDING)
                        p1.fileSize.compareTo(p2.fileSize) else p2.fileSize.compareTo(p1.fileSize)

                    Constant.SORT_DATE-> if (sortOrder == Constant.ORDER_ASCENDING)
                        p1.date.compareTo(p2.date) else p2.date.compareTo(p1.date)

                    else -> p2.date.compareTo(p1.date)
                }
            }
            onSortingComplete?.invoke(albumList)
        } catch (e: Exception) {
            Log.e(TAG, "applyAlbumSorting Exception:$e")
        }
    }

    private fun getSelectionQuery(filterMedia: Int): String {
        val query = StringBuilder()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")

            rawExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
            }
        }

        if (filterMedia and TYPE_GIFS != 0) {
            query.append("${MediaStore.Images.Media.DATA} LIKE ? OR ")
        }
        return query.toString().trim().removeSuffix("OR")
    }

    private fun getSelectionArgsQuery(filterMedia: Int): ArrayList<String> {
        val args = ArrayList<String>()
        if (filterMedia and TYPE_IMAGES != 0) {
            photoExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.jpg")
            args.add("%.jpeg")
            rawExtensions.forEach {
                args.add("%$it")
            }
            args.add("%.svg")
        }

        if (filterMedia and TYPE_VIDEOS != 0) {
            videoExtensions.forEach {
                args.add("%$it")
            }
        }
        if (filterMedia and TYPE_GIFS != 0) {
            args.add("%.gif")
        }

        return args
    }

    fun destroyLoader() {
        mJob.cancel()
    }

}
