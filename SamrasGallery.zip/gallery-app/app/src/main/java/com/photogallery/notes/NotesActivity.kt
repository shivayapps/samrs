package com.photogallery.notes

import android.app.Activity
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.SearchView
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.photogallery.notes.adapter.NotesAdapter
import com.photogallery.notes.database.NotesDataBase
import com.photogallery.notes.entities.Notes
import com.photogallery.databinding.ActivityNotesBinding
import com.photogallery.extension.onTextChangeListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.photogallery.utils.MessageEvent
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.util.Locale

class NotesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNotesBinding
    var arrNotes = ArrayList<Notes>()
    var allBackList = ArrayList<Notes>()
    var notesAdapter: NotesAdapter = NotesAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNotesBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        binding.recyclerView.setHasFixedSize(true)
        binding.recyclerView.layoutManager = StaggeredGridLayoutManager(
            2,
            StaggeredGridLayoutManager.VERTICAL
        )
        binding.recyclerView.adapter = notesAdapter


        initNotes()

        notesAdapter.setOnClickListener(onClicked)

        // Find View By ID
//        val fabCreateNoteBtn = findViewById<FloatingActionButton>(R.id.fabCreateNoteBtn)

        // FAB CREATE NOTE FRAGMENT
        binding.fabCreateNoteBtn.setOnClickListener {
            startActivity(Intent(this, CreateNoteActivity::class.java))
            //activityLauncher.launch(Intent(this, CreateNoteActivity::class.java))
        }

        binding.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.icSearchClear.setOnClickListener {
            binding.searchView.setText("")

            if (binding.searchView.text.toString().isEmpty()) {
                binding.icSearchClear.visibility = View.GONE
//                binding.llSearch.beGone()
//                binding.llSuggestion.beVisible()
            } else {
                binding.icSearchClear.visibility = View.VISIBLE
//                binding.llSearch.beVisible()
//                binding.llSuggestion.beGone()
            }
            hideKeyboard(binding.searchView)
        }
        binding.searchView.onTextChangeListener { str ->
            if (str.isEmpty()) {
                binding.icSearchClear.visibility = View.GONE
                notesAdapter.filterList(str)
            } else {
                binding.icSearchClear.visibility = View.VISIBLE
                notesAdapter.filterList(str)
            }
        }

        if (!EventBus.getDefault().isRegistered(this)) EventBus.getDefault().register(this)

    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        if (event.type.equals("refresh_note")) {
            initNotes()
        }

    }

    fun hideKeyboard(view: EditText) {
        view.clearFocus()
        val methodManager = (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        methodManager.hideSoftInputFromWindow(view.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
    }

    private fun initNotes() {
        val notes = NotesDataBase.getDataBase(this@NotesActivity).noteDao().getAllNotes()
        arrNotes.clear()
        arrNotes.addAll(notes)

        allBackList.clear()
        allBackList.addAll(notes)

        Log.e("setSearch", "initNotes.arrNotes:${arrNotes.size}")
        Log.e("setSearch", "initNotes.allBackList:${allBackList.size}")
        notesAdapter.setData(allBackList)
        notesAdapter.notifyDataSetChanged()
    }

//    var activityLauncher =
//        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
//            initNotes()
//        }

    private val onClicked = object : NotesAdapter.onItemClickListener {
        override fun onClicked(notesId: Int) {
            startActivity(
                Intent(
                    this@NotesActivity,
                    CreateNoteActivity::class.java
                ).putExtra("noteId", notesId)
            )
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (EventBus.getDefault().isRegistered(this)) EventBus.getDefault().unregister(this)
    }

}