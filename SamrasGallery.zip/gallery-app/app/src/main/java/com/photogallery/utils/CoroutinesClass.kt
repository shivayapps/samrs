package com.photogallery.utils

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

val job = SupervisorJob()

val mainscope = CoroutineScope(Dispatchers.Main + job)
val ioScope = CoroutineScope(Dispatchers.IO + job)
val backgroundscope = CoroutineScope(Dispatchers.Default + job)

fun AsyncBackgroundWork(onPreWork: () -> Unit, onBackgroundWork: () -> Unit, onPostWork: () -> Unit) {
    mainscope.launch {
        onPreWork()
        backgroundscope.launch {
            onBackgroundWork()
            mainscope.launch {
                onPostWork()
            }
        }
    }
}