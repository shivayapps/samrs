package com.photogallery.jobs

import android.content.Context
import android.os.Build
import android.util.Log
import com.photogallery.GalleryApp
import com.photogallery.R
import com.photogallery.database.AppDatabase
import com.photogallery.extension.isApng
import com.photogallery.extension.isGif
import com.photogallery.extension.isImageFast
import com.photogallery.extension.isPng
import com.photogallery.extension.isPortrait
import com.photogallery.extension.isSvg
import com.photogallery.extension.isVideoFast
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.utils.Constant
import com.photogallery.utils.Preferences
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class PrivateLoader(
    private val mContext: Context,
    private var sortType: Int = Constant.SORT_DATE,
    private var sortOrder: Int = Constant.ORDER_DESCENDING,
    private var groupBy: Int = Constant.GROUP_BY_DATE_DAILY,
    private var groupOrder: Int = Constant.GROUP_BY_NONE,
    prefKey: String = "",
) {

    private var TAG = ""
    private var mJob: Job = Job()
    private var preferences: Preferences? = null
    private var dataBase: AppDatabase? = null

    private val albumList: ArrayList<AlbumData> = ArrayList()
    var allList = ArrayList<MediaData>()
    var pictures = ArrayList<Any>()

    fun refreshLoader(prefKey: String) {
        sortType = preferences?.getSortType(prefKey) ?: Constant.SORT_DATE
        sortOrder = preferences?.getSortOrder(prefKey) ?: Constant.ORDER_DESCENDING
        groupBy = preferences?.getGroupBy(prefKey) ?: Constant.GROUP_BY_DATE_DAILY
        groupOrder = preferences?.getGroupOrderBy(prefKey) ?: Constant.GROUP_BY_NONE
    }

    init {
        TAG = prefKey.ifEmpty { "MediaLoaderX" }
        preferences = GalleryApp.preferences

        dataBase = AppDatabase.getInstance(mContext)
        refreshLoader(prefKey)

    }

//    fun getAllAlbum(
//        onSuccess: ((albumList: ArrayList<AlbumData>, groupedMediaList: ArrayList<Any>, mediaList: ArrayList<MediaData>) -> Unit)? = null,
//        onFailed: ((error: String) -> Unit)? = null,
//    ) {
//
//        mJob = CoroutineScope(Dispatchers.IO).launch {
//            try {
//                val albums: ArrayList<AlbumData> = ArrayList()
//                val sortedMedia: ArrayList<MediaData> = ArrayList()
//                val groupMedia: ArrayList<Any> = ArrayList()
//                val allMedia: ArrayList<MediaData> = ArrayList()
//                allMedia.clear()
//                albumList.clear()
//
//                val hiddenList = dataBase?.vaultDao()?.getHiddenList(false)
//
//                if (!hiddenList.isNullOrEmpty()) {
//                    for (hiddenData in hiddenList) {
//                        val file = File(hiddenData.hidePath)
//                        val mediaData =
//                            MediaData(
//                                hiddenData.hidePath,
//                                file.name,
//                                hiddenData.folder,
//                                file.lastModified(),
//                                file.lastModified(),
//                                file.length(),
//                                Utils.isVideoFile(hiddenData.hidePath)
//                            )
//                        mediaData.isPrivate = true
//                        mediaData.isFavorite = false
//                        mediaData.isVideo = hiddenData.isVideo == 1
//                        mediaData.idDataBase = hiddenData.id
//                        mediaData.restorePath = hiddenData.restorePath
//                        if (mediaData.fileSize > 0) {
//                            allMedia.add(mediaData)
//                        }
//                    }
//                }
//
//                applyMediaSorting(allMedia, sortType, sortOrder) { media ->
//                    sortedMedia.addAll(media)
//
//                    val groupedMedia = sortedMedia.groupBy { it.folderName }
//                    Log.e(TAG, "groupedMedia size:${groupedMedia.size}")
//
//                    groupedMedia.forEach { (bucketPath, media) ->
//
//                        val folderName = media.first().folderName
//                        val folderSize = media.sumOf { it.fileSize }
//                        val albumData = AlbumData(
//                            title = folderName,
//                            mediaData = ArrayList(media),
//                            folderPath = bucketPath,
//                            date = media.maxOfOrNull { it.date } ?: 0L,
//                            fileSize = folderSize
//                        )
//                        albums.add(albumData)
//                    }
//
//                }
//
//                applyAlbumSorting(albums, sortType, sortOrder) { sortedAlbums ->
//                    albumList.addAll(sortedAlbums)
//                }
//
//                applyMediaGrouping(sortedMedia, groupBy, groupOrder) { groupedMediaList ->
//                    Log.e(TAG, "groupedMediaList==>> ${groupedMediaList.size}")
//                    groupMedia.addAll(groupedMediaList)
//                }
//
//                withContext(Dispatchers.Main) {
////                    onMediaListSuccess?.invoke(sortedMedia)
////                    onMediaFolderListSuccess?.invoke(customAlbumList)
//                    Log.e(TAG, "onSuccess?.invoke")
//                    onSuccess?.invoke(albumList, groupMedia, sortedMedia)
//                }
//
//            } catch (e: Exception) {
//                withContext(Dispatchers.Main) {
//                    onFailed?.invoke(e.message ?: "Error occurred while loading media.")
//                }
//            }
//        }
//    }

//    fun getAllData(
//        onSuccess: ((groupedMediaList: ArrayList<Any>, mediaList: ArrayList<MediaData>) -> Unit)? = null,
//        onFailed: ((error: String) -> Unit)? = null,
//    ) {
//
//        mJob = CoroutineScope(Dispatchers.IO).launch {
//            try {
//                val albums: ArrayList<AlbumData> = ArrayList()
//                val sortedMedia: ArrayList<MediaData> = ArrayList()
//                val groupMedia: ArrayList<Any> = ArrayList()
//
//                allList.clear()
//                val hiddenList = dataBase?.vaultDao()?.getHiddenList(false)
//
//                if (!hiddenList.isNullOrEmpty()) {
//                    for (hiddenData in hiddenList) {
//                        val file = File(hiddenData.hidePath)
//                        val mediaData =
//                            MediaData(
//                                hiddenData.hidePath,
//                                file.name,
////                                file.parentFile.name,
//                                hiddenData.folder,
//                                file.lastModified(),
//                                file.lastModified(),
//                                file.length(),
//                                Utils.isVideoFile(hiddenData.hidePath)
//                            )
//                        mediaData.isPrivate = true
//                        mediaData.isFavorite = false
//                        mediaData.isVideo = hiddenData.isVideo == 1
//                        mediaData.idDataBase = hiddenData.id
//                        mediaData.restorePath = hiddenData.restorePath
//                        if (mediaData.fileSize > 0) {
//                            allList.add(mediaData)
//                        } else {
////                            dataBase?.dataDao()?.removeRecentDelete(
////                                RecentDeleteData(
////                                    mediaData.idDataBase,
////                                    mediaData.filePath,
////                                    mediaData.restorePath
////                                )
////                            )
//                        }
//                    }
//                }
//
//                applyMediaSorting(allList, sortType, sortOrder) { media ->
//                    sortedMedia.addAll(media)
//
//                    val groupedMedia = sortedMedia.groupBy { it.folderName }
//                    Log.e(TAG, "groupedMedia size:${groupedMedia.size}")
//                    groupedMedia.forEach { (bucketPath, media) ->
//
//                        val folderName = media.first().folderName
//                        val folderSize = media.sumOf { it.fileSize }
//                        val albumData = AlbumData(
//                            title = folderName,
//                            mediaData = ArrayList(media),
//                            folderPath = bucketPath,
//                            date = media.maxOfOrNull { it.date } ?: 0L,
//                            fileSize = folderSize
//                        )
//                        albums.add(albumData)
//                    }
//                }
//
//                applyMediaGrouping(sortedMedia, groupBy, groupOrder) { groupedMediaList ->
//                    Log.e(TAG, "groupedMediaList==>> ${groupedMediaList.size}")
//                    groupMedia.addAll(groupedMediaList)
//                }
//
//                withContext(Dispatchers.Main) {
////                    onMediaListSuccess?.invoke(sortedMedia)
////                    onMediaFolderListSuccess?.invoke(customAlbumList)
//                    Log.e(TAG, "onSuccess?.invoke")
//                    onSuccess?.invoke(groupMedia, sortedMedia)
//                }
//
//            } catch (e: Exception) {
//                withContext(Dispatchers.Main) {
//                    onFailed?.invoke(e.message ?: "Error occurred while loading media.")
//                }
//            }
//        }
//    }

//    fun getFolderData(
//        albumData: AlbumData,
//        onSuccess: ((groupedMediaList: ArrayList<Any>, mediaList: ArrayList<MediaData>) -> Unit)? = null,
//        onFailed: ((error: String) -> Unit)? = null,
//    ) {
//
//        mJob = CoroutineScope(Dispatchers.IO).launch {
//            try {
////                val albums: ArrayList<AlbumData> = ArrayList()
//                val sortedMedia: ArrayList<MediaData> = ArrayList()
//                val groupMedia: ArrayList<Any> = ArrayList()
//
//                allList.clear()
//                val hiddenList = dataBase?.vaultDao()?.getHiddenFolderList(albumData.title, false)
//
//                if (!hiddenList.isNullOrEmpty()) {
//                    for (hiddenData in hiddenList) {
//                        val file = File(hiddenData.hidePath)
//                        val mediaData =
//                            MediaData(
//                                hiddenData.hidePath,
//                                file.name,
////                                file.parentFile.name,
//                                hiddenData.folder,
//                                file.lastModified(),
//                                file.lastModified(),
//                                file.length(),
//                                Utils.isVideoFile(hiddenData.hidePath)
//                            )
//                        mediaData.isPrivate = true
//                        mediaData.isFavorite = false
//                        mediaData.isVideo = hiddenData.isVideo == 1
//                        mediaData.idDataBase = hiddenData.id
//                        mediaData.restorePath = hiddenData.restorePath
//                        if (mediaData.fileSize > 0) {
//                            allList.add(mediaData)
//                        } else {
////                            dataBase?.dataDao()?.removeRecentDelete(
////                                RecentDeleteData(
////                                    mediaData.idDataBase,
////                                    mediaData.filePath,
////                                    mediaData.restorePath
////                                )
////                            )
//                        }
//                    }
//                }
//
//                applyMediaSorting(allList, sortType, sortOrder) { media ->
//                    sortedMedia.addAll(media)
//                }
//
//                applyMediaGrouping(sortedMedia, groupBy, groupOrder) { groupedMediaList ->
//                    Log.e(TAG, "groupedMediaList==>> ${groupedMediaList.size}")
//                    groupMedia.addAll(groupedMediaList)
//                }
//
//                withContext(Dispatchers.Main) {
////                    onMediaListSuccess?.invoke(sortedMedia)
////                    onMediaFolderListSuccess?.invoke(customAlbumList)
//                    Log.e(TAG, "onSuccess?.invoke")
//                    onSuccess?.invoke(groupMedia, sortedMedia)
//                }
//
//            } catch (e: Exception) {
//                withContext(Dispatchers.Main) {
//                    onFailed?.invoke(e.message ?: "Error occurred while loading media.")
//                }
//            }
//        }
//    }


    fun applyAlbumSorting(
        albumList: ArrayList<AlbumData>,
        sortType: Int,
        sortOrder: Int,
        onSortingComplete: ((sortedList: ArrayList<AlbumData>) -> Unit)? = null
    ) {
        Log.e(TAG, "applyAlbumSorting size==>> ${albumList.size}")
        try {
            albumList.sortWith { p1, p2 ->
                when (sortType) {
                    Constant.SORT_NAME -> if (sortOrder == Constant.ORDER_ASCENDING)
                        p1.title.compareTo(p2.title, true) else p2.title.compareTo(p1.title, true)

//                    Constant.SORT_PATH -> if (sortOrder == Constant.ORDER_ASCENDING)
//                        p1.folderPath.compareTo(p2.folderPath, true) else p2.folderPath.compareTo(p1.folderPath, true)

                    Constant.SORT_SIZE -> if (sortOrder == Constant.ORDER_ASCENDING)
                        p1.fileSize.compareTo(p2.fileSize) else p2.fileSize.compareTo(p1.fileSize)

                    Constant.SORT_DATE -> if (sortOrder == Constant.ORDER_ASCENDING)
                        p1.date.compareTo(p2.date) else p2.date.compareTo(p1.date)

                    else -> p2.date.compareTo(p1.date)
                }
            }
            onSortingComplete?.invoke(albumList)
        } catch (e: Exception) {
            Log.e(TAG, "applyAlbumSorting Exception:$e")
        }
    }

    fun applyMediaGrouping(
        mediaList: ArrayList<MediaData>,
        currentGrouping: Int,
        groupOrder: Int,
        onGroupComplete: ((groupedMediaList: ArrayList<Any>) -> Unit)? = null
    ) {
        Log.e(TAG, "applyMediaGrouping >>>>")
        val allList = ArrayList<Any>()
        val format = when (currentGrouping) {
            Constant.GROUP_BY_DATE_DAILY -> SimpleDateFormat(preferences?.dateFormat, Locale.ENGLISH)
//            Constant.GROUP_BY_DATE_TAKEN_DAILY -> SimpleDateFormat(preferences.dateFormat, Locale.ENGLISH)
            Constant.GROUP_BY_DATE_MONTHLY -> SimpleDateFormat("MMMM yyyy", Locale.ENGLISH)
//            Constant.GROUP_BY_DATE_TAKEN_MONTHLY -> SimpleDateFormat("MMMM yyyy", Locale.ENGLISH)
            else -> SimpleDateFormat(preferences?.dateFormat, Locale.ENGLISH)
        }
        try {
            // Group media data based on the selected grouping
            val dateWisePictures = linkedMapOf<String, ArrayList<MediaData>>()

            if (mediaList.isNotEmpty()) {
                mediaList.forEach { pictureData ->
                    // Determine the group key based on the current grouping type
                    val strKey = getGroupKey(pictureData, currentGrouping, format)

                    // Add the media item to the corresponding group
                    dateWisePictures.getOrPut(strKey) { ArrayList() }.add(pictureData)
                }

                // Get the keys and order them based on groupOrder
                val listKeys = ArrayList(dateWisePictures.keys).apply {
                    if (groupOrder == Constant.ORDER_DESCENDING) reverse()
                }

                // If no groups are formed, just add all media items to the list
                if (listKeys.isEmpty()) {
                    allList.addAll(mediaList)
                }

                // Add grouped media data to the final list
                listKeys.forEach { key ->
                    dateWisePictures[key]?.let { imagesData ->
                        if (imagesData.isNotEmpty()) {
                            allList.add(AlbumData(key, imagesData))
                            allList.addAll(imagesData)
                        }
                    }
                }
            }

            // Invoke the callback with the grouped media data
            onGroupComplete?.invoke(allList)

        } catch (e: Exception) {
            allList.addAll(mediaList)
            onGroupComplete?.invoke(allList)
            Log.e(TAG, "applyMediaGrouping Exception: $e")
        }

        Log.e(TAG, "applyMediaGrouping <<<<")
    }

    // Helper function to determine the group key based on the current grouping type
    private fun getGroupKey(pictureData: MediaData, currentGrouping: Int, format: SimpleDateFormat): String {
        return when (currentGrouping) {
            Constant.GROUP_BY_NONE -> ""
            Constant.GROUP_BY_DATE_DAILY -> format.format(getDayStartTS(pictureData.date, false))
//            Constant.GROUP_BY_DATE_TAKEN_DAILY -> format.format(getDayStartTS(pictureData.dateTaken, false))
            Constant.GROUP_BY_DATE_MONTHLY -> format.format(getDayStartTS(pictureData.date, true))
//            Constant.GROUP_BY_DATE_TAKEN_MONTHLY -> format.format(getDayStartTS(pictureData.dateTaken, true))
//            Constant.GROUP_BY_EXTENSION -> pictureData.fileName.getFilenameExtension().lowercase(Locale.getDefault())
//            Constant.GROUP_BY_FOLDER -> pictureData.filePath.getParentFolder().lowercase(Locale.getDefault())
//            Constant.GROUP_BY_FILE_TYPE -> getFileTypeString(pictureData.fileName)
            else -> format.format(getDayStartTS(pictureData.date, false))
        }
    }

    private fun getFileTypeString(fileName: String): String {
        Log.e("getFileTypeString", "getFileTypeString.001:$fileName")
        var stringId = R.string.images
        if (fileName.isImageFast() || fileName.isApng() || fileName.isPng()) stringId =
            R.string.images
        else if (fileName.isVideoFast()) stringId = R.string.videos
        else if (fileName.isPortrait()) stringId = R.string.portraits
        else if (fileName.isSvg()) stringId = R.string.svgs
        else if (fileName.isGif()) stringId = R.string.gifs

        return mContext.getString(stringId)
    }

    private fun getDayStartTS(ts: Long, resetDays: Boolean): Long {
        val calendar = Calendar.getInstance(Locale.ENGLISH).apply {
            timeInMillis = ts
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)

            if (resetDays) {
                set(Calendar.DAY_OF_MONTH, 1)
            }
        }

        return calendar.timeInMillis
    }

    fun destroyLoader() {
        mJob.cancel()
    }

}
