package com.photogallery.jobs

import java.io.File

data class FileModel(val file: File, var isSelected:Boolean=false)
