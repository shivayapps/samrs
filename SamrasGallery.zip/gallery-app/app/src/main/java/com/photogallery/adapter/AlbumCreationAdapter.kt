package com.photogallery.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import androidx.viewbinding.ViewBinding
import com.bumptech.glide.Glide
import com.photogallery.R
import com.photogallery.databinding.ItemAddAlbumBinding
import com.photogallery.model.AlbumData

class AlbumCreationAdapter(
    var context: Context,
    var list: ArrayList<AlbumData>,
    val clickListener: (pos: Int) -> Unit,
//    val layoutType: Int? = 0
) :
    RecyclerView.Adapter<AlbumCreationAdapter.ListViewHolder>() {

    var selectPos = -1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
//        if (layoutType == 1) {
        val binding =
            ItemAddAlbumBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ListViewHolder(binding)

    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {

        if (holder is ListViewHolder) {
            val binding = holder.binding as ItemAddAlbumBinding
            binding.tvName.text = list[position].title

            if (selectPos == position)
                binding.ivSelect.setImageDrawable(
                    ContextCompat.getDrawable(
                        context,
                        R.drawable.ic_select
                    )
                )
            else
                binding.ivSelect.setImageDrawable(
                    ContextCompat.getDrawable(
                        context,
                        R.drawable.ic_un_select
                    )
                )

            val albumData = list[position]
            binding.tvCount.visibility =
                if (albumData.isCustomAlbum) View.GONE else View.VISIBLE

            if (albumData.mediaData.isNotEmpty()) {
                binding.tvCount.text = "${albumData.mediaData.size}"

                Glide.with(context.applicationContext).load(albumData.mediaData[0].filePath)
                    .into(binding.image)

            } else {
                binding.tvCount.text = "0"
//                val materialShapeDrawable =
//                    MaterialShapeDrawable(binding.image.shapeAppearanceModel)
//                materialShapeDrawable.fillColor = ColorStateList.valueOf(ContextCompat.getColor(context, R.color.add_album_bg))
//                binding.image.setImageDrawable(materialShapeDrawable)
                binding.image.setImageDrawable(
                    ContextCompat.getDrawable(
                        context,
                        R.drawable.ic_image_placeholder
                    )
                )
            }

            if (albumData.isCustomAlbum && albumData.title == context.getString(R.string.add)) {
                binding.icAddAlbum.visibility = View.VISIBLE
                binding.image.visibility = View.GONE
            } else {
                binding.icAddAlbum.visibility = View.GONE
                binding.image.visibility = View.VISIBLE
            }
//            if (albumData.isCustomAlbum && albumData.title!=context.getString(R.string.add)){
//                binding.image.setImageDrawable(
//                    ContextCompat.getDrawable(
//                        context,
//                        R.drawable.ic_image_placeholder
//                    )
//                )
//            }
            binding.root.setOnClickListener {
                val p = selectPos
                selectPos = position
                clickListener(position)
                notifyItemChanged(selectPos)
                if (p != -1) {
                    notifyItemChanged(p)
                }
            }
        }

    }

    class ListViewHolder(var binding: ViewBinding) : RecyclerView.ViewHolder(binding.root) {}
//    class GridViewHolder(var binding: ViewBinding) : RecyclerView.ViewHolder(binding.root) {}
}