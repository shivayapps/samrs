package com.photogallery.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.photogallery.databinding.ItemDirsBinding

class DirectoryListAdapter(var context: Context, var list: ArrayList<String>, val clickListener: (pos: Int) -> Unit) : RecyclerView.Adapter<DirectoryListAdapter.ViewHolder>() {

//    var selectPos = 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemDirsBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.tvTitle.text = list[position]

//        if (selectPos == position)
//            holder.binding.ivSelect.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_check_on))
//        else
//            holder.binding.ivSelect.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_check_off))

        holder.binding.ivOption.setOnClickListener {
            clickListener(position)
        }

    }

    class ViewHolder(var binding: ItemDirsBinding) : RecyclerView.ViewHolder(binding.root) {

    }
}