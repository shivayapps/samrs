package com.photogallery.jobs

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import android.util.Log
import androidx.core.database.getLongOrNull
import androidx.core.database.getStringOrNull
import com.photogallery.database.AppDatabase
import com.photogallery.database.LocationEntity
import com.photogallery.extension.getParentFolder
import com.photogallery.model.MediaData
import com.photogallery.utils.Constant
import java.io.File

fun fetchImages1(context: Context): List<String> {
    val projection = arrayOf(
        MediaStore.Images.Media._ID,
        MediaStore.Images.Media.DISPLAY_NAME,
        MediaStore.Images.Media.DATE_ADDED
    )

    val sortOrder = "${MediaStore.Images.Media.DATE_ADDED} DESC"
    val limit = 15

    val imageList = mutableListOf<String>()

    val queryUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI

    context.contentResolver.query(queryUri, projection, null, null, "$sortOrder LIMIT $limit")?.use { cursor ->
        while (cursor.moveToNext()) {
            val imageId = cursor.getLongOrNull(cursor.getColumnIndex(MediaStore.Images.Media._ID))
            val imagePath =
                cursor.getStringOrNull(cursor.getColumnIndex(MediaStore.Images.Media.DATA))
            val contentUri = imageId?.let {
                ContentUris.withAppendedId(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    it
                )
            }
            imageList.add(contentUri.toString())
        }
    } ?: Log.e("FetchImages", "Cursor is null")

    return imageList

}

fun fetchRecentMedia(context: Context): List<MediaData> {
    val mediaList = ArrayList<MediaData>()
//    val mediaList = mutableListOf<String>()

    // Query images using MediaStore
    val projectionImage = arrayOf(
//        MediaStore.Images.Media._ID,
//        MediaStore.Images.Media.DATA
        MediaStore.Images.Media._ID,
        MediaStore.Images.Media.DATA,
        MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
        MediaStore.MediaColumns.DATE_MODIFIED,
        MediaStore.MediaColumns.DATE_TAKEN,
        MediaStore.MediaColumns.DISPLAY_NAME,
        MediaStore.MediaColumns.SIZE,
    )

    val fifteenDaysAgo = System.currentTimeMillis() - 15 * 24 * 60 * 60 * 1000

    val imageUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    val sortOrderImage = "${MediaStore.Images.Media.DATE_MODIFIED} DESC"
    val selectionImage = "${MediaStore.Images.Media.DATE_MODIFIED} >= ?"
    val selectionArgsImage = arrayOf((fifteenDaysAgo / 1000).toString())

    context.contentResolver.query(
        imageUri,
        projectionImage,
        selectionImage,
        selectionArgsImage,
        sortOrderImage
    )?.use { cursor ->

        cursor.use {
            while (it.moveToNext()) {

                val path = it.getString(it.getColumnIndexOrThrow(MediaStore.Images.Media.DATA))
                val title = it.getString(it.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME))
                val bucketPath = path.substring(0, path.lastIndexOf(title) - 1)

                var bucketName = it.getString(it.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME)) ?: path.getParentFolder()
                if (bucketPath == Constant.ROOT_PATH) bucketName = "Root"

                val fileSize = it.getLong(it.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)).takeIf { size -> size > 0 } ?: File(path).length()
                val date = it.getLong(it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)) * 1000
                val dateTaken = it.getLong(it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)) * 1000

                val idColumn = it.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val id = it.getLong(idColumn)
                val contentUri = ContentUris.withAppendedId(imageUri, id)


                if (fileSize > 0) {
                    val mediaData = MediaData(
                        filePath = path,
                        fileUri = contentUri.toString(),
                        fileName = title, folderName = bucketName, date = date,
                        bucketPath = bucketPath, dateTaken = dateTaken.takeIf { it > 0 } ?: date, fileSize = fileSize
                    )
                    mediaList.add(mediaData)
                }
            }
        }

    } ?: Log.e("FetchUtils", "Cursor is null")

    val videoUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
    val sortOrderVideo = "${MediaStore.Images.Media.DATE_MODIFIED} DESC"
    val selectionVideo = "${MediaStore.Video.Media.DATE_MODIFIED} >= ?"
    val selectionArgsVideo = arrayOf((fifteenDaysAgo / 1000).toString())

    val projectionVideo = arrayOf(
        MediaStore.Video.VideoColumns._ID,
        MediaStore.Video.VideoColumns.DATA,
        MediaStore.Video.Media.DISPLAY_NAME,
        MediaStore.Video.VideoColumns.SIZE,
        MediaStore.Video.VideoColumns.DURATION,
        MediaStore.Video.VideoColumns.DATE_MODIFIED,
        MediaStore.Video.VideoColumns.DATE_TAKEN,
        MediaStore.MediaColumns.BUCKET_DISPLAY_NAME
    )

    context.contentResolver.query(
        videoUri,
        projectionVideo,
        selectionVideo,
        selectionArgsVideo,
        sortOrderVideo
    )?.use { cursor ->
        cursor.use {
            while (it.moveToNext()) {
                val path = it.getString(it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA))
                val title = it.getString(it.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME))
                val bucketPath = path.substring(0, path.lastIndexOf(title) - 1)

                var bucketName = it.getString(it.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME)) ?: path.getParentFolder()
                if (bucketPath == Constant.ROOT_PATH) bucketName = "Root"

                val fileSize = it.getLong(it.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)).takeIf { size -> size > 0 } ?: File(path).length()
                val date = it.getLong(it.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DATE_MODIFIED)) * 1000
                val dateTaken = it.getLong(it.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)) * 1000
                val duration = it.getLong(it.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DURATION))

                val idColumn = it.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val id = it.getLong(idColumn)
                val contentUri = ContentUris.withAppendedId(imageUri, id)

                if (fileSize > 0) {
                    val mediaData = MediaData(
                        filePath = path, fileUri = contentUri.toString(), fileName = title, folderName = bucketName, date = date,
                        dateTaken = dateTaken.takeIf { it > 0 } ?: date, fileSize = fileSize,
                        bucketPath = bucketPath, isVideo = true, videoDuration = duration
                    )

                    mediaList.add(mediaData)
                }
            }
        }
    } ?: Log.e("FetchUtils", "Cursor is null")

    return mediaList

}

fun fetchRecentPlace(context: Context): List<LocationEntity> {
    val sortedUniquePlaces = try {
        val dataBase = AppDatabase.getInstance(context)
        val places = dataBase.dataDao().getLocationEntityList()
        places.sortedByDescending { it.locationId }
            .distinctBy { it.title } ?: emptyList()
    } catch (e: Exception) {
        emptyList()
    }
    return sortedUniquePlaces.shuffled()
}

fun fetchImages(context: Context): List<String> {
    val imageList = mutableListOf<String>()

    imageList.addAll(fetchImagesFromFolder(context, "/DCIM/Camera"))

    return imageList
}

private fun fetchImagesFromFolder(context: Context, folderPath: String): List<String> {
    val imageList = mutableListOf<String>()

    // Query images using MediaStore
    val projection = arrayOf(
        MediaStore.Images.Media._ID,
        MediaStore.Images.Media.DATA
    )

    val selection = "${MediaStore.Images.Media.DATA} like ?"
    val selectionArgs = arrayOf("%$folderPath%")

    val sortOrder = "${MediaStore.Images.Media.DATE_MODIFIED} DESC"
    val uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI

    context.contentResolver.query(
        uri,
        projection,
        selection,
        selectionArgs,
        sortOrder
    )?.use { cursor ->
        while (cursor.moveToNext()) {
            val imageId = cursor.getLongOrNull(cursor.getColumnIndex(MediaStore.Images.Media._ID))
            val imagePath = cursor.getStringOrNull(cursor.getColumnIndex(MediaStore.Images.Media.DATA))
            val contentUri = imageId?.let {
                ContentUris.withAppendedId(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    it
                )
            }
            imageList.add(contentUri.toString())
        }
    } ?: Log.e("FetchImages", "Cursor is null")

    return imageList
}

