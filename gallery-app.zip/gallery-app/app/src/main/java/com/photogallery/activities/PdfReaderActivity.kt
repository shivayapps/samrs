package com.photogallery.activities

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isVisible
import com.adconfig.adsutil.Config.checkReInter
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.BannerAdHelper
import com.canhub.cropper.parcelable
import com.github.barteksc.pdfviewer.scroll.DefaultScrollHandle
import com.google.android.gms.ads.AdView
import com.photogallery.R
import com.photogallery.base.BaseActivity
import com.photogallery.base.BaseNoThemeActivity
import com.photogallery.databinding.ActivityPdfReaderBinding
import com.photogallery.dialog.JumpPageDialog
import com.photogallery.dialog.PdfBrightnessDialog
import com.photogallery.extension.getFilenameFromPath
import com.photogallery.model.PdfModel
import com.photogallery.utils.AdCache
import com.photogallery.utils.Constant
import com.photogallery.utils.MessageEvent
import com.photogallery.utils.Preferences
import com.photogallery.utils.Utils
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File

class PdfReaderActivity : BaseNoThemeActivity() {

    private var pdfPath: String? = null
    private var pdfName: String? = null
    private var pdfUri: Uri? = null
    private var isOutside = false

    private val fullScreenFlags =
        View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

    private val normalFlags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE

    var isDarkMode = false
    var currentPage = 0

    lateinit var preferences: Preferences
    lateinit var binding: ActivityPdfReaderBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityPdfReaderBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        preferences = Preferences(this)
        if (preferences.isNeedInterAd) {
            AdmobIntersAdImpl().load(this, getString(R.string.inter_all))
        } else {
            checkReInter {
                if (it) {
                    AdmobIntersAdImpl().load(this, getString(R.string.inter_all))
                    preferences.isNeedInterAd = true
                }
            }
        }

        pdfPath = intent.getStringExtra("pdfPath")
        pdfName = intent.getStringExtra("pdfName")

        pdfUri = intent.parcelable("pdfUri")
        isOutside = intent.getBooleanExtra("isOutside", false)

        loadBanner()
        if (!EventBus.getDefault().isRegistered(this)) EventBus.getDefault().register(this)

        if (savedInstanceState != null) {
            currentPage = savedInstanceState.getInt("CURRENT_PAGE", 0)
        }
        intView()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (EventBus.getDefault().isRegistered(this)) EventBus.getDefault().unregister(this)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageEvent) {
        if (event.type.equals("refresh")) {
        }
    }

    var isAdLoaded = false
    var mAdView: AdView? = null
    override fun onResume() {
        super.onResume()
        mAdView?.resume()

    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }

    private fun loadBanner() {
        if (!isAdLoaded) {

            val adId = getString(R.string.b_imageListActivity)
            BannerAdHelper.showBanner(
                this,
                binding.layoutBanner.mFLAd,
                binding.layoutBottomAd,
                adId,
                AdCache.imageListAdView,
                { isLoaded, adView, message ->
                    if (!isDestroyed) {
                        mAdView = adView
                        AdCache.imageListAdView = adView
                        isAdLoaded = isLoaded
                    }
                })
        }
    }

    fun changeMode(isDarkMode: Boolean) {
        if (isDarkMode) {
            binding.customPdfView.setNightMode(true)
            binding.root.setBackgroundColor(
                Color.parseColor("#161616")
            )
            binding.loutSelectOption.setBackgroundColor(
                Color.parseColor("#1F1F1F")
            )
            binding.ivDarkMode.setImageResource(R.drawable.ic_light_mode)

            binding.ivRotate.setColorFilter(Color.parseColor("#FFFFFF"))
            binding.ivDarkMode.setColorFilter(Color.parseColor("#FFFFFF"))
            binding.ivBrightness.setColorFilter(Color.parseColor("#FFFFFF"))
            binding.ivSwipe.setColorFilter(Color.parseColor("#FFFFFF"))
            binding.ivJump.setColorFilter(Color.parseColor("#FFFFFF"))
            binding.icBack.setColorFilter(Color.parseColor("#FFFFFF"))
            binding.icShare.setColorFilter(Color.parseColor("#FFFFFF"))

            binding.txtTitle.setTextColor(Color.parseColor("#FFFFFF"))
            binding.tvRotate.setTextColor(Color.parseColor("#FFFFFF"))
            binding.tvDarkMode.setTextColor(Color.parseColor("#FFFFFF"))
            binding.tvBrightness.setTextColor(Color.parseColor("#FFFFFF"))
            binding.tvSwipe.setTextColor(Color.parseColor("#FFFFFF"))
            binding.tvJump.setTextColor(Color.parseColor("#FFFFFF"))
        } else {
            binding.customPdfView.setNightMode(false)
            binding.root.setBackgroundColor(
                Color.parseColor("#F1F1F1")
            )
            binding.loutSelectOption.setBackgroundColor(
                Color.parseColor("#FFFFFFFF")
            )
            binding.ivDarkMode.setImageResource(R.drawable.ic_dark_mode)

            binding.ivRotate.setColorFilter(Color.parseColor("#FF0E1217"))
            binding.ivDarkMode.setColorFilter(Color.parseColor("#FF0E1217"))
            binding.ivBrightness.setColorFilter(Color.parseColor("#FF0E1217"))
            binding.ivSwipe.setColorFilter(Color.parseColor("#FF0E1217"))
            binding.ivJump.setColorFilter(Color.parseColor("#FF0E1217"))
            binding.icBack.setColorFilter(Color.parseColor("#FF0E1217"))
            binding.icShare.setColorFilter(Color.parseColor("#FF0E1217"))

            binding.txtTitle.setTextColor(Color.parseColor("#FF0E1217"))
            binding.tvRotate.setTextColor(Color.parseColor("#FF0E1217"))
            binding.tvDarkMode.setTextColor(Color.parseColor("#FF0E1217"))
            binding.tvBrightness.setTextColor(Color.parseColor("#FF0E1217"))
            binding.tvSwipe.setTextColor(Color.parseColor("#FF0E1217"))
            binding.tvJump.setTextColor(Color.parseColor("#FF0E1217"))
        }

    }

    fun intView() {
        binding.icBack.setOnClickListener {
            onBackPressed()
        }

        val themeType = Preferences(this).getThemeValue()
        when (themeType) {
            Constant.THEME_LIGHT -> {
                isDarkMode = false
            }

            Constant.THEME_DARK -> {
                isDarkMode = true
            }
        }
        changeMode(isDarkMode)

        if (pdfName != null && pdfPath != null) {
            setupPdfViewWithFile()
        } else if (pdfUri != null) {
            setupPdfViewWithUri()
        } else {
            Toast.makeText(this, "Error Occurred", Toast.LENGTH_SHORT).show()
            finish()
        }

    }

    private fun setUpViewActions() {
        binding.btnDarkMode.setOnClickListener {
            isDarkMode = !isDarkMode
            changeMode(isDarkMode)
        }


        binding.btnRotate.setOnClickListener {
            requestedOrientation = if (resources.configuration.orientation == 1) {
                ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            } else {
                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            }

        }

        binding.btnBrightness.setOnClickListener {
            showBrightnessDialog()
        }


        binding.btnSwipe.setOnClickListener {
            if (binding.customPdfView.isPageFlingEnabled) {
                binding.customPdfView.setPageFling(false)
                binding.ivSwipe.setImageResource(R.drawable.ic_multi_swipe)
                Toast.makeText(this, "Multi Swipe Enabled", Toast.LENGTH_SHORT).show()
            } else {
                binding.customPdfView.setPageFling(true)
                binding.ivSwipe.setImageResource(R.drawable.ic_single_swipe)
                Toast.makeText(this, "Single Swipe Enabled", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnJump.setOnClickListener {
            showJumpDialog()
        }

        binding.icShare.setOnClickListener {
            Utils.sharePDF(this,pdfPath!!)
        }
    }

    private fun setupPdfViewWithUri() {

        binding.customPdfView
            .fromUri(pdfUri)
            .onTap {
                if (binding.loutToolbar.isVisible) {
                    hideActionUI()
                } else {
                    showActionUI()
                }
                true
            }
            .enableSwipe(true)
            .swipeHorizontal(false)
            .enableDoubletap(true)
            .defaultPage(currentPage)
            .enableAnnotationRendering(true)
            .password(null)
            .scrollHandle(DefaultScrollHandle(this))
            .enableAntialiasing(true)
            .nightMode(isDarkMode)
            .spacing(0)
            .load()

        val contentResolver = contentResolver
        val projection = {
            arrayOf(
                android.provider.MediaStore.Files.FileColumns._ID,
                android.provider.MediaStore.Files.FileColumns.DISPLAY_NAME,
                android.provider.MediaStore.Files.FileColumns.SIZE,
                android.provider.MediaStore.Files.FileColumns.DATE_ADDED
            )
        }
        val cursor = contentResolver.query(
            pdfUri!!,
            projection(),
            null,
            null,
            null
        )
        var title: String? = null

        if (cursor != null) {
            cursor.moveToFirst()

            title =
                cursor.getString(cursor.getColumnIndexOrThrow(android.provider.MediaStore.Files.FileColumns.DISPLAY_NAME))

            cursor.close()
        }

        binding.txtTitle.text = resizeName(title!!)
        binding.icShare.visibility = View.GONE

        setUpViewActions()

    }

    private fun setupPdfViewWithFile() {

        binding.txtTitle.text = pdfPath?.getFilenameFromPath()
        val file = File(pdfPath!!)

        binding.customPdfView
            .fromFile(file)
            .onTap {
                if (binding.loutToolbar.isVisible) {
                    hideActionUI()
                } else {
                    showActionUI()
                }
                true
            }
            .enableSwipe(true)
            .swipeHorizontal(false)
            .enableDoubletap(true)
            .defaultPage(currentPage)
            .nightMode(isDarkMode)
            .enableAnnotationRendering(true)
            .password(null)
            .scrollHandle(DefaultScrollHandle(this))
            .enableAntialiasing(true)
            .spacing(0)
            .load()


        setUpViewActions()

    }

    fun showActionUI() {
        binding.loutToolbar.visibility = View.VISIBLE
        binding.loutBottom.visibility = View.VISIBLE
        window.decorView.systemUiVisibility = normalFlags
    }

    fun hideActionUI() {
        binding.loutToolbar.visibility = View.GONE
        binding.loutBottom.visibility = View.GONE
        window.decorView.systemUiVisibility = fullScreenFlags
    }

    fun resizeName(s: String): String {
        if (s.length <= 32) {
            return s
        }
        val first = s.substring(0, 18)
        val last = s.substring(s.length - 10, s.length)
        return "$first...$last"
    }

    private fun showJumpDialog() {

        val totalPage = binding.customPdfView.pageCount
        val currentPage = binding.customPdfView.currentPage + 1
        val jumpPageDialog = JumpPageDialog(this, currentPage, totalPage, { pageNumber ->
            binding.customPdfView.jumpTo(pageNumber - 1, true)
        })
        jumpPageDialog.show()

    }

    private fun showBrightnessDialog() {

        val layoutParams = window.attributes
        val currentBrightness = if (layoutParams.screenBrightness < 0) { // Use system brightness
            android.provider.Settings.System.getInt(
                contentResolver, android.provider.Settings.System.SCREEN_BRIGHTNESS
            ).toFloat() / 255
        } else {
            layoutParams.screenBrightness
        }
        val pdfBrightnessDialog = PdfBrightnessDialog(this, currentBrightness, { progress ->
            val brightness = progress.toFloat() / 100
            layoutParams.screenBrightness = brightness
            window.attributes = layoutParams
        })
        pdfBrightnessDialog.show()

    }

    override fun onBackPressed() {
        if (isOutside) {
            startActivity(Intent(this, HomeActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            })
            finish()
        } else {
            super.onBackPressed()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("CURRENT_PAGE", binding.customPdfView.currentPage)
    }

}