package com.photogallery.dialog

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import com.photogallery.databinding.DialogCopyMoveBinding
import com.photogallery.utils.DIALOG_DIM_AMOUNT

class CopyMoveDialog(
    var mContext: Activity,
    val clickListener: (option: Int) -> Unit
) : Dialog(mContext) {

    lateinit var bindingDialog: DialogCopyMoveBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        window?.setDimAmount(DIALOG_DIM_AMOUNT)
        window?.attributes?.windowAnimations = android.R.style.Animation_Dialog
//        window?.decorView!!.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        bindingDialog = DialogCopyMoveBinding.inflate(layoutInflater)
//        bindingDialog.root.setPadding(0, 0, 0, mContext.navigationBarHeight)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
        intListener()
        setCancelable(false)
        setCanceledOnTouchOutside(false)
    }


    private fun intView() {

    }

    private fun intListener() {

        bindingDialog.btMove.setOnClickListener {
            clickListener.invoke(0)
            dismiss()
        }
        bindingDialog.btCopy.setOnClickListener {
            clickListener.invoke(1)
            dismiss()
        }
        bindingDialog.icClose.setOnClickListener {
            //clickListener.invoke(1)
            dismiss()
        }

    }


}

