package com.photogallery.spananimation

import android.view.ScaleGestureDetector
import android.view.animation.DecelerateInterpolator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.SimpleItemAnimator
//import com.smart.photomanager.helper.ZOOM_IN_THRESHOLD
//import com.smart.photomanager.helper.ZOOM_OUT_THRESHOLD

class SmoothItemAnimatorController(
    private val recyclerView: RecyclerView,
    //private val layoutManager: GridLayoutManager
) {

    private var minSpan = 1
    private var maxSpan = 6
    private var scaleGestureEnabled = true
    private var listener: ((Int) -> Unit)? = null

    private var scaleGestureDetector: ScaleGestureDetector

    private var lastSpanCount = layoutManager?.spanCount ?: 3
    private var scaleFactorAccum = 1f

    private val layoutManager: GridLayoutManager?
        get() = recyclerView.layoutManager as? GridLayoutManager

    init {
        recyclerView.itemAnimator = SmoothItemAnimator()
        lastSpanCount = layoutManager?.spanCount ?: 3

        scaleGestureDetector = ScaleGestureDetector(
            recyclerView.context,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {

                override fun onScale(detector: ScaleGestureDetector): Boolean {
                    if (!scaleGestureEnabled) return false

                    scaleFactorAccum *= detector.scaleFactor

                    if (scaleFactorAccum > 0.1f && lastSpanCount > minSpan) {
                        // Zoom in → reduce span count
                        updateSpanCount(lastSpanCount - 1)
                        scaleFactorAccum = 1f
                    } else if (scaleFactorAccum < 0.1f && lastSpanCount < maxSpan) {
                        // Zoom out → increase span count
                        updateSpanCount(lastSpanCount + 1)
                        scaleFactorAccum = 1f
                    }
                    return true
                }
            })

        recyclerView.setOnTouchListener { _, event ->
            scaleGestureDetector.onTouchEvent(event)
            false
        }
    }

    fun setSpanRange(min: Int, max: Int) {
        minSpan = min
        maxSpan = max
    }

    fun setScaleGestureEnabled(enabled: Boolean) {
        scaleGestureEnabled = enabled
    }

    fun setOnSpanCountChangedListener(block: (Int) -> Unit) {
        listener = block
    }

    private fun updateSpanCount(newCount: Int) {
        if (newCount != lastSpanCount) {
            layoutManager?.spanCount = newCount
            recyclerView.requestLayout()
            lastSpanCount = newCount
            listener?.invoke(newCount)
        }
    }

    private class SmoothItemAnimator : SimpleItemAnimator() {
        override fun animateMove(
            holder: RecyclerView.ViewHolder,
            fromX: Int, fromY: Int,
            toX: Int, toY: Int
        ): Boolean {
            val view = holder.itemView
            val deltaY = toY - fromY

            if (deltaY != 0) {
                view.translationY = -deltaY.toFloat()
                view.animate()
                    .translationY(0f)
                    .setDuration(900L)
                    .setInterpolator(DecelerateInterpolator())
                    .start()
            }
            return false
        }

        override fun runPendingAnimations() {}
        override fun endAnimation(item: RecyclerView.ViewHolder) {}
        override fun endAnimations() {}
        override fun isRunning(): Boolean = false
        override fun animateRemove(holder: RecyclerView.ViewHolder?): Boolean = false
        override fun animateAdd(holder: RecyclerView.ViewHolder?): Boolean = false
        override fun animateChange(
            oldHolder: RecyclerView.ViewHolder?, newHolder: RecyclerView.ViewHolder?,
            fromLeft: Int, fromTop: Int, toLeft: Int, toTop: Int
        ): Boolean = false
    }
}
