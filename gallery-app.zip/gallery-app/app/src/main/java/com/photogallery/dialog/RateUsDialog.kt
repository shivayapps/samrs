package com.photogallery.dialog

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import com.adconfig.AdsConfig
import com.google.android.play.core.review.ReviewInfo
import com.google.android.play.core.review.ReviewManager
import com.google.android.play.core.review.ReviewManagerFactory
import com.photogallery.R
import com.photogallery.databinding.DialogRateUsBinding
import com.photogallery.extension.sendEmail
import com.photogallery.utils.DIALOG_DIM_AMOUNT
import com.photogallery.utils.Preferences


import java.lang.ref.WeakReference


class RateUsDialog(var mContext: Activity,
                   val clickListener: (isExit: Boolean) -> Unit
) : Dialog(mContext) {

//    var btnClickListener: ((Int) -> Unit?)? =null
    lateinit var binding: DialogRateUsBinding
    private var rate: Float = 0f

    lateinit var preferences: Preferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        window?.setDimAmount(DIALOG_DIM_AMOUNT)
        window?.attributes?.windowAnimations = android.R.style.Animation_Dialog

        binding = DialogRateUsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT
        )
        preferences = Preferences(mContext)
        AdsConfig.isSystemDialogOpen = true
        intView()
    }



    private fun intView() {
        binding.txtTitle.text = mContext.getString(R.string.rate_title_good)
        //binding.ivTop.setImageResource(R.drawable.rate_four)
        binding.btnOk.isEnabled = false
        binding.btnOk.alpha = 0.5f

        binding.btRatingBar.setOnRatingChangeListener { _, rating, _ ->
            rate = rating
            binding.btnOk.isEnabled = true
            binding.btnOk.alpha = 1f

//            when (rating) {
//                0f -> {
//                    binding.txtTitle.text = mContext.getString(R.string.rate_title_good)
////                    binding.ivTop.setImageResource(R.drawable.rate_four)
//                    binding.btnOk.isEnabled = false
//                    binding.btnOk.alpha = 0.5f
//                }
//
//                1f -> {
//                    binding.txtTitle.text = mContext.getString(R.string.rate_title_fair)
////                    binding.ivTop.setImageResource(R.drawable.rate_one)
//                }
//
//                2f -> {
//                    binding.txtTitle.text = mContext.getString(R.string.rate_title_fair)
////                    binding.ivTop.setImageResource(R.drawable.rate_two)
//                }
//
//                3f -> {
//                    binding.txtTitle.text = mContext.getString(R.string.rate_title_good)
////                    binding.ivTop.setImageResource(R.drawable.rate_three)
//                }
//
//                4f -> {
//                    binding.txtTitle.text = mContext.getString(R.string.rate_title_good)
////                    binding.ivTop.setImageResource(R.drawable.rate_four)
//                }
//
//                5f -> {
//                    binding.txtTitle.text = mContext.getString(R.string.rate_title_good)
////                    binding.ivTop.setImageResource(R.drawable.rate_five)
//                }
//            }
        }
        intListener()
    }


    private fun showInAppRateDialogInternal(
        reviewManager: ReviewManager,
        activity: Activity,
        reviewInfo: ReviewInfo
    ) {
        val reviewFlow = reviewManager.launchReviewFlow(activity, reviewInfo)
        val activityRef = WeakReference(activity)
        reviewFlow.addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val fragmentActivity = activityRef.get()
                if (fragmentActivity != null) {
                    lauchAppStore(activity)
//                    storeRateResult(fragmentActivity, RateUsState.IGNORED)
                }
            } else {
//                log.error(task.exception)
            }
        }
    }


    private fun showInAppRateDialog(activity: Activity) {

        val reviewManager = ReviewManagerFactory.create(activity)
        val activityRef = WeakReference(activity)
        val requestReview = reviewManager.requestReviewFlow()
        requestReview.addOnCompleteListener { task ->

            if (task.isSuccessful) {
                val fragmentActivity = activityRef.get()
                if (fragmentActivity != null) {
                    showInAppRateDialogInternal(
                        reviewManager,
                        fragmentActivity,
                        task.result
                    )
                }
            } else {
//                log.error(task.exception)
            }
        }
    }

    private fun intListener() {
        binding.btnOk.setOnClickListener {
            if (rate >= 4) {
                preferences.isRatingDone=true
//                PrefUtils.storeBoolean(activity, Const.RATE_US_DIALOG, true)
                showInAppRateDialog(mContext)
                dismiss()
            } else if (rate <= 3 && rate.toInt() != 0) {

                mContext.sendEmail("makavanavivek304@gmail.com", "GalleryApp Feedback/Suggestion", "Message:\n")
//                val intent = Intent(activity, FeedBackActivity::class.java)
//                activity.startActivity(intent)
                dismiss()
            }
            clickListener.invoke(true)
//            PrefUtils.storeBoolean(activity, Const.RATE_US_DIALOG, true)
        }

        binding.ivClose.setOnClickListener {
            dismiss()
            clickListener.invoke(false)
//            PrefUtils.storeBoolean(activity, Const.RATE_US_DIALOG, true)
        }
    }

    private fun lauchAppStore(activity: Activity) {
        activity.startActivity(
            Intent(
                Intent.ACTION_VIEW,
                Uri.parse("http://play.google.com/store/apps/details?id=${activity.packageName}")
            )
        )
    }


}