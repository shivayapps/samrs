package com.photogallery.notes.dao

import androidx.room.*
import com.photogallery.notes.entities.Notes


@Dao
interface NoteDao {

    @Query("SELECT * FROM notes ORDER BY id DESC")
    fun getAllNotes(): List<Notes>

    @Query("SELECT * FROM notes WHERE id = :id")
    fun getSpecificNote(id: Int): Notes

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertNotes(note: Notes)

    @Delete
    fun deleteNotes(note: Notes)

    @Query("DELETE FROM notes WHERE id = :id")
    fun deleteSpecificNote(id: Int)

    @Update
    fun updateNotes(note: Notes)


}