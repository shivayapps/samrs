package com.photogallery.notes.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.photogallery.database.AppDatabase
import com.photogallery.notes.dao.NoteDao
import com.photogallery.notes.entities.Notes
import com.photogallery.utils.Constant

@Database(entities = [Notes::class], version = 1, exportSchema = false)
abstract class NotesDataBase : RoomDatabase() {

    companion object {

        var notesDataBase: NotesDataBase? = null

        @Synchronized
        fun getDataBase(context: Context): NotesDataBase {

            if (notesDataBase == null) {
//                notesDataBase = Room.databaseBuilder(context, NotesDataBase::class.java, "notes.db").build()
                notesDataBase = Room.databaseBuilder(
                    context,
                    NotesDataBase::class.java,
                    "gallery_notes.dbcrypt"
//                    Constant.ROOT_PATH + "/.Gallery/database.dbcrypt"
                )
                    .allowMainThreadQueries()
                    .build()
            }
            return notesDataBase!!
        }
    }

    abstract fun noteDao(): NoteDao
}