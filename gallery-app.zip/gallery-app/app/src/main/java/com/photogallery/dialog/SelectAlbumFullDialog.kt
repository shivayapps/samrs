package com.photogallery.dialog

import android.app.Activity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.photogallery.R
import com.photogallery.adapter.AlbumCreationAdapter
import com.photogallery.databinding.DialogAddAlbumFullBinding
import com.photogallery.extension.toast
import com.photogallery.model.AlbumData
import com.photogallery.utils.Preferences

class SelectAlbumFullDialog(
    var mContext: Activity,
    var albumDataList: ArrayList<AlbumData>,
    var selectedAlbum: ArrayList<AlbumData>,
    var isCopy: Boolean,
    val selectPathListener: (path: String) -> Unit,
    val createAlbumListener: () -> Unit
) : DialogFragment() {

    lateinit var binding: DialogAddAlbumFullBinding
    lateinit var albumAdapter: AlbumCreationAdapter
    var albumList: ArrayList<AlbumData> = ArrayList()
    var selectPos = -1
    var preferences: Preferences = Preferences(mContext)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NORMAL, R.style.FullScreenDialog)
    }

    override fun onStart() {
        super.onStart()
        val dialog = dialog
        if (dialog != null) {
            val width = ViewGroup.LayoutParams.MATCH_PARENT
            val height = ViewGroup.LayoutParams.MATCH_PARENT
            dialog.window!!.setLayout(width, height)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        super.onCreateView(inflater, container, savedInstanceState)
        binding = DialogAddAlbumFullBinding.inflate(layoutInflater, container, false)

        intView()

        return binding.root
    }

    private fun intView() {

        if (isCopy)
            binding.txtTitle.text = mContext.getString(R.string.copy_to_album)
        else
            binding.txtTitle.text = mContext.getString(R.string.move_to_album)

//        val newAlbum = preferences.getLastAlBumCreated()
//        Log.e("newAlbum", "getLastAlBumCreated:$newAlbum")
//        if (newAlbum.isNotEmpty()) {
//            albumList.add(
//                AlbumData(
//                    newAlbum.getFilenameFromPath(),
//                    folderPath = newAlbum,
//                    isCustomAlbum = true
//                )
//            )
//        }
        albumDataList.removeAll(selectedAlbum)
        albumList.addAll(albumList.size, albumDataList)
        albumList.add(AlbumData(mContext.getString(R.string.add), isCustomAlbum = true))

        initAdapter()
        initListener()
    }

    private fun initListener() {
        binding.btnClose.setOnClickListener {
            dismiss()
        }
        binding.btnDone.setOnClickListener {
            if (selectPos >= 0) {
                val albumData = albumList[selectPos]
                if (albumData.isCustomAlbum) {
                    if (albumData.title == mContext.getString(R.string.add)) {
                        dismiss()
                        createAlbumListener()
                    } else if (albumData.folderPath.isNotEmpty()) {
                        dismiss()
                        selectPathListener(albumData.folderPath)
                    }
                } else {
                    dismiss()
                    selectPathListener(albumData.folderPath)
                }
            } else {
                mContext.toast(getString(R.string.PleaseSelectAlbum))
            }
//            dismiss()
        }
    }

    private fun initAdapter() {
        albumAdapter = AlbumCreationAdapter(mContext, albumList, clickListener = {
            selectPos = it


        })
        val gridLayoutManager = GridLayoutManager(mContext, 3, RecyclerView.VERTICAL, false)
        binding.albumRecycler.layoutManager = gridLayoutManager
        binding.albumRecycler.adapter = albumAdapter
    }


}
