package com.photogallery.activities


import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.activity.enableEdgeToEdge
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.adconfig.AdsConfig
import com.photogallery.R
import com.photogallery.base.BaseActivity
import com.photogallery.databinding.ActivityPermissionBinding
import com.photogallery.extension.toast
import com.photogallery.utils.Constant
import com.photogallery.utils.LogEvent
import com.photogallery.utils.Preferences
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class PermissionActivity : BaseActivity() {

    lateinit var binding: ActivityPermissionBinding
    lateinit var preferences: Preferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPermissionBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        preferences = Preferences(this)
        init()
    }

    private fun init() {

        binding.txtMsg.text = getString(R.string.permission_msg)
        if (checkStoragePermission())
            startNextScreen()

        binding.btnAllow.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    requestNotification()
                } else requestStoragePermission()
            } else {
                requestPermission()
            }
        }
    }

    private fun requestNotification() {
        val list: ArrayList<String> = ArrayList()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            list.add(android.Manifest.permission.POST_NOTIFICATIONS)
        }

        Dexter.withContext(this)
            .withPermissions(
                list
            )
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport?) {
                    report?.let {
                        requestStoragePermission()
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: MutableList<PermissionRequest>?,
                    token: PermissionToken?
                ) {
                    token?.continuePermissionRequest()
                }
            }).check()
    }

    private fun startNextScreen() {
        val calendar = Calendar.getInstance()
        val format = SimpleDateFormat("dd/mm/yy", Locale.ENGLISH)
        val today = format.format(calendar.timeInMillis)
        LogEvent.logEvent("PermissionActivity", "startNextScreen:$today")

        if (!preferences.isSetLanguage) {
            val intent = Intent(this, LanguageSelectionActivity::class.java)
                .putExtra(Constant.EXTRA_IS_OPEN_FROM_SPLASH, true)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            startActivity(intent)
        } else {
            val intent = Intent(this, HomeActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            startActivity(intent)
        }
    }

    private fun requestPermission() {

        val list: ArrayList<String> = ArrayList()

        list.add(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            list.add(android.Manifest.permission.ACCESS_MEDIA_LOCATION)
        }

        Dexter.withContext(this)
            .withPermissions(
                list
            )
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport?) {
                    report?.let {
                        if (report.areAllPermissionsGranted()) {
                            startNextScreen()
                        } else if (report.isAnyPermissionPermanentlyDenied) {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                            val uri = Uri.fromParts("package", packageName, null)
                            intent.data = uri
                            permissionLauncher.launch(intent)
                        } else {
                            toast(
                                getString(R.string.permission_toast_msg)
                            )
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: MutableList<PermissionRequest>?,
                    token: PermissionToken?
                ) {
                    token?.continuePermissionRequest()
                }
            }).check()

    }

    var permissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { _ ->
            if (checkStoragePermission())
                startNextScreen()
            else
                requestPermission()
        }

    var permissionActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {

        } else {
            if (Environment.isExternalStorageManager()) {
                startNextScreen()
            }
        }
    }

    private fun requestStoragePermission() {
        try {
            val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
            intent.addCategory("android.intent.category.DEFAULT")
            intent.data = Uri.parse("package:$packageName")
            AdsConfig.isSystemDialogOpen = true
            permissionActivityResultLauncher.launch(intent)
            handler.postDelayed(checkSettingOn, 1000)
        } catch (e: Exception) {
            val intent = Intent()
            intent.action = Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION
            permissionActivityResultLauncher.launch(intent)
            handler.postDelayed(checkSettingOn, 1000)
        }
    }

    var handler: Handler = Handler(Looper.myLooper()!!)
    var checkSettingOn: Runnable = object : Runnable {
        override fun run() {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
                return
            } else {
                if (Environment.isExternalStorageManager()) {
                    startNextScreen()
                    return
                }
                handler.postDelayed(this, 200)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
    }
}