package com.photogallery.event

import com.photogallery.model.RestoreData
import java.util.ArrayList

data class RestoreDataEvent(var restoreList: ArrayList<RestoreData>)
