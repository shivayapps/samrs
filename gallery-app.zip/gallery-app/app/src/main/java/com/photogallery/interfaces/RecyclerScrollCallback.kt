package com.photogallery.interfaces

interface RecyclerScrollCallback {
    fun onScrolled(scrollY: Int)
}
