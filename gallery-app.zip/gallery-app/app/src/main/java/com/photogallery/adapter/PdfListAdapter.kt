package com.photogallery.adapter

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.photogallery.R
import com.photogallery.databinding.ItemPdfListBinding
import com.photogallery.dialog.PdfOptionDialog
import com.photogallery.extension.getFilenameFromPath
import com.photogallery.model.PdfModel
import com.photogallery.utils.Preferences
import com.photogallery.utils.Utils

class PdfListAdapter(
    var context: Activity,
    val clickListener: (pos: Int, pdfModel: PdfModel) -> Unit,
    val optionListener: (option: Int, pdfModel: PdfModel) -> Unit
) : ListAdapter<PdfModel, RecyclerView.ViewHolder>(DiffCallBack()) {

    private class DiffCallBack : DiffUtil.ItemCallback<PdfModel>() {
        override fun areItemsTheSame(oldItem: PdfModel, newItem: PdfModel) = oldItem == newItem

        @SuppressLint("DiffUtilEquals")
        override fun areContentsTheSame(oldItem: PdfModel, newItem: PdfModel) = oldItem == newItem
    }


    var preferences: Preferences = Preferences(context)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = ItemPdfListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PdfListViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        holder.itemView.tag = holder
        if (holder is PdfListViewHolder) {
            val pdfModel: PdfModel = getItem(position) as PdfModel

            holder.binding.txtTitle.text = pdfModel.filePath.getFilenameFromPath()
            holder.binding.txtPath.text = pdfModel.filePath
            holder.binding.root.setOnClickListener {
                clickListener(position, pdfModel)
            }
            holder.binding.ivOption.setOnClickListener {
                PdfOptionDialog(context, { option ->
                    optionListener.invoke(option,pdfModel)

                }).show(holder.binding.ivOption)
            }
        }
    }

    class PdfListViewHolder(var binding: ItemPdfListBinding) :
        RecyclerView.ViewHolder(binding.root)

}