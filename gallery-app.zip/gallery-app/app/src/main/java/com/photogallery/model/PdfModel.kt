package com.photogallery.model

data class PdfModel(
    val name: String,
    val filePath: String,
    val folder: String,
    var isFavorite: Boolean = false,
    var isSelected: Boolean = false
)
