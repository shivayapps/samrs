package com.photogallery.recover

import android.app.ProgressDialog
import android.content.Context
import android.graphics.BitmapFactory
import android.os.AsyncTask
import android.os.Environment
import android.os.Handler
import android.os.Message
import android.util.Log
import com.photogallery.extension.isImageFast
import com.photogallery.extension.isVideoFast
import com.photogallery.model.MediaData
import com.photogallery.utils.Utils
import java.io.File

class ScannerAsyncTask(private val context: Context, private val handler: Handler?) :
    AsyncTask<String, Int, ArrayList<MediaData>>() {

    private val alImageData: ArrayList<MediaData> = ArrayList()
    private var progressDialog: ProgressDialog? = null
    var i = 0


    override fun onPreExecute() {
        super.onPreExecute()
    }

    override fun doInBackground(vararg params: String): ArrayList<MediaData> {
        val fileType = params[0]
        val dirPath: String = Environment.getExternalStorageDirectory().absolutePath
        Log.d(TAG, "doInBackground: path: $dirPath")
        checkFileOfDirectory(getFileList(dirPath), fileType)
        return alImageData
    }

    override fun onProgressUpdate(vararg values: Int?) {
        super.onProgressUpdate(*values)
        if (handler != null) {
            val message = Message.obtain()
            message.what = com.photogallery.recover.Config.UPDATE
            message.obj = alImageData.size
            handler.sendMessage(message)
        }
    }


    override fun onPostExecute(arrayList: ArrayList<MediaData>) {
        if (progressDialog != null) {
            progressDialog!!.cancel()
            progressDialog = null
        }
        if (handler != null) {
            val message = Message.obtain()
            message.what = com.photogallery.recover.Config.DATA
            message.obj = arrayList
            handler.sendMessage(message)
        }
        super.onPostExecute(arrayList)
    }

    fun checkFileOfDirectory(fileArr: Array<File>?, fileType: String) {
        if (fileArr == null) return
        for (i in fileArr.indices) {
            val numArr = arrayOfNulls<Int>(1)
            val i2 = this.i
            this.i = i2 + 1
            numArr[0] = i2
            publishProgress(*numArr)
            if (fileArr[i].isDirectory) {
                checkFileOfDirectory(getFileList(fileArr[i].path), fileType)
            } else {
                val options = BitmapFactory.Options()
                options.inJustDecodeBounds = true
                BitmapFactory.decodeFile(fileArr[i].path, options)
                if (!(options.outWidth == -1 || options.outHeight == -1)) {
                    Log.d(TAG, "checkFileOfDirectory: " + fileArr[i].path)

                    val file1 = File(fileArr[i].path)
                    if (fileArr[i].isImageFast()) {

                        val pictureData = MediaData(
                            file1.path,
                            Utils.getUriFromPath(context,file1.path).toString(),
                            file1.name,
                            file1.parentFile.name,
                            file1.lastModified(),
                            file1.lastModified(),
                            file1.length()
                        )
                        this.alImageData.add(pictureData);
                    } else if (fileArr[i].isVideoFast()) {
                        val pictureData = MediaData(
                            file1.path,
                            Utils.getUriFromPath(context,file1.path).toString(),
                            file1.name,
                            file1.parentFile.name,
                            file1.lastModified(),
                            file1.lastModified(),
                            file1.length(),
                            isVideo = true
                        )
                        this.alImageData.add(pictureData);
                    }

                }
            }
        }
    }

    fun getFileList(str: String?): Array<File>? {
        val file = File(str)
        return if (!file.isDirectory) {
            null
        } else file.listFiles()
    }

    companion object {
        private const val TAG = "ScannerAsyncTask_"
    }
}
