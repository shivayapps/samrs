package com.photogallery.asynctasks

import android.content.Context
import android.os.AsyncTask
import com.photogallery.utils.Preferences


class TrashAsynctask(
    val context: Context,
    val callback: (isComplete: Boolean) -> Unit
) :
    AsyncTask<Void, Void, Boolean>() {

    val config = Preferences(context)

    override fun doInBackground(vararg params: Void): Boolean {


        return true
    }

    override fun onPostExecute(isComplete: Boolean) {
        super.onPostExecute(isComplete)
        callback(isComplete)
    }

    fun stopFetching() {
        cancel(true)
    }
}
