package com.photogallery.notes

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Patterns
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.photogallery.R
import com.photogallery.databinding.DialogEdittextBinding
import com.photogallery.extension.toast
import com.photogallery.utils.DIALOG_DIM_AMOUNT

class EditTextDialog(
    var mContext: Activity,
    val btnClickListener: (stringText: String) -> Unit
) : Dialog(mContext) {

    lateinit var bindingDialog: DialogEdittextBinding

//    override fun onCreateView(
//        inflater: LayoutInflater, container: ViewGroup?,
//        savedInstanceState: Bundle?
//    ): View {
//        bindingDialog = DialogEdittextBinding.inflate(layoutInflater, container, false)
//        intView()
//        intListener()
//        return bindingDialog.root
//    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        window?.setDimAmount(DIALOG_DIM_AMOUNT)
//        window?.decorView!!.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        bindingDialog = DialogEdittextBinding.inflate(layoutInflater)
//        bindingDialog.root.setPadding(0, 0, 0, mContext.navigationBarHeight)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
        intListener()
    }

    private fun intView() {
        bindingDialog.edtText.text!!.clear()
    }

    private fun intListener() {

        bindingDialog.btnCancel.setOnClickListener { dismiss() }

        bindingDialog.btnOk.setOnClickListener {
            val str = bindingDialog.edtText.text.toString().trim()
            if (str.isNotEmpty()) {
                checkWebUrl()
//                btnClickListener.invoke(str)
            } else {
                mContext.toast("Please enter valid text")
            }
        }
    }

    private fun checkWebUrl() {
        if (Patterns.WEB_URL.matcher(bindingDialog.edtText.text.toString()).matches()) {
            //bindingDialog.layoutWebUrl.visibility = View.GONE
//            bindingDialog.etWebLink.isEnabled = false
//            webLink = binding.etWebLink.text.toString()
//            bindingDialog.tvWebLink.visibility = View.VISIBLE
//            bindingDialog.tvWebLink.text = binding.etWebLink.text.toString()
            btnClickListener.invoke(bindingDialog.edtText.text.toString())
            dismiss()
        } else {
            Toast.makeText(mContext, "Url is not Valid", Toast.LENGTH_SHORT).show()
        }
    }

//    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
//    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
//        BottomSheetDialog(requireContext(), theme)
}

