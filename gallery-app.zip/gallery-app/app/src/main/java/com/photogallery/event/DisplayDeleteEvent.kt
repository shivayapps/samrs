package com.photogallery.event

import java.util.ArrayList

data class DisplayDeleteEvent(var deleteList: ArrayList<String> , var isFromFav:Boolean = false)
