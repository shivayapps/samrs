package com.photogallery.dialog

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import com.photogallery.databinding.DialogSortingBinding
import com.photogallery.utils.Constant
import com.photogallery.utils.DIALOG_DIM_AMOUNT
import com.photogallery.utils.Preferences

class SortingOptionsDialog(val mContext: Context, val folderPath:String?="", val updateListener: () -> Unit) :
    Dialog(mContext) {

    lateinit var bindingDialog: DialogSortingBinding
    lateinit var preferences: Preferences
    var sortType = 0
    var sortOrder = 0

//    override fun onCreateView(
//        inflater: LayoutInflater, container: ViewGroup?,
//        savedInstanceState: Bundle?
//    ): View {
//        bindingDialog = DialogSortingBinding.inflate(layoutInflater, container, false)
//        intView()
//        return bindingDialog.root
//    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        window?.setDimAmount(DIALOG_DIM_AMOUNT)
        window?.attributes?.windowAnimations = android.R.style.Animation_Dialog
//        window?.decorView!!.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        bindingDialog = DialogSortingBinding.inflate(layoutInflater)
//        bindingDialog.root.setPadding(0, 0, 0, mContext.navigationBarHeight)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        intView()
    }

    private fun intView() {
        preferences = Preferences(mContext)
        sortType = preferences.getSortType(folderPath)
        sortOrder = preferences.getSortOrder(folderPath)

//        if(folderPath.equals("frag_0")) {
//            sortType = preferences.getSortType("frag_0")
//            sortOrder = preferences.getSortOrder("frag_0")
//        }

//        if(folderPath.isNullOrEmpty() || folderPath.startsWith("frag_")) {
//            bindingDialog.cbFolderOnly.beGone()
//            bindingDialog.dividerFolder.beGone()
//        }

        intListener()

        when (sortType) {
            Constant.SORT_NAME -> bindingDialog.rbName.isChecked = true
//            Constant.SORT_PATH -> bindingDialog.rbPath.isChecked = true
            Constant.SORT_SIZE -> bindingDialog.rbSize.isChecked = true
            Constant.SORT_DATE -> bindingDialog.rbDate.isChecked = true
//            Constant.SORT_DATE_TAKEN -> bindingDialog.rbDateTaken.isChecked = true
        }

        when (sortOrder) {
            Constant.ORDER_ASCENDING -> bindingDialog.rbAscending.isChecked = true
            Constant.ORDER_DESCENDING -> bindingDialog.rbDescending.isChecked = true
        }

//        if(folderPath.isNullOrEmpty() || folderPath.startsWith("frag_")) {
//            bindingDialog.cbFolderOnly.beGone()
//            bindingDialog.dividerFolder.beGone()
//        }
    }


    private fun intListener() {
        bindingDialog.btnCancel.setOnClickListener {
            dismiss()
        }
        bindingDialog.btnOK.setOnClickListener {
            val selectedRadioButtonId: Int = bindingDialog.grpOption.checkedRadioButtonId
            val selectedRadioButtonIdOrder: Int = bindingDialog.grpOrder.checkedRadioButtonId
            var selectedType = -1
            var selectedOrder = -1
            selectedType = when (selectedRadioButtonId) {
                bindingDialog.rbName.id -> Constant.SORT_NAME
//                bindingDialog.rbPath.id -> Constant.SORT_PATH
                bindingDialog.rbSize.id -> Constant.SORT_SIZE
                bindingDialog.rbDate.id -> Constant.SORT_DATE
//                bindingDialog.rbDateTaken.id -> Constant.SORT_DATE_TAKEN
                else -> -1
            }
            selectedOrder = when (selectedRadioButtonIdOrder) {
                bindingDialog.rbAscending.id -> Constant.ORDER_ASCENDING
                bindingDialog.rbDescending.id -> Constant.ORDER_DESCENDING
                else -> -1
            }
//            if (sortType != selectedType)
                preferences.setSortType(selectedType)
                preferences.setSortType(selectedType,folderPath)

//                preferences.setAlbumSortOrder(selectedOrder)
                preferences.setSortOrder(selectedOrder)
                preferences.setSortOrder(selectedOrder,folderPath)

//            if (bindingDialog.cbFolderOnly.isChecked)
//                preferences.setAlbumSortOrder(selectedOrder,folderPath)
//            else {
//                preferences.setAlbumSortOrder(selectedOrder)
//                preferences.setSortOrder(selectedOrder)
//            }

            dismiss()

            updateListener.invoke()
        }
    }

}