package com.photogallery.interfaces;

public interface OnImageScanListener {
    void onImageScan(int value);
    void onScanCompleted();
}