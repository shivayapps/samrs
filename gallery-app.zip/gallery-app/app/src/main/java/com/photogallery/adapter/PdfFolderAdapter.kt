package com.photogallery.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.photogallery.R
import com.photogallery.adapter.PdfFolderAdapter.PdfListViewHolder
import com.photogallery.databinding.ItemPdfFolderBinding

class PdfFolderAdapter(
    private val context: Context,
    private val clickListener: (pos: Int, selectedFolder: String) -> Unit
) : ListAdapter<String, PdfListViewHolder>(DiffCallBack()) {

    private var selectedFolder = "All Pdf"
    private var selectedPos = 0

    private class DiffCallBack : DiffUtil.ItemCallback<String>() {
        override fun areItemsTheSame(oldItem: String, newItem: String) = oldItem == newItem

        @SuppressLint("DiffUtilEquals")
        override fun areContentsTheSame(oldItem: String, newItem: String) = oldItem == newItem
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PdfListViewHolder {
        val binding = ItemPdfFolderBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PdfListViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PdfListViewHolder, position: Int, payloads: List<Any>) {
        if (payloads.isNotEmpty() && payloads.contains("SELECTION")) {
            bindSelection(holder, position)
        } else {
            onBindViewHolder(holder, position)
        }
    }

    override fun onBindViewHolder(holder: PdfListViewHolder, position: Int) {
        val folder = getItem(position)
        holder.binding.txtTitle.text = folder
        bindSelection(holder, position)

        holder.binding.root.setOnClickListener {
            if (selectedPos != position) {
                val previousSelected = selectedPos
                selectedFolder = folder
                selectedPos = position
                if (previousSelected >= 0) {
                    notifyItemChanged(previousSelected, "SELECTION")
                }
                notifyItemChanged(selectedPos, "SELECTION")
                clickListener(position, folder)
            }
        }
    }

    private fun bindSelection(holder: PdfListViewHolder, position: Int) {
        //val folder = getItem(position)
        val isSelected = position == selectedPos
        if (isSelected) {
            holder.binding.llBg.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#1878F3"))
            holder.binding.ivIcon.setImageResource(R.drawable.ic_folder_open)
            holder.binding.ivIcon.imageTintList = ColorStateList.valueOf(Color.parseColor("#FFFFFF"))
            holder.binding.txtTitle.setTextColor(Color.parseColor("#FFFFFF"))
        } else {
            holder.binding.llBg.backgroundTintList = null
            holder.binding.llBg.background = context.resources.getDrawable(R.drawable.bg_top)
            holder.binding.ivIcon.setImageResource(R.drawable.ic_folder)
            holder.binding.ivIcon.imageTintList = ColorStateList.valueOf(ContextCompat.getColor(context, R.color.black_text))
            holder.binding.txtTitle.setTextColor(ContextCompat.getColor(context, R.color.black_text))
        }
//        holder.binding.llBg.backgroundTintList = ColorStateList.valueOf(
//            if (isSelected) Color.parseColor("#1878F3") else Color.parseColor("#FFFFFF")
//        )
//        holder.binding.ivIcon.setImageResource(if (isSelected) R.drawable.ic_folder_open else R.drawable.ic_folder)
    }

    class PdfListViewHolder(val binding: ItemPdfFolderBinding) :
        RecyclerView.ViewHolder(binding.root)
}
