package com.photogallery.dialog

//import com.example.customview.AppOpenManager
//import com.example.customview.adconfig.NativeAdHelper.mMainNative
//import com.example.customview.adconfig.NativeAdHelper.showMainNativeAd
import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import android.widget.Toast
import com.adconfig.AdsConfig
import com.photogallery.databinding.DialogJumpPageBinding
import com.photogallery.utils.DIALOG_DIM_AMOUNT

class JumpPageDialog(
    val activity: Activity,
    val currentPage: Int,
    val totalPage: Int,
    val clickListener: (pageNo: Int) -> Unit
) : Dialog(activity) {

    lateinit var binding: DialogJumpPageBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setGravity(Gravity.BOTTOM)
        window?.setDimAmount(DIALOG_DIM_AMOUNT)
        window?.attributes?.windowAnimations = android.R.style.Animation_Dialog

        binding = DialogJumpPageBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT
        )
        AdsConfig.isSystemDialogOpen = true

        binding.pageNumbers.text = "($currentPage - $totalPage)"
        binding.edtText.setText("$currentPage")

        binding.btnCancel.setOnClickListener {
            dismiss()
        }
        binding.btnOK.setOnClickListener {
            val pageNumber = binding.edtText.text.toString().toInt()
            if (pageNumber in 1..totalPage) {
                clickListener.invoke(pageNumber)
                dismiss()
            } else {
                Toast.makeText(activity, "Invalid Page Number", Toast.LENGTH_SHORT).show()
            }
        }

    }


}