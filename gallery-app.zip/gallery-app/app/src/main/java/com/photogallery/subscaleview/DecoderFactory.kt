package com.photogallery.subscaleview

interface DecoderFactory<T> {
    fun make(): T
}
