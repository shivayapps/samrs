package com.photogallery.utils
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class CompressUtils {
    fun compressImage(context: Context, sourceImagePath: String, maxImageSize: Int, quality: Int): String? {
        try {
            // Read the image file and decode it into a Bitmap
            val options = BitmapFactory.Options()
            options.inJustDecodeBounds = true
            BitmapFactory.decodeFile(sourceImagePath, options)

            // Calculate the inSampleSize based on the desired maximum image size
            options.inSampleSize = calculateInSampleSize(options, maxImageSize, maxImageSize)
            options.inJustDecodeBounds = false

            val decodedBitmap = BitmapFactory.decodeFile(sourceImagePath, options)

            // Get the orientation of the image from the Exif data
            val exif = ExifInterface(sourceImagePath)
            val orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_UNDEFINED)

            // Rotate the Bitmap to the correct orientation
            val rotatedBitmap = rotateBitmap(decodedBitmap, orientation)

            // Compress the Bitmap to a file
            val compressedImagePath = getCompressedImageFilePath(context)
            val fileOutputStream = FileOutputStream(compressedImagePath)
            rotatedBitmap.compress(Bitmap.CompressFormat.JPEG, quality, fileOutputStream)
            fileOutputStream.close()

            return compressedImagePath
        } catch (e: IOException) {
            Log.e("printStackTrace","printStackTrace:$e")
        }
        return null
    }

    fun calculateInSampleSize(options: BitmapFactory.Options, reqWidth: Int, reqHeight: Int): Int {
        val height = options.outHeight
        val width = options.outWidth
        var inSampleSize = 1

        if (height > reqHeight || width > reqWidth) {
            val halfHeight = height / 2
            val halfWidth = width / 2

            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2
            }
        }

        return inSampleSize
    }

    fun rotateBitmap(bitmap: Bitmap, orientation: Int): Bitmap {
        val matrix = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> Matrix().apply { postRotate(90f) }
            ExifInterface.ORIENTATION_ROTATE_180 -> Matrix().apply { postRotate(180f) }
            ExifInterface.ORIENTATION_ROTATE_270 -> Matrix().apply { postRotate(270f) }
            else -> Matrix()
        }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    fun getCompressedImageFilePath(context: Context): String {
        val cacheDir = context.cacheDir
        return File.createTempFile("compressed_image_", ".jpg", cacheDir).absolutePath
    }
}