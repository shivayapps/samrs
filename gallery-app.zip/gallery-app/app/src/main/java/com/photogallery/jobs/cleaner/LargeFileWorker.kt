package com.photogallery.jobs.cleaner

import android.content.Context
import android.os.Build
import android.util.Log
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.utils.Constant
import com.photogallery.utils.STOP_LARGE_JUNK
import com.photogallery.utils.UPDATE_LARGE_JUNK
import com.photogallery.utils.UPDATE_LARGE_SIZE
import com.photogallery.utils.sendEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

suspend fun Context.startLargeFileWorker(allMedia: List<MediaData>) {
    LargeFileWorker.doWork(this, allMedia)
}

object LargeFileWorker {

    var largePhotoData: Map<String, List<MediaData>> = emptyMap()
    private var isLargeRunning = false
    var totalCounter: Float = 0F
    var scanCounter: Int = 0
    var largeSize = 0L

    suspend fun doWork(context: Context, allMedia: List<MediaData>) {

        totalCounter = ((allMedia.size).toFloat())

        val pictures = ArrayList<Any>()
        if (allMedia.isEmpty()) return

//        CoroutineScope(Dispatchers.IO).launch {
        if (!isLargeRunning) {
            isLargeRunning = true

            if (Constant.largeRealPhotoData.isNotEmpty()) {
                setFilterLarge()
            } else {
                val largefile = allMedia.filter { it.fileSize > 1e+7 }   //greater than 10Mb
//                val largefile = allMedia.filter { it.fileSize > (10 * 1024 * 1024) }   //greater than 10Mb
                Log.e("Cleaner.LargeFileWorker", "largefile:${largefile.size}")
                largePhotoData = groupPhotoDataBySize(largefile.sortedBy { it.fileSize })
                val bucketKeys: Set<String> = largePhotoData.keys
                val listFolderkeys = java.util.ArrayList(bucketKeys)
                listFolderkeys.reverse()
                Log.e("Cleaner.LargeFileWorker", "RealPhotoData 003 listFolderkeys:${listFolderkeys.size}==>${listFolderkeys}")
                for (index in listFolderkeys.indices) {

                    var list = largePhotoData[listFolderkeys[index]]
                    val bucketData = AlbumData(
                        title = listFolderkeys[index],
                        folderPath = listFolderkeys[index],
//                        mediaData = list as ArrayList<MediaData>,
                        isCustomAlbum = true,
                        isCheckboxVisible = true
                    )
                    list = list!!.sortedByDescending { it.fileSize }
                    pictures.add(bucketData)
                    pictures.addAll(list.toMutableList())

                }
                Log.e("Cleaner.LargeFileWorker", "RealPhotoData largeRealPhotoData==>${pictures.size}")
                val totalFileSize = pictures
                    .filterIsInstance<MediaData>()
                    .sumOf { it.fileSize }
                largeSize = totalFileSize
                Constant.largeRealPhotoData = pictures
                setFilterLarge()
            }
            sendEvent(STOP_LARGE_JUNK)
        }
//        }
    }

    fun groupPhotoDataBySize(photoData: List<MediaData>): Map<String, List<MediaData>> {
        return photoData.groupBy {
            when {
                it.fileSize in 20 * 1024 * 1024..30 * 1024 * 1024 -> "30-20 MB"
                it.fileSize in 30 * 1024 * 1024..50 * 1024 * 1024 -> "50-30 MB"
                it.fileSize in 50 * 1024 * 1024..70 * 1024 * 1024 -> "70-50 MB"
                it.fileSize in 70 * 1024 * 1024..100 * 1024 * 1024 -> "100-70 MB"
                it.fileSize in 100 * 1024 * 1024..500 * 1024 * 1024 -> "500-100 MB"
                it.fileSize in 500 * 1024 * 1024..1024 * 1024 * 1024 -> "1024-500 MB"
                it.fileSize > 1024 * 1024 * 1024 -> "1+ GB"
                else -> "20-10 MB"
            }
        }
    }

    private fun setFilterLarge() {
        Log.e("Cleaner.LargeFileWorker", "setFilterDuplicate:001")
        val pictures = ArrayList<Any>()
        pictures.addAll(Constant.largeRealPhotoData)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            pictures.removeIf { item ->
                item is MediaData && !File(item.filePath).exists()
            }
        } else {
            val iterator = pictures.iterator()
            while (iterator.hasNext()) {
                val item = iterator.next()
                if (item is MediaData && !File(item.filePath).exists()) {
                    iterator.remove()
                }
            }
        }


        //remove empty album
        val indicesToRemove = mutableListOf<Int>()
        for (i in pictures.indices) {
            if (pictures[i] is AlbumData) {
                var hasMediaData = false

                for (j in (i + 1) until pictures.size) {
                    if (pictures[j] is MediaData) {
                        hasMediaData = true
                    } else if (pictures[j] is AlbumData) {
                        break
                    }
                }
                if (!hasMediaData) {
                    indicesToRemove.add(i)
                }
            }
        }
        for (index in indicesToRemove.reversed()) {
            pictures.removeAt(index)
        }

        Constant.largeRealPhotoData = pictures


        val ssSize = pictures.filterIsInstance<MediaData>().size
        val totalFileSize = pictures
            .filterIsInstance<MediaData>()
            .sumOf { it.fileSize }
        largeSize = totalFileSize
        Log.e("Cleaner.DuplicateWorker", "largeSize:$largeSize")
        updatePercentage()

        val sizePair = Pair(totalFileSize.toLong(), ssSize.toInt())
        isLargeRunning = false
        sendEvent(UPDATE_LARGE_SIZE, sizePair)
        Log.e("Cleaner.LargeFileWorker", "setFilterDuplicate:002")
    }

    private fun updatePercentage() {
        val percent: Float = 0f
        Log.e("Cleaner.LargeFileWorker", "updatePercentage:${percent},$scanCounter,$totalCounter")
        sendEvent(UPDATE_LARGE_JUNK, percent)
    }

}
