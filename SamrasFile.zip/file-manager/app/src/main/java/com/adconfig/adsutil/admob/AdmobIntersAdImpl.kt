package com.adconfig.adsutil.admob

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.adconfig.adsutil.Config
import com.adconfig.adsutil.abstract.IntersAd
import com.adconfig.adsutil.utils.AdsError
import com.adconfig.adsutil.utils.AdsListener
import com.adconfig.adsutil.utils.isAnyAdShowing
import com.adconfig.adsutil.utils.isOnline

class AdmobIntersAdImpl : IntersAd() {

    //    override val TAG = "AdmobInters"
    private val TAG: String = "ADCONFIG_InterAd"
//    var auInterstitialAds = AuInterstitialAds()

    override fun destroy() {
        Config.mInterstitialAd = null
    }

    override fun show(activity: Activity) {
//         Log.i("ADCONFIG_InterAd", "show.000")
        if (Config.mInterstitialAd == null) {
            Log.i("ADCONFIG_InterAd", "show.001")
//            if (auInterstitialAds.isAdLoaded()!!) {
//                auInterstitialAds.showInterstitialAds(object : AdsListener {
//                    override fun onAdClicked() {
//                        adsListener.onAdClicked()
//
//                    }
//
//                    override fun onAdDismissed() {
//                        adsListener.onAdDismissed()
//                    }
//
//                    override fun onAdLoaded(appOpenAd: Any) {
//                    }
//
//                    override fun onAdLoaded() {
//                        adsListener.onAdLoaded()
//                    }
//
//                    override fun onAdFailedToShow(adsError: AdsError) {
//                        adsListener.onAdFailedToShow(AdsError(0, ""))
//                    }
//
//                    override fun onAdImpression() {
//                        adsListener.onAdImpression()
//                    }
//
//                    override fun onAdShowed() {
//                        adsListener.onAdShowed()
//                    }
//                })
//            } else {
            isAnyAdShowing = false
            Log.i("isAnyAdShowing", "isAnyAdShowing.005:$isAnyAdShowing")
            adsListener?.onAdFailedToShow(AdsError(0, ""))
//            }
        } else {
            Log.i("ADCONFIG_InterAd", "show.002")
            Config.mInterstitialAd?.show(activity)
            Config.mInterstitialAd?.fullScreenContentCallback = fullScreenContentCallback
        }
    }

    override fun load(context: Context, mAdId: String, onLoaded: (isLoaded: Boolean) -> Unit) {
        Log.i("ADCONFIG_InterAd", "load:$mAdId")
        if (Config.mInterstitialAd == null) {
            Log.i("ADCONFIG_InterAd", "load new")
            loadInters(context, { isLoaded, message, interstitial ->
                if (isLoaded) {
//                    Config.mInterstitialAd = interstitial
                } else {
                    adsListener?.onAdFailedToShow(AdsError(0, message))
                }
                onLoaded.invoke(isLoaded)
            }, mAdId)
        } else {
            Log.i("ADCONFIG_InterAd", "loaded")
            onLoaded.invoke(true)
        }
    }

    private val fullScreenContentCallback = object : FullScreenContentCallback() {
        override fun onAdClicked() {
            super.onAdClicked()
            adsListener?.onAdClicked()
        }

        override fun onAdDismissedFullScreenContent() {
            super.onAdDismissedFullScreenContent()
            adsListener?.onAdDismissed()
        }

        override fun onAdFailedToShowFullScreenContent(adError: com.google.android.gms.ads.AdError) {
            super.onAdFailedToShowFullScreenContent(adError)
            adsListener?.onAdFailedToShow(AdsError(adError.code, adError.message))
        }

        override fun onAdImpression() {
            super.onAdImpression()
            adsListener?.onAdImpression()
        }

        override fun onAdShowedFullScreenContent() {
            super.onAdShowedFullScreenContent()
            adsListener?.onAdShowed()
        }
    }

    private fun getAdRequest(): AdRequest {
        return AdRequest
            .Builder()
//            .setHttpTimeoutMillis(3000)
            .build()
    }

    fun loadInters(
        context: Context,
        onLoaded: (isLoaded: Boolean, message: String, interstitial: InterstitialAd?) -> Unit,
        mAdId: String
    ) {
        // Log.i("ADCONFIG_InterAd", "loadInters:isOnline:${context.isOnline()}")
//        val interAdId = Config.admobInterstitialAdId
        if (!context.isOnline()) {
            onLoaded.invoke(false, "failed:Device Offline", null)
        } else {
            val interAdId = mAdId
            InterstitialAd.load(
                context,
                interAdId,
                getAdRequest(),
                object : InterstitialAdLoadCallback() {
                    override fun onAdFailedToLoad(adError: LoadAdError) {
                        super.onAdFailedToLoad(adError)
                        Log.i(
                            TAG,
                            "onAdFailedToLoad: Ad failed to load -> \nresponseInfo::${adError.responseInfo}\nErrorCode::${adError.code}\nErrorMessage::${adError.message}"
                        )
                        onLoaded.invoke(
                            false,
                            "${adError.code}\n${adError.message}\n${adError.responseInfo}",
                            null
                        )

                    }

                    override fun onAdLoaded(interstitialAd: InterstitialAd) {
                        // Log.i("ADCONFIG_InterAd", "onAdLoaded")
                        Config.mInterstitialAd = interstitialAd
                        onLoaded.invoke(true, "Success", interstitialAd)
                    }
                }
            )
        }
    }
}