package com.explorefile.filemanager.interfaces

interface RecyclerScrollCallback {
    fun onScrolled(scrollY: Int)
}
