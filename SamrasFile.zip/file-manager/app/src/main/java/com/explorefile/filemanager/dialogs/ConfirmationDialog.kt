package com.explorefile.filemanager.dialogs

import android.app.Activity
import androidx.appcompat.app.AlertDialog
import com.explorefile.filemanager.R
import com.explorefile.filemanager.databinding.DialogDeleteMessageBinding
import com.explorefile.filemanager.extensions.beGone
import com.explorefile.filemanager.extensions.getAlertDialogBuilder
import com.explorefile.filemanager.extensions.setupDialogStuff

class ConfirmationDialog(
    activity: Activity,
    message: String = "",
    messageId: Int = R.string.proceed_with_deletion,
    positive: Int = R.string.yes,
    negative: Int = R.string.no,
    val cancelOnTouchOutside: Boolean = true,
    dialogTitle: Int = R.string.permanently_delete,
    val callback: () -> Unit
) {
    private var dialog: AlertDialog? = null

    init {
        val view = DialogDeleteMessageBinding.inflate(activity.layoutInflater, null, false)
        view.message.text = message.ifEmpty { activity.resources.getString(messageId) }

        val builder = activity.getAlertDialogBuilder()

        if (negative != 0) {
            view.txtCancel.text = activity.resources.getText(negative)
        } else {
            view.txtCancel.beGone()
            view.imageView.beGone()
        }

        view.txtOk.text = activity.resources.getText(positive)
        view.txtTitle.text = activity.resources.getText(dialogTitle)

        view.txtOk.setOnClickListener {
            dialogConfirmed()
        }

        view.txtCancel.setOnClickListener {
            dialog?.dismiss()
        }

        builder.apply {
            activity.setupDialogStuff(
                view.root,
                this,
                cancelOnTouchOutside = cancelOnTouchOutside
            ) { alertDialog ->
                dialog = alertDialog
            }
        }
    }

    private fun dialogConfirmed() {
        dialog?.dismiss()
        callback()
    }
}
