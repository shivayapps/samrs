package com.explorefile.filemanager.activities

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.adconfig.adsutil.admob.NativeAdHelper
import com.adconfig.adsutil.admob.NativeLayoutType
import com.explorefile.filemanager.databinding.ActivityStartBinding
import com.explorefile.filemanager.extensions.getProperBackgroundColor
import com.explorefile.filemanager.extensions.getProperTextColor
import com.explorefile.filemanager.extensions.viewBinding
import com.explorefile.filemanager.helpers.FIRST_TIME_KEY
import com.explorefile.filemanager.helpers.INTENT_KEY

class StartActivity : BaseActivity() {

    val binding by viewBinding(ActivityStartBinding::inflate)

    override fun onCreate(savedInstanceState: Bundle?) {
        isMaterialActivity = true
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        binding.txtGetStart.setOnClickListener {
            startActivity(
                Intent(this, LanguageActivity::class.java).putExtra(
                    INTENT_KEY,
                    FIRST_TIME_KEY
                )
            )
            finish()
        }

    }

    override fun onResume() {
        super.onResume()

        updateStatusbarColor(getProperBackgroundColor())

        arrayOf(
            binding.txtFile,
            binding.txtInfo
        ).forEach {
            it.setTextColor(getProperTextColor())
        }

    }
}