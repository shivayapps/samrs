package com.explorefile.filemanager.filecleaner

import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.adconfig.adsutil.admob.BannerAdHelper
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.BaseActivity
import com.explorefile.filemanager.databinding.ActivityStorageAnalysisBinding
import com.explorefile.filemanager.extensions.getProperBackgroundColor
import com.explorefile.filemanager.extensions.viewBinding
import com.explorefile.filemanager.filecleaner.viewmodel.StorageAnalysisVM
import com.explorefile.filemanager.helpers.AdCache
import com.explorefile.filemanager.helpers.NavigationIcon
import com.google.android.gms.ads.AdView


class StorageAnalysisActivity : BaseActivity(), View.OnClickListener {

    private val binding by viewBinding(ActivityStorageAnalysisBinding::inflate)
    private val vm: StorageAnalysisVM by viewModels()

    private var mAdView: AdView? = null
    private var isAdLoaded = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        setupToolbar()
        setupObservers()
        setupClickListeners()
        initAds()
    }

    private fun setupToolbar() {
        binding.analyzeToolbar.title = getString(R.string.storage_analysis)
    }

    private fun setupObservers() {
        vm.scanResult.observe(this) { result ->
            result?.stat?.let { stat ->
                val usedPercent = if (stat.totalSize != 0L)
                    (stat.usedSize * 100 / stat.totalSize).toInt()
                else 0
                binding.tvSaUsedPercentValue.text = "$usedPercent%"
                binding.tvSaStorageUsedSizeValue.text = formatSize(stat.usedSize)
                binding.tvSaStorageTotalSizeValue.text = formatSize(stat.totalSize)
            }

            result?.file?.let { file ->
                binding.tvSrImageSize.text = formatSize(file.image.queueSize.get())
                binding.tvSrVideoSize.text = formatSize(file.video.queueSize.get())
                binding.tvSrAudioSize.text = formatSize(file.audio.queueSize.get())
                binding.tvSrDocumentSize.text = formatSize(file.document.queueSize.get())
                binding.tvSrApkFileSize.text = formatSize(file.apkFile.queueSize.get())
                binding.tvSrCompressedFileSize.text = formatSize(file.compressedFile.queueSize.get())
                binding.tvSrEmptyDirSize.text = formatCount(file.emptyDir.fileQueue.size)
                binding.tvSrNoExtFileSize.text = formatSize(file.noExt.queueSize.get())
                binding.tvSrUnknownExtFileSize.text = formatSize(file.unknownExt.queueSize.get())
            }

            binding.tvSrOtherSize.text = formatSize(result.other)
//            binding.tvSaScanCost.text = getString(R.string.scan_cost, result.file?.scanCost ?: 0)
            binding.tvSaScanCost.text = getString(R.string.scan_cost, result.file?.scanCost?.toString() ?: "0")

            binding.sabMain.dataAndColorArray=vm.sabData.value
            binding.sabMain.invalidate()
        }

        vm.sabData.observe(this) {
            binding.sabMain.dataAndColorArray=it
            binding.sabMain.invalidate()
        }
    }

    private fun setupClickListeners() {
        binding.llSrImageSizeContainer.setOnClickListener(this)
        binding.llSrVideoSizeContainer.setOnClickListener(this)
        binding.llSrAudioSizeContainer.setOnClickListener(this)
        binding.llSrDocumentSizeContainer.setOnClickListener(this)
        binding.llSrApkFileSizeContainer.setOnClickListener(this)
        binding.llSrCompressedFileSizeContainer.setOnClickListener(this)
        binding.llSrEmptyDirSizeContainer.setOnClickListener(this)
        binding.llSrNoExtFileSizeContainer.setOnClickListener(this)
        binding.llSrUnknownExtFileSizeContainer.setOnClickListener(this)
        binding.llSrOtherSizeContainer.setOnClickListener(this)
    }

    private fun initAds() {
        val adId = getString(R.string.b_fileType)

        BannerAdHelper.showBanner(this,
            binding.frameAds,
            binding.frameAds,
            adId,
            AdCache.bannerFileType,
            { isLoaded, adView, message ->
                mAdView = adView
                AdCache.bannerFileType = adView
                isAdLoaded = isLoaded
            })
    }

    override fun onResume() {
        super.onResume()
        mAdView?.resume()
        setupToolbar(binding.analyzeToolbar, NavigationIcon.Arrow)
        updateTopBarColors(binding.analyzeToolbar, getProperBackgroundColor())
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
    }

    override fun onStart() {
        super.onStart()
        vm.startScanStorage()
    }

    override fun onDestroy() {
        super.onDestroy()
        vm.stopScanStorageIfNeed()
        mAdView?.destroy()
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            binding.llSrImageSizeContainer.id -> { /* handle image */ }
            binding.llSrVideoSizeContainer.id -> { /* handle video */ }
            // Add other click handlers here
        }
    }

    private fun formatSize(bytes: Long?): String {
        bytes ?: return "0 B"
        // Use formatter or custom logic here
        return android.text.format.Formatter.formatShortFileSize(this, bytes)
    }

    private fun formatCount(count: Int?): String {
        return count?.toString() ?: "0"
    }
}
