package com.explorefile.filemanager.helpers

import com.explorefile.filemanager.models.AppInfo
import java.util.*

/**
 * Created by Mahendra Gohil on 07-12-2021.
 * Holder for apps
 */

class AppManager {
    var userApps: MutableList<AppInfo> = ArrayList()
    var systemApps: MutableList<AppInfo> = ArrayList()
    var userAppSize: Int = 0
    var systemAppSize: Int = 0
}
