package com.explorefile.filemanager.fragments

import android.content.Context
import android.util.AttributeSet
import android.widget.RelativeLayout
import com.explorefile.filemanager.R
import com.explorefile.filemanager.activities.BaseActivity
import com.explorefile.filemanager.activities.MainActivity
import com.explorefile.filemanager.databinding.ApplicationFragmentBinding
import com.explorefile.filemanager.databinding.ItemsFragmentBinding
import com.explorefile.filemanager.databinding.RecentsFragmentBinding
import com.explorefile.filemanager.databinding.StorageFragmentBinding
import com.explorefile.filemanager.extensions.deleteFiles
import com.explorefile.filemanager.extensions.getMimeType
import com.explorefile.filemanager.extensions.isAudioFast
import com.explorefile.filemanager.extensions.isPathOnRoot
import com.explorefile.filemanager.extensions.toast
import com.explorefile.filemanager.extensions.tryOpenPathIntent
import com.explorefile.filemanager.helpers.RootHelpers
import com.explorefile.filemanager.helpers.VIEW_TYPE_LIST
import com.explorefile.filemanager.models.FileDirItem

abstract class MyViewPagerFragment<BINDING : MyViewPagerFragment.InnerBinding>(
    context: Context,
    attributeSet: AttributeSet
) :
    RelativeLayout(context, attributeSet) {
    protected var activity: BaseActivity? = null
    protected var currentViewType = VIEW_TYPE_LIST

    var currentPath = ""
    var isGetContentIntent = false
    var isGetRingtonePicker = false
    var isPickMultipleIntent = false
    var wantedMimeTypes = listOf("")
    protected var isCreateDocumentIntent = false
    protected lateinit var innerBinding: BINDING

    protected fun clickedPath(path: String) {
        if (isGetContentIntent || isCreateDocumentIntent) {
            (activity as MainActivity).pickedPath(path)
        } else if (isGetRingtonePicker) {
            if (path.isAudioFast()) {
                (activity as MainActivity).pickedRingtone(path)
            } else {
                activity?.toast(R.string.select_audio_file)
            }
        } else {
            activity?.tryOpenPathIntent(path, false)
        }
    }

    fun handleFileDeleting(files: ArrayList<FileDirItem>, hasFolder: Boolean) {
        val firstPath = files.firstOrNull()?.path
        if (firstPath == null || firstPath.isEmpty() || context == null) {
            return
        }

        if (context!!.isPathOnRoot(firstPath)) {
            RootHelpers(activity!!).deleteFiles(files)
        } else {
            (activity as BaseActivity).deleteFiles(files, hasFolder) {
                if (!it) {
                    activity!!.runOnUiThread {
                        activity!!.toast(R.string.unknown_error_occurred)
                    }
                }
            }
        }
    }




    protected fun isProperMimeType(
        wantedMimeType: String,
        path: String,
        isDirectory: Boolean
    ): Boolean {
        return if (wantedMimeType.isEmpty() || wantedMimeType == "*/*" || isDirectory) {
            true
        } else {
            val fileMimeType = path.getMimeType()
            if (wantedMimeType.endsWith("/*")) {
                fileMimeType.substringBefore("/").equals(wantedMimeType.substringBefore("/"), true)
            } else {
                fileMimeType.equals(wantedMimeType, true)
            }
        }
    }

    abstract fun setupFragment(activity: BaseActivity)
    abstract fun setupCategoriesBinding(activity: BaseActivity)

    abstract fun onResume(textColor: Int)

    abstract fun refreshFragment()

    abstract fun searchQueryChanged(text: String)

    interface InnerBinding

    class ItemsInnerBinding(val binding: ItemsFragmentBinding) : InnerBinding

    class RecentsInnerBinding(val binding: RecentsFragmentBinding) : InnerBinding

    class StorageInnerBinding(val binding: StorageFragmentBinding) : InnerBinding
    class ApplicationInnerBinding(val binding: ApplicationFragmentBinding) : InnerBinding
}
